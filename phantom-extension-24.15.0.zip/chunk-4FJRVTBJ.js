import{E as i,p as t}from"./chunk-OJG7N72N.js";import{cc as p}from"./chunk-Q5O4STUM.js";import{a as u}from"./chunk-MVAHBHCD.js";import{f as d,h as n,n as a}from"./chunk-FPMOV6V2.js";n();a();var e=d(u());var A=({name:c,publicKey:m,publicKeyLabel:r,hideParens:b})=>{let s=p(m,4),o=b?s:`(${s})`;return e.default.createElement(e.default.Fragment,null,e.default.createElement(y,null,c),r?e.default.createElement(g,null,e.default.createElement(l,null,o),e.default.createElement(P,null,r)):e.default.createElement(l,null,o))},y=t(i).attrs({size:16,weight:500,color:"white",maxWidth:"135px",noWrap:!0})``,l=t(i).attrs({size:16,weight:400,opacity:.5})``,P=t.span`
  opacity: 0.3;
  font-size: 15px;
  margin-right: 5px;
  display: inline-flex;
`,g=t.div`
  text-align: right;
`;export{A as a};
