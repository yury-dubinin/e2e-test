import{p as r}from"./chunk-OJG7N72N.js";import{h as t,n}from"./chunk-FPMOV6V2.js";t();n();var e={width:"100%",align:"flex-start",direction:"column",justify:"flex-start"},s=r.div`
  display: flex;
  flex: ${i=>i.flex};
  flex-direction: ${i=>i.direction};
  width: ${i=>i.width};
  margin: ${i=>i.margin};
  padding: ${i=>i.padding};
  align-items: ${i=>i.align};
  justify-content: ${i=>i.justify};
`;s.defaultProps=e;export{s as a};
