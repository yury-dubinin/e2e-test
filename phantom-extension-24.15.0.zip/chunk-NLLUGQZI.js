import{da as p,j as l}from"./chunk-KB2UMCDM.js";import{E as s,p as r}from"./chunk-OJG7N72N.js";import{r as a}from"./chunk-IVQ3W7KJ.js";import{h as i,i as n}from"./chunk-RO2HUFH7.js";import{a as f}from"./chunk-MVAHBHCD.js";import{f as m,h as t,n as e}from"./chunk-FPMOV6V2.js";t();e();var o=m(f());var d=r.header`
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30px 40px;
`,g=r.a`
  text-decoration: none;
  display: flex;
  align-items: center;
  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
  transition-duration: 250ms;
  transition-property: color;
  color: #aaa;
  svg {
    fill: #222222;
    color: inherit;
    * {
      color: inherit;
    }
  }
  &:hover {
    opacity: 0.8;
  }
`,h=r.a`
  display: flex;
  color: #aaa;
  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
  transition-duration: 250ms;
  transition-property: color;
  svg {
    fill: #222222;
    color: inherit;
    * {
      color: inherit;
    }
  }
  &:hover {
    opacity: 0.8;
  }
`,k=()=>{let{t:c}=a();return o.default.createElement(d,null,o.default.createElement(h,{href:n,target:"_blank",rel:"noopener noreferrer"},o.default.createElement(l,{width:32})),o.default.createElement(g,{"data-testid":"full-page-header-support-link",href:i,rel:"noopener",target:"_blank"},o.default.createElement(p,null),o.default.createElement(s,{color:"#222222",size:16,weight:500,margin:"0 0 0 8px"},c("fullPageHeaderHelp"))))};export{k as a};
