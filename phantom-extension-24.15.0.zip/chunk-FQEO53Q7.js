import{a as L}from"./chunk-5CR56F4P.js";import{f as le}from"./chunk-IB7UF4X6.js";import{a as E,c as M,d as B,e as W,f as z}from"./chunk-7HOFAWG5.js";import{a as de,b as O}from"./chunk-W5GLT6IB.js";import{a as C}from"./chunk-JQSMP2U7.js";import{a as ne}from"./chunk-MLAFUF6V.js";import{E as ie,F as ae,Qa as se,n as F,q as re}from"./chunk-KB2UMCDM.js";import{E as u,l as V,p as n}from"./chunk-OJG7N72N.js";import{e as oe}from"./chunk-D3AP5534.js";import{b as Y}from"./chunk-T2EVB3DU.js";import{Ed as ee,Gb as P,Jb as q,Kb as J,Nd as R,Oa as w,Rd as te,ba as G,cc as Q,jd as Z}from"./chunk-Q5O4STUM.js";import{r as h}from"./chunk-IVQ3W7KJ.js";import{s as U,t as X}from"./chunk-RO2HUFH7.js";import{a as v}from"./chunk-MVAHBHCD.js";import{f as I,h as p,n as c}from"./chunk-FPMOV6V2.js";p();c();var _e=()=>{let{t:e}=h(),{mutateAsync:t}=ee(),{mutateAsync:o}=Z();return{handleImportSeed:async(a,m,f,l=0)=>{let S=await ne(a,m,f),x={};if(S.forEach((A,_)=>{let N=e("onboardingImportAccountsAccountName",{walletIndex:l+_+1});x[A.identifier]={name:N}}),await o({metadataBatch:x}),S.length===0)throw new Error("Failed to set seed phrase");await t({identifier:S[0].identifier}),oe.capture("addSeedAccount",{data:{walletIndex:l+1}})}}};p();c();var r=I(v());p();c();var g=I(v());var T=({primaryContent:e,secondaryContent:t,leftContent:o,rightContent:d,onClick:a,disabled:m,["data-testid"]:f})=>g.default.createElement(Ie,{"data-testid":f,onClick:m?void 0:a,disabled:m},g.default.createElement(Ae,null,o,g.default.createElement("div",null,typeof e=="string"?g.default.createElement(u,{weight:600,size:16,textAlign:"left"},e):e,typeof t=="string"?g.default.createElement(u,{color:"#777777",size:14,textAlign:"left",lineHeight:18},t):t)),d===void 0?g.default.createElement(re,null):d),k=n.div`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 32px;
  min-width: 32px;
  width: 32px;
  height: 32px;
  margin-left: -8px;
`,Ae=n.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: fit-content;
  gap: 12px;
`,Ie=n.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #2a2a2a;
  border-radius: 6px;
  padding: 18px 20px;
  width: 100%;
  margin-bottom: 10px;
  &:last-of-type {
    margin-bottom: 0;
  }
  ${e=>e.onClick&&V`
      :hover {
        background: #333;
        cursor: pointer;
      }
    `}
  ${e=>e.disabled&&V`
      opacity: 0.5;
      :hover {
        background: #2a2a2a;
        cursor: not-allowed;
      }
    `}
`;p();c();var i=I(v());var ce=({onChange:e,value:t,networkID:o})=>{let d=P(),a=(0,i.useMemo)(()=>{if(!o)return[];let f=w.getAddressTypes(o);return d.filter(l=>f.includes(l))},[d,o]);if(!a||a.length===0)return null;let m=a.includes(t)?t:a[0];return i.default.createElement(ve,{onChange:e,value:m},({isExpanded:f})=>i.default.createElement(i.default.Fragment,null,i.default.createElement(be,{isActive:f},i.default.createElement(pe,{networkID:o,addressType:m},i.default.createElement(me,null,i.default.createElement(F,{fill:"#777",width:10})))),i.default.createElement(Te,{portal:!1},i.default.createElement(W,{maxHeight:"300px"},a?.filter(l=>l!==m)?.map(l=>i.default.createElement(ke,{key:l,value:l},i.default.createElement(pe,{networkID:o,addressType:l})))))))},pe=({addressType:e,networkID:t,children:o})=>!t||!e?null:i.default.createElement(C,{justify:"space-between"},i.default.createElement(C,null,i.default.createElement(L,{networkID:t,size:32}),i.default.createElement(Ne,null,G.getDisplayName(e))),o),ve=n(E)`
  width: 100%;
  position: relative;
`,me=n.div`
  display: inline-flex;
  line-height: 0;
`,be=n(({isActive:e,...t})=>i.default.createElement(M,{...t}))`
  padding: 8px 16px 8px 12px;

  ${me} {
    svg {
      transform: rotate(${e=>e.isActive?"-180deg":"0"});
      transition: transform 0.2s ease-in-out;
    }
  }
`,Te=n(B)`
  z-index: 2;
  width: 100%;
`,ke=n(z)`
  padding: 8px 16px 8px 12px;
  min-height: 50px;
`,Ne=n(u).attrs({size:16,weight:400,lineHeight:19,margin:"0 0 0 8px"})``;p();c();var s=I(v());var De=n(E)`
  width: 100%;
  position: relative;
`,fe=n.div`
  display: inline-flex;
  line-height: 0;
`,Pe=n(({isActive:e,...t})=>s.default.createElement(M,{...t}))`
  padding: 8px 16px 8px 12px;

  ${fe} {
    svg {
      transform: rotate(${e=>e.isActive?"-180deg":"0"});
      transition: transform 0.2s ease-in-out;
    }
  }
`,Fe=n(B)`
  z-index: 2;
  width: 100%;
`,Ee=n(z)`
  padding: 8px 16px 8px 12px;
  min-height: 50px;
`,Me=n(u).attrs({size:16,weight:400,lineHeight:19,margin:"0 0 0 8px"})``,he=({onChange:e,value:t})=>{let o=q();return s.default.createElement(De,{onChange:e,value:t},({isExpanded:d})=>s.default.createElement(s.default.Fragment,null,s.default.createElement(Pe,{isActive:d},s.default.createElement(ue,{networkID:t},s.default.createElement(fe,null,s.default.createElement(F,{fill:"#777",width:10})))),s.default.createElement(Fe,{portal:!1},s.default.createElement(W,{maxHeight:"300px"},o.filter(a=>a!==t).map(a=>s.default.createElement(Ee,{key:a,value:a},s.default.createElement(ue,{networkID:a})))))))},ue=({networkID:e,children:t})=>s.default.createElement(C,{justify:"space-between"},s.default.createElement(C,null,s.default.createElement(L,{networkID:e,size:32}),s.default.createElement(Me,null,w.getNetworkName(e))),t);var Ht=({onClick:e,disabled:t})=>{let{t:o}=h(),{isSolanaOnlyEnabled:d}=J();return r.default.createElement(T,{"data-testid":"import-private-key-button",primaryContent:o("addAccountImportWalletPrimaryText"),secondaryContent:o(d?"addAccountImportWalletSolanaSecondaryText":"addAccountImportWalletSecondaryText"),leftContent:r.default.createElement(k,null,r.default.createElement(ie,{fill:"#EDEDEF"})),rightContent:null,onClick:e,disabled:t})},_t=({control:e,getValues:t,register:o,setValue:d,trigger:a,errors:m,nameValidations:f,privateKey:l,privateKeyValidations:S,addressPreview:x})=>{let{t:A}=h(),_=te(y=>y.editableAccountMetadata),N=t("networkID"),ye=w.getAddressTypes(N),j=P(),we=j.filter(y=>ye.includes(y));return r.default.createElement(le,null,r.default.createElement(R,{name:"networkID",control:e,render:({field:{onChange:y,value:$}})=>j.length===1?r.default.createElement(r.default.Fragment,null):r.default.createElement(he,{onChange:D=>{y(D);let ge=w.getAddressTypes(D),Se=j.filter(xe=>ge.includes(xe));d("addressType",Se[0]),l&&a("privateKey")},value:$})}),r.default.createElement(R,{name:"addressType",control:e,render:({field:{onChange:y,value:$}})=>we.length===1?r.default.createElement(r.default.Fragment,null):r.default.createElement(ce,{onChange:D=>{y(D),l&&a("privateKey")},value:$,networkID:N})}),r.default.createElement(O.WithWarning,{placeholder:A("addAccountImportAccountName"),defaultValue:_?.name,warning:!!m.name,warningMessage:m.name?.message,autoComplete:"off",maxLength:Y,...o("name",f)}),r.default.createElement(Ce.WithWarning,{placeholder:A("addAccountImportAccountPrivateKey"),defaultValue:"",warning:!!m.privateKey,warningMessage:m.privateKey?.message,autoComplete:"off",...o("privateKey",S)}),x?r.default.createElement(Be,{label:A("settingsWalletAddress"),pubkey:x}):null)},Be=r.default.memo(({label:e,pubkey:t})=>r.default.createElement(C,{justify:"space-between",align:"center",margin:"-7px 0 0"},r.default.createElement(u,{size:16,weight:600},e),r.default.createElement(u,{size:16},Q(t,4)))),We=n(O.withComponent("textarea"))`
  height: 120px;
  text-align: start;
  resize: none;
  -webkit-text-security: disc;
`,Ce=de(We);Ce.defaultProps={fontSize:"16px"};p();c();var K=I(v());var Gt=({onClick:e,disabled:t})=>{let{t:o}=h(),d=U||X;return K.default.createElement(T,{primaryContent:o("addAccountHardwareWalletPrimaryText"),secondaryContent:o("addAccountHardwareWalletSecondaryText"),leftContent:K.default.createElement(k,null,K.default.createElement(se,{fill:"#EDEDEF"})),rightContent:null,onClick:e,disabled:t||d})};p();c();var H=I(v());var to=({onClick:e,disabled:t})=>{let{t:o}=h();return H.default.createElement(T,{"data-testid":"import-seed-phrase-button",primaryContent:o("addAccountImportSeedPhrasePrimaryText"),secondaryContent:o("addAccountImportSeedPhraseSecondaryText"),leftContent:H.default.createElement(k,null,H.default.createElement(ae,{fill:"#EDEDEF"})),rightContent:null,onClick:e,disabled:t})};export{_e as a,T as b,k as c,he as d,Ht as e,_t as f,Gt as g,to as h};
