import{b as e}from"./chunk-XBQBBV2G.js";import{l as t,p as a}from"./chunk-OJG7N72N.js";import{h as i,n as d}from"./chunk-FPMOV6V2.js";i();d();var s=a.div`
  background: ${o=>o.isHighlighted?"#333":"#2a2a2a"};
  ${o=>o.opacity!==void 0?`opacity: ${o.opacity};`:""}
  border-radius: ${e.radiusRow};
  padding-top: 15px;
  padding-bottom: 15px;
  padding-left: 10px;
  padding-right: 15px;
  display: flex;
  margin-bottom: 10px;
  align-items: center;
  width: 100%;
  cursor: ${o=>o.isDisabled?"auto":"pointer"};
  ${o=>!o.isDisabled&&t`
      &:hover {
        opacity: 1;
        background: #333333;
      }
    `}
`;export{s as a};
