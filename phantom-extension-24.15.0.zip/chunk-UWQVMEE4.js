import{p as n,y as i}from"./chunk-OJG7N72N.js";import{a as g}from"./chunk-MVAHBHCD.js";import{f as c,h as o,n as r}from"./chunk-FPMOV6V2.js";o();r();var e=c(g());var L=n.div`
  display: flex;
  align-items: center;
  justify-content: center;
`,s=({className:a,children:l,isLoading:p,spinnerColor:d,showingDelayMs:t=500})=>{let[u,f]=(0,e.useState)(!0);return(0,e.useEffect)(()=>{let m=setTimeout(()=>f(!1),t);return()=>{clearTimeout(m)}},[t]),p?u?null:e.default.createElement(L,{className:a},e.default.createElement(i,{color:d})):e.default.createElement(e.default.Fragment,null,l)};s.defaultProps={isLoading:!1};var x=n(s)`
  height: 100%;
`;export{x as a};
