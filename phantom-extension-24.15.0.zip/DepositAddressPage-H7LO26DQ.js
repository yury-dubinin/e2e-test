import{a as k}from"./chunk-4FJRVTBJ.js";import{a as N}from"./chunk-CYZ74O6J.js";import{c as P}from"./chunk-P3IBEZ5F.js";import{C as h}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import{a as x}from"./chunk-JQSMP2U7.js";import{a as g}from"./chunk-7ZDPJAUC.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-VHWNQPFU.js";import"./chunk-KB2UMCDM.js";import{A as l,E as A,p as r}from"./chunk-OJG7N72N.js";import"./chunk-LZSLSY3Q.js";import{fc as b}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as y}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as C}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f,h as m,n as c}from"./chunk-FPMOV6V2.js";m();c();var D=f(N()),o=f(C());m();c();var a=f(C());var B=r(l).attrs({borderRadius:"100px",theme:"primary",width:"auto",fontSize:14,fontWeight:600})`
  flex-shrink: 0;
  padding: 5px 12px;
`,w=a.default.memo(s=>{let{copyText:t,className:i}=s,{buttonText:e,copy:n}=P(t),u=(0,a.useCallback)(d=>{d.stopPropagation(),n()},[n]);return a.default.createElement(B,{className:i,onClick:u},e)});var F=r(g).attrs({align:"center",justify:"space-between"})`
  height: 100%;
`,I=r(D.default)`
  padding: 8px;
  background: #ffffff;
  border-radius: 6px;
`,T=r(x).attrs({align:"center",justify:"space-between"})`
  padding: 12px 15px;
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 6px;
  box-shadow: inset 0px 0px 4px rgba(0, 0, 0, 0.25);
`,v=r(g).attrs({align:"center"})`
  ${T} {
    margin-top: 32px;
    margin-bottom: 11px;
  }
`,z=r(x)`
  p:first-child {
    margin-right: 6px;
  }
`,H=s=>{let{accountName:t,walletAddress:i,address:e,symbol:n,onClose:u}=s,d=n||(e?b(e):void 0),{t:p}=y();return{i18nStrings:(0,o.useMemo)(()=>({depositAssetInterpolated:p("depositAssetDepositInterpolated",{tokenSymbol:d}),secondaryText:p("depositAssetSecondaryText"),transferFromExchange:p("depositAssetTransferFromExchange"),close:p("commandClose")}),[p,d]),accountName:t,walletAddress:i,onClose:u}},M=o.default.memo(s=>{let{i18nStrings:t,accountName:i,walletAddress:e,onClose:n}=s;return o.default.createElement(F,null,o.default.createElement(h,null,t.depositAssetInterpolated),o.default.createElement(v,null,o.default.createElement(I,{value:e,size:160}),o.default.createElement(T,null,o.default.createElement(z,null,o.default.createElement(k,{name:i,publicKey:e})),o.default.createElement(w,{copyText:e})),o.default.createElement(A,{size:14,color:"#777777",lineHeight:20},t.secondaryText)),o.default.createElement(g,null,o.default.createElement(l,{onClick:n},t.close)))}),E=o.default.memo(s=>{let t=H(s);return o.default.createElement(M,{...t})}),oo=E;export{E as DepositAddressPage,oo as default};
