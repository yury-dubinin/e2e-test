import{a as be}from"./chunk-4FHVYNCP.js";import{a as Pt}from"./chunk-4FJRVTBJ.js";import{a as xt}from"./chunk-246MQMRD.js";import{a as vt}from"./chunk-V5HJYMXJ.js";import{p as wt}from"./chunk-Y3KNGKBS.js";import{a as Pe}from"./chunk-QVVAGMA5.js";import{a as we}from"./chunk-OIUFF6CQ.js";import{d as gt}from"./chunk-WK2JI25E.js";import{h as ht}from"./chunk-W5GLT6IB.js";import{C as j,t as ft,z as Y}from"./chunk-FGDP4DIS.js";import{a as ie}from"./chunk-JQSMP2U7.js";import{a as J}from"./chunk-7ZDPJAUC.js";import{a as f,c as de,j as g,r as ct,z as xe}from"./chunk-XBQBBV2G.js";import{a as re}from"./chunk-DDQ3VOL7.js";import{b as ot,c as rt}from"./chunk-Y44OMTJB.js";import{b as pe,c as st,e as ge,f as ve,g as Ie,h as Re,i as Ee,j as mt,k as pt}from"./chunk-SDQFBK4G.js";import{Wa as it,j as Me,k as me,qb as nt,wc as at}from"./chunk-NAMHSCI2.js";import{qa as lt}from"./chunk-KB2UMCDM.js";import{A as W,B as yt,E as oe,p as l,y as ut}from"./chunk-OJG7N72N.js";import{b as dt,c as Le}from"./chunk-LZSLSY3Q.js";import{e as B}from"./chunk-D3AP5534.js";import{Oa as he,P as ue,Qd as tt,S as ye,Va as _e,yd as et}from"./chunk-Q5O4STUM.js";import{V as Xe,ha as Ye}from"./chunk-PAHUG44L.js";import{a as X,r as E}from"./chunk-IVQ3W7KJ.js";import{D as Je,O as fe,ta as Ze}from"./chunk-FJ67REU6.js";import{a as Q}from"./chunk-MVAHBHCD.js";import{f as U,h as a,n as s}from"./chunk-FPMOV6V2.js";a();s();a();s();var bt=new pe("Failed to get FiatRampProviderUrl"),qe=async(e,o)=>{try{let r=await ue.api().headers(e).post("/fiat_ramp/v2/onramp/provider_url",o);if(!ye(r))throw bt;return r.data}catch{throw bt}};a();s();var De=new pe("Failed to get provider url");async function Ne(e){try{_e(e.defaultToken)&&(e.defaultToken.address=e.defaultToken.address.toLowerCase()),e.userAddresses.forEach(n=>{_e(n)&&(n.address=n.address.toLowerCase())});let o=await ue.api().post("/fiat_ramp/v1/onramp/get_url",e);if(!ye(o))throw De;let r=await o.data;if(!r.url)throw De;return r.url}catch{throw De}}a();s();var O=U(Q());var Ct=()=>O.default.createElement(we,{align:"center",width:"100%",height:"74px",backgroundColor:"#2D2D2D",borderRadius:"8px",margin:"0 0 10px 0",padding:"10px"},O.default.createElement(Bt,null,O.default.createElement(we,{width:"44px",height:"44px",backgroundColor:"#434343",borderRadius:"50%"})),O.default.createElement(J,null,O.default.createElement(ie,{margin:"0 0 10px",justify:"space-between"},O.default.createElement(Tt,{width:"120px"})),O.default.createElement(ie,{justify:"space-between"},O.default.createElement(Tt,{width:"75px"})))),Bt=l.div`
  width: 44px;
  height: 44px;
  margin-right: 15px;
`,Tt=l(we).attrs({height:"8px",backgroundColor:"#484848",borderRadius:"8px"})``;a();s();var ne=U(Q());a();s();var z={container:"_1qwevyc194 _1qwevyc16j _1qwevyc10m _1qwevyc12w _1qwevyc156 _1qwevyczh _1qwevyc11r _1qwevyc141",headerContainer:"_1qwevyc3i _1qwevyc4p",contentContainer:"_1qwevyc194 _1qwevyc16j _1qwevyc18j _1qwevyc19r _1qwevyc19j",emptyStateContainer:"_1qwevyc194 _1qwevyc16j _1qwevyc15v _1qwevyc15i _1qwevyc18j"},Z={container:"wch2wi1 _1qwevyclb _1qwevycm9 _1qwevyco5 _1qwevycn7 _1qwevyc3k _1qwevyc2d _1qwevyc4r _1qwevyc16 _1qwevyc194 _1qwevyc15z _1qwevyc15i _1qwevyczh _1qwevyc1hs _1qwevyc1dm",icon:"_1qwevycld _1qwevycmb _1qwevyco7 _1qwevycn9 _1qwevycyv _1qwevyc100",info:"_1qwevyc84"};var Wt=20,Te=({header:e,content:o,isLoading:r,context:n})=>ne.default.createElement("div",{className:z.container,style:{padding:n==="publicFungible"?16:"initial"}},e&&ne.default.createElement("div",{className:z.headerContainer},e),ne.default.createElement("div",{className:z.contentContainer},r?ne.default.createElement("div",{style:{marginTop:Wt}},[1,2,3,4].map(i=>ne.default.createElement(Ct,{key:i}))):o));a();s();var jt={onClose:()=>{},context:"home",fungible:void 0,purchaseAmount:"",purchaseType:"currency",currencySymbol:"usd",ownerPublicKey:"",price:0,minPurchaseAmount:Re,maxPurchaseAmount:Ie,quickSelectDenominations:Ee,paymentMethod:void 0,provider:void 0,checkoutQuoteType:"recommended",legacyProviders:[]},L=tt(e=>({...jt,setState:o=>e(o)}));a();s();var t=U(Q());a();s();var m=U(Q());a();s();var w=U(Q());var St=w.default.memo(e=>{let{t:o}=E(),{name:r,logo:n,tag:i,quote:d,onClick:p,index:u}=e;return w.default.createElement("div",{className:Z.container,onClick:()=>p(e)},w.default.createElement("div",{className:f({display:"flex",flexDirection:"row",alignItems:"center",gap:10})},w.default.createElement("img",{className:Z.icon,src:n,alt:r}),w.default.createElement("div",{className:f({display:"flex",flexDirection:"column",gap:2})},w.default.createElement(g,{font:"bodySemibold",color:"textPrimary",children:r}),i&&w.default.createElement(g,{font:"caption",color:u===0?"accentSuccess":"textSecondary",children:i}))),d?w.default.createElement("div",{className:f({display:"flex",flexDirection:"column",gap:2})},w.default.createElement(g,{align:"right",font:"bodySemibold",color:"textPrimary",children:d.displayDestinationAmount}),w.default.createElement(g,{align:"right",font:"caption",color:"textSecondary",children:`\u2248 ${d.displaySourceAmount}`})):w.default.createElement("div",{className:f({display:"flex",flexDirection:"row",alignItems:"center",gap:4})},w.default.createElement(g,{align:"right",font:"caption",color:"textSecondary",children:o("buyThirdPartyScreenViewQuote")}),w.default.createElement(de.ChevronRight,{size:16,color:"textSecondary"})))});a();s();var A=U(Q());a();s();var M=U(Q());var Ft=({assets:e,name:o,onClick:r,description:n,estimatedArrival:i})=>M.default.createElement("div",{className:Z.container,onClick:r},M.default.createElement("div",{className:f({display:"flex",flexDirection:"row",gap:10})},M.default.createElement("img",{className:Z.icon,src:e?.roundIcon,alt:o}),M.default.createElement("div",{className:f({display:"flex",flexDirection:"column",gap:6})},M.default.createElement(g,{font:"bodySemibold",color:"textPrimary",children:o}),M.default.createElement(ct,{direction:"row",alignItems:"center",color:"textSecondary",gap:4},M.default.createElement(de.Clock,{size:14}),M.default.createElement(g,{font:"caption",children:i})))),n&&M.default.createElement(gt,{label:n,ariaLabel:o},M.default.createElement(de.Info,{className:Z.info,color:"textSecondary",size:16})));var At=()=>{let{t:e}=E(),{paymentMethods:o,moveToNextPage:r,closeModal:n,isLoading:i,context:d}=zt();return A.default.createElement(Te,{isLoading:i,header:A.default.createElement(j,null,e("buyThirdPartyScreenPaymentMethodTitle")),content:A.default.createElement(A.default.Fragment,null,o.length===0?A.default.createElement("div",{className:z.emptyStateContainer},A.default.createElement(Pe,null,e("buyThirdPartyScreenPaymentMethodEmptyState"))):A.default.createElement("div",{className:f({display:"flex",flexDirection:"column",gap:8,marginBottom:96})},o.map(p=>A.default.createElement(Ft,{key:p.id,onClick:()=>{r(p)},...p})),A.default.createElement(g,{color:"textSecondary",children:e("buyThirdPartyScreenPaymentMethodFooter"),font:"caption"})),d!=="publicFungible"&&A.default.createElement(re,null,A.default.createElement(W,{onClick:n},e("commandClose")))),context:d})},zt=()=>{let e=L(),o=L(u=>u.setState),{popDetailView:r}=Y(),{version:n}=chrome.runtime.getManifest(),{data:i,isLoading:d}=st({"x-client-platform":"web","x-client-app-version":n,"x-client-locale":X.language},{token:e.fungible?.caip19,purchaseAmount:e.purchaseAmount,purchaseType:e.purchaseType}),p=u=>{o({...e,paymentMethod:u,provider:void 0,checkoutQuoteType:"recommended"}),B.capture("fiatOnrampPaymentMethodSelected",{data:{paymentMethodId:u.id}}),r()};return{context:e.context,moveToNextPage:p,closeModal:e.onClose,isLoading:d,paymentMethods:i?.paymentMethods||[]}};var _t=()=>{let{t:e}=E(),{pushDetailViewCallback:o}=Y(),{closeModal:r,onProviderSelected:n,isLoading:i,providers:d,paymentMethod:p,quoteTimeToExpiry:u,quoteTimeToExpiryColor:q,context:_}=Vt();return m.default.createElement(Te,{isLoading:i,header:m.default.createElement(m.default.Fragment,null,m.default.createElement(j,null,e("fiatRampQuotes")),m.default.createElement(xe,{rows:[{type:"drawer",id:"selected-payment-method",onClick:o(m.default.createElement(At,null)),topLeft:{text:p?.name||e("buyThirdPartyScreenPaymentMethod"),before:p?.assets?.icon?m.default.createElement(be,{src:p.assets.icon,width:24,height:24}):void 0}}]})),content:m.default.createElement(m.default.Fragment,null,d.length===0?m.default.createElement("div",{className:z.emptyStateContainer},m.default.createElement(Pe,null,e("buyThirdPartyScreenProvidersEmptyState"))):m.default.createElement(m.default.Fragment,null,m.default.createElement("div",{className:f({display:"flex",flexDirection:"column",gap:8,marginTop:16,marginBottom:96})},m.default.createElement("div",{className:f({display:"flex",justifyContent:"space-between"})},m.default.createElement(g,{font:"bodyMedium",color:"textSecondary",children:e("buyThirdPartyScreenProviders")}),m.default.createElement("div",null,m.default.createElement(g,{font:"captionMedium",color:"textSecondary",children:`${e("fiatRampNewQuote")}:`})," ",m.default.createElement(g,{className:f({width:32}),font:"captionMedium",color:q,children:u}))),d.map((F,v)=>m.default.createElement(St,{key:`${F.id}-${v}`,index:v,onClick:n,...F})))),_!=="publicFungible"&&m.default.createElement(re,null,m.default.createElement(W,{onClick:r},e("commandClose")))),context:_})},Vt=()=>{let{popDetailView:e}=Y(),{handleHideModalVisibility:o}=wt(),r=L(),n=L(D=>D.setState),{fungible:i,purchaseAmount:d,purchaseType:p,paymentMethod:u,ownerPublicKey:q,context:_}=r;if(!i)throw new Error("No fungible asset selected");let{version:F}=chrome.runtime.getManifest(),{data:v,isLoading:V}=mt({"x-client-platform":"web","x-client-app-version":F,"x-client-locale":X.language},{...p==="currency"?{fiatAmount:d}:{tokenAmount:d},token:i.caip19,paymentMethodId:u?.id,destinationAddress:{address:q,chainId:i.caip19.chainId,resourceType:"address"}}),I=u||v?.paymentMethod,x=v?.providers||[],y=(0,m.useCallback)(D=>{B.capture("fiatOnrampProviderSelected",{data:{chainId:v?.token?.chainId,providerId:D.id,paymentMethodId:I?.id,destinationAmount:D.quote?.displayDestinationAmount,sourceAmount:D.quote?.displaySourceAmount,asset:v?.token}}),n({...r,provider:D,paymentMethod:I,checkoutQuoteType:"selected"}),e()},[r,e,v?.token,I,n]),K=Je(),[b,ee]=(0,m.useState)(ge);ft(()=>{V||x.length===0||(b===0?(ee(ge),K.invalidateQueries({refetchType:"active"})):ee(b-1))},V?null:1e3);let T=b<10?`0:0${b}`:`0:${b}`,h=b<=10?"accentWarning":"textPrimary";return{providers:x,paymentMethod:I,onProviderSelected:y,closeModal:()=>o("onramp"),isLoading:V,quoteTimeToExpiry:T,quoteTimeToExpiryColor:h,context:_}};a();s();var k=U(Q());a();s();var H=U(Q());var It=H.default.memo(e=>{let{badge:o,circleAlpha:r=1,circleColor:n,description:i,icon:d,title:p,onClick:u}=e;return H.default.createElement(Kt,{onClick:u},H.default.createElement(vt,{color:n,alpha:r,diameter:48},d),H.default.createElement(J,{margin:"0 0 0 10px"},H.default.createElement(Xt,null,H.default.createElement(Mt,{weight:600,size:16,lineHeight:19},p),o&&H.default.createElement(Gt,null,o)),H.default.createElement(Mt,{weight:400,size:14,lineHeight:17,color:"#999999",maxWidth:"250px"},i)))}),Kt=l.li`
  cursor: pointer;
  display: flex;
  align-items: center;
  background-color: #2a2a2a;
  border-radius: 6px;
  padding: 13px 10px;
  min-height: 74px;
  width: 100%;
  margin-bottom: 10px;

  &:last-of-type {
    margin-bottom: 0;
  }

  &:hover {
    background-color: #333;
  }
`,Mt=l(oe)`
  display: inline-flex;
  align-items: center;
  text-align: left;
`,Gt=l.div`
  cursor: default;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #551bf9;
  border-radius: 32px;
  padding: 2px 6px;
  gap: 4px;
  margin-left: 8px;
  font-size: 11px;
  font-weight: 600;
`,Xt=l.div`
  display: flex;
  margin-bottom: 6px;
`;var Et=()=>{let e=Zt();return k.default.createElement(Jt,{...e})},Jt=k.default.memo(e=>{let{context:o,fiatRampProviders:r,i18nStrings:n,onClose:i,showClose:d}=e;return k.default.createElement(oo,{context:o},k.default.createElement(j,null,n.buy),k.default.createElement(to,null,r.map((p,u)=>k.default.createElement(It,{key:`${p.title}-${u}`,...p}))),d?k.default.createElement(re,null,k.default.createElement(W,{onClick:i},n.close)):null)}),Zt=()=>{let{purchaseType:e,fungible:o,onClose:r,ownerPublicKey:n,legacyProviders:i,purchaseAmount:d,context:p}=L();if(!o)throw new Error("No fungible asset selected");let{name:u,symbol:q,caip19:_}=o,{chainId:F}=_,{t:v}=E(),V=(0,k.useMemo)(()=>({close:v("commandClose"),buy:v("buyAssetInterpolated",{tokenSymbol:q})}),[v,q]),I=async y=>{let K={chainId:F,resourceType:"address",address:n},b=e==="currency",ee={...b?{fiatAmount:d}:{tokenAmount:d},providerID:y,userAddresses:[K],defaultToken:_,clientPlatform:"web"},T={data:{chainId:he.getChainID(F),networkId:F,providerId:y,purchaseAmount:d,isFiatDenominated:b,asset:{name:u,symbol:q,type:"fungible"}}};try{let h=await Ne(ee);eo(h,"fiatOnrampProviderSelected",T)}catch(h){fe.captureError(h,"onRamp")}},x=i.map(y=>({title:y.name,description:y.description,circleColor:y.fiatRampProviderAsset.circleColor,icon:k.default.createElement("img",{src:y.fiatRampProviderAsset.logoUri}),onClick:async()=>await I(y.providerID),badge:y.badgeText}));return{context:p,fiatRampProviders:x,i18nStrings:V,onClose:r,showClose:p==="home"}},Rt=e=>Math.floor(e/2-Le/2),eo=async(e,o,r)=>{B.capture(o,r),await rt({url:e,type:"popup",focused:!0,width:dt,height:Le,top:Rt(self.screen.height),left:Rt(self.innerWidth)})},to=l.ul`
  height: 460px;
  overflow: scroll;
  padding-bottom: 64px;
`,oo=l.div`
  padding: ${e=>e.context==="publicFungible"?"16px":"0"};
`;var Mn=()=>{let{t:e}=E(),{pushDetailView:o}=Y(),[r,n]=(0,t.useState)(void 0),i=L(),{quickSelectDenominations:d,minPurchaseAmount:p,maxPurchaseAmount:u,context:q,purchaseType:_,currencySymbol:F,fungible:v,onClose:V,ownerPublicKey:I,purchaseAmount:x,setState:y,paymentMethod:K,provider:b,checkoutQuoteType:ee}=i,T=parseFloat(x),h=_==="currency",{name:D,symbol:C,decimals:Ce,caip19:ae,logoURI:Lt}=v,ce=ae.chainId,{data:qt=""}=et(c=>c?.name),{data:Ue}=nt({query:{data:ae}}),P=Ue?Ue?.usd:void 0,G=(0,t.useMemo)(()=>{if(r)return!1;let c=x.length>0,R=T>0,$=Number.isFinite(T);return c&&R&&$},[r,x,T]),Dt=(0,t.useMemo)(()=>{if(!P)return`??? ${C}`;if(h){let c=it.get(ce).formDisplayPrecision,R=me(T,P,c),$=at(R,c);return x===""?`0 ${C}`:$.length+(C?.length??0)<15?`~${$} ${C}`:`~${$.substring(0,8)}... ${C}`}return x===""?"$0.00":`~${Ye(Me(T,P))}`},[ce,x,T,h,C,P]),le=Xe(x),Nt=(0,t.useCallback)(c=>{let R=parseFloat(c),$=h?p:me(p,P??0,ve),Ke=h?u:me(u,P??0,ve),Ht=R<$,$t=R>Ke,Ge=Ht?e("buyAssetScreenMinPurchasePriceInterpolated",{amount:h?`${p} ${F.toUpperCase()}`:`${$} ${C}`}):$t?e("buyAssetScreenMaxPurchasePriceInterpolated",{amount:h?`${u} ${F.toUpperCase()}`:`${Ke} ${C}`}):void 0;y({...i,purchaseAmount:c,checkoutQuoteType:"recommended"}),n(Ge||void 0)},[i,F,u,p,y,h,C,e,P]),Ut=(0,t.useCallback)(c=>{y({...i,currencySymbol:"usd",purchaseAmount:c,purchaseType:"currency",checkoutQuoteType:"recommended"}),n(void 0)},[i,y]),Qt=(0,t.useCallback)(()=>{if(!P)return;let c=h?me(T,P,Ce):Me(T,P);y({...i,purchaseAmount:c.toString(),purchaseType:h?"token":"currency"}),n(void 0)},[i,Ce,T,y,h,P]),{data:[te]}=Ze(["enable-fiat-ramp-v2"]),Se=(0,t.useMemo)(()=>({..._==="currency"?{fiatAmount:le}:{tokenAmount:le},token:ae,destinationAddress:{address:I,chainId:ae.chainId,resourceType:"address"}}),[ae,le,I,_]),{version:Qe}=chrome.runtime.getManifest(),Fe=ee==="selected",Ae=!Fe&&G&&!!le,{data:ke,isLoading:Oe,isError:He}=pt({"x-client-platform":"web","x-client-app-version":Qe,"x-client-locale":X.language},{...Se,paymentMethodId:K?.id,providerId:b?.id},te&&Ae),N=Fe?K:ke?.paymentMethod,se=Fe?b:ke?.provider,$e=(0,t.useCallback)(()=>{y({...i,paymentMethod:N}),o(t.default.createElement(_t,null))},[i,o,N,y]),Be=(0,t.useMemo)(()=>{if(te)return Ae&&Oe?{type:"base",id:"recommended-quote-loading",topLeft:{text:e("buyThirdPartyScreenLoadingQuote"),before:t.default.createElement("div",{className:f({minHeight:24,width:0})})},topRight:{after:t.default.createElement(ut,{diameter:20})},disabled:!0}:!G||!N||!se||He?{type:"drawer",id:"no-quote",topLeft:{text:e("buyThirdPartyScreenChoseQuote"),before:t.default.createElement("div",{className:f({minHeight:24,width:0})})},disabled:!0,onClick:()=>null}:{type:"drawer",id:"selected-quote",onClick:$e,topLeft:{text:N?.name,before:N?.assets?.icon?t.default.createElement(be,{src:N?.assets?.icon,width:24,height:24}):void 0},topRight:{text:se?.name}}},[te,$e,G,Ae,He,Oe,N,se,e]),[We,je]=(0,t.useState)(!1),ze=te?G&&(!!ke||!!K&&!!b):G,Ot=(0,t.useMemo)(()=>({...Se,paymentMethodId:N?.id||"",providerId:se?.id||""}),[Se,N?.id,se?.id]),Ve=async c=>{if(ze)if(c&&c.preventDefault(),B.capture("fiatOnrampAmountSelected",{data:{networkId:ce,chainId:he.getChainID(ce),asset:{name:D,symbol:C,type:"fungible"}}}),y({...i,price:P??0}),te){je(!0);try{let{url:R}=await qe({"x-client-platform":"web","x-client-app-version":Qe,"x-client-locale":X.language},Ot);await ot({url:R})}catch(R){fe.captureError(R,"onRamp")}je(!1)}else o(t.default.createElement(Et,null))};return t.default.createElement(ro,{context:q},t.default.createElement(io,null,t.default.createElement(j,null,e("buyAssetInterpolated",{tokenSymbol:C})),t.default.createElement(no,{iconUrl:Lt,width:94,alt:D??""}),t.default.createElement(ao,null,t.default.createElement(Pt,{name:qt,publicKey:I})),t.default.createElement(so,{onSubmit:Ve},t.default.createElement(lo,null,t.default.createElement(ht,{value:x,onKeyPress:c=>!G&&c.key==="Enter"&&c.preventDefault(),onUserInput:Nt,placeholder:e("amount"),warning:!!r,decimalLimit:Ce}),t.default.createElement(mo,null,h?"USD":C)),r?t.default.createElement(oe,{color:"#EB3742",size:16,textAlign:"left"},r):t.default.createElement(ie,{justify:"space-between"},t.default.createElement(yo,null,t.default.createElement(fo,{onClick:Qt},P?t.default.createElement(t.default.Fragment,null,Dt,P===0?null:t.default.createElement(lt,{width:13,height:13})):`??? ${C}`)),t.default.createElement(po,null,d.map(c=>t.default.createElement(co,{key:c,fontSize:12,fontWeight:600,borderRadius:"25px",theme:x===c?"primary":"secondary",onClick:()=>Ut(c)},"$",c)))))),Be&&t.default.createElement("div",{className:f({marginBottom:16,width:"100%"})},t.default.createElement(xe,{rows:[Be]})),t.default.createElement(uo,{primaryText:e(te?"commandBuy":"commandNext"),primaryTheme:G?"primary":"default",primaryDisabled:!ze||We,onPrimaryClicked:Ve,secondaryText:e("commandCancel"),onSecondaryClicked:V,primaryLoading:We}))},ro=l(J).attrs({justify:"space-between"})`
  height: 100%;
  padding: ${e=>e.context==="publicFungible"?"16px":"0"};
`,io=l(J).attrs({align:"center"})`
  flex: 1;
`,no=l(xt)`
  margin: 20px 0;
`,ao=l(ie)`
  cursor: not-allowed;
  padding: 12px 15px;
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 6px;
  box-shadow: inset 0px 0px 4px rgba(0, 0, 0, 0.25);
  margin-bottom: 10px;
  p:first-child {
    margin-right: 6px;
  }
`,so=l.form`
  width: 100%;
`,mo=l(oe).attrs({size:16,color:"#777777",lineHeight:27})`
  position: absolute;
  right: 12px;
  top: calc(50% - 27px / 2);
  display: flex;
  align-items: center;
`,po=l.div`
  display: flex;
  flex-direction: row;
`,co=l(W)`
  margin: 0px 2px 0px 2px;
  padding: 4px 12px 4px 12px;
`,lo=l.div`
  position: relative;
  margin-bottom: 10px;
`,uo=l(yt)`
  width: 100%;
`,yo=l.div`
  align-self: start;
  width: 50%;
`,fo=l(oe).attrs({size:14,color:"#777777",hoverColor:"#AB9FF2"})`
  display: flex;
  align-items: center;
  &:hover {
    svg {
      fill: #ab9ff2;
    }
  }
  svg {
    fill: #777777;
    margin-left: 4px;
  }
`;export{Ct as a,Wt as b,Te as c,jt as d,L as e,Mn as f};
