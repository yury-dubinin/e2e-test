import{a as er,b as or,c as X}from"./chunk-VPXMNJOS.js";import{a as Un,b as be,c as _n}from"./chunk-HLP5EEDN.js";import{a as Ln}from"./chunk-43CKPY5D.js";import{a as qn}from"./chunk-PK6WRZ47.js";import{d as R,f as Sn,h as Cn}from"./chunk-IGBPBJS3.js";import{d as En,e as Mn,f as Fn,h as zn,i as Gn,j as Q,k as $n,l as jn,m as Z,n as Jn,p as Yn}from"./chunk-K44DQOSB.js";import{b as Kn,c as he,d as ee,e as oe,f as Te}from"./chunk-2H36JXZX.js";import"./chunk-VETEAMTK.js";import"./chunk-WZ7EKXIB.js";import"./chunk-4F52HJNC.js";import"./chunk-OILLFGJN.js";import{a as ot}from"./chunk-UWQVMEE4.js";import"./chunk-UG36FTUI.js";import{c as Pn}from"./chunk-PZLCHVHJ.js";import"./chunk-NRQGEP3J.js";import"./chunk-4S56I3J4.js";import"./chunk-CYZ74O6J.js";import"./chunk-JQQUUSH2.js";import"./chunk-S366KFSE.js";import"./chunk-GTS5E7LO.js";import"./chunk-SYMRC4AP.js";import"./chunk-354SN5AZ.js";import"./chunk-UMXXII74.js";import"./chunk-IPG2S7ZF.js";import"./chunk-N5ZGUDXJ.js";import"./chunk-IE2CINMV.js";import"./chunk-O6LPORXM.js";import"./chunk-FQEO53Q7.js";import"./chunk-YML3RMB7.js";import"./chunk-C6XKDXF4.js";import"./chunk-6TM7UJPN.js";import"./chunk-TEDKHQ6I.js";import"./chunk-KLAGLWLU.js";import"./chunk-5CR56F4P.js";import"./chunk-IB7UF4X6.js";import{a as Nn}from"./chunk-YO7AFFW5.js";import"./chunk-3S6ORMD7.js";import"./chunk-7HOFAWG5.js";import"./chunk-PLCKHDK3.js";import"./chunk-6LXDUOIB.js";import"./chunk-MDQQE27Q.js";import{b as ye,c as Dt}from"./chunk-CZC7LOIE.js";import"./chunk-V5HJYMXJ.js";import{f as ro,q as Wn}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import{a as xo}from"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import{c as Rn}from"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import{y as Fe,z as ne}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as bt}from"./chunk-JQSMP2U7.js";import{a as Ro}from"./chunk-7ZDPJAUC.js";import{a as Bo,c as no,p as In}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-JHJLW3YA.js";import"./chunk-2OUSFATI.js";import"./chunk-QSY3A4J6.js";import{b as uo,c as go,j as ze}from"./chunk-U5GOBD2Y.js";import{b as on}from"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import{a as Hn,b as Vn,c as Zn}from"./chunk-YMXCED7D.js";import{b as Qn}from"./chunk-JOOIVSPU.js";import{b as On}from"./chunk-OMHIKLMS.js";import{e as ke,f as vn}from"./chunk-MLAFUF6V.js";import{c as hn}from"./chunk-CAX63KUB.js";import"./chunk-RZVI54SU.js";import"./chunk-BRQMZKX2.js";import"./chunk-ICR7ECHM.js";import"./chunk-SDQFBK4G.js";import"./chunk-AENF63HN.js";import"./chunk-ZJTWFWE3.js";import"./chunk-ZHACRE4R.js";import"./chunk-B3SQHPTA.js";import{A as Yo,B as ho,z as Ko}from"./chunk-U2D7GPOT.js";import{n as yn}from"./chunk-FDMFY2TH.js";import{Bb as At,Lb as mn,Ob as un,Ra as cn,Z as nn,ic as gn,ka as rn,lb as pn,na as sn,ob as ln,ua as an,vb as dn,wc as fn}from"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import{a as Io}from"./chunk-U4OVRE4G.js";import{a as Xn}from"./chunk-QK4PPFHG.js";import{c as kt}from"./chunk-Y6EZT3LZ.js";import{a as Dn}from"./chunk-JTW2FZNL.js";import{a as Bn}from"./chunk-B42X32Z2.js";import{Ra as wo,Sa as Xo,Va as kn,q as Qo,t as An,wb as Zo}from"./chunk-KB2UMCDM.js";import{A as So,B as Co,C as Le,E as u,d as xn,m as Tn,p as s,q as et,y as bn}from"./chunk-OJG7N72N.js";import{a as si,b as tn}from"./chunk-AJXONBM4.js";import"./chunk-LR3UNZEP.js";import"./chunk-ZHWDN4FA.js";import"./chunk-7FZROKRY.js";import"./chunk-B3RYBV57.js";import{a as vt,f as yo,i as Xt}from"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import{e as wn}from"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import{b as Zt,c as en,e as B}from"./chunk-D3AP5534.js";import{a as ai}from"./chunk-RSNIE4RH.js";import{k as ae}from"./chunk-ET4WBMMI.js";import{s as Jo}from"./chunk-OY2GAEXY.js";import{p as fo}from"./chunk-T2EVB3DU.js";import{$a as $o,C as Ot,Ea as ci,I as Ht,K as Vt,Ka as $t,Ma as Ee,O as It,Oa as j,Qd as Qt,ba as Tt,cc as Fo,dc as jo,md as Yt,nc as jt,sc as Jt,wc as Kt,yd as se}from"./chunk-Q5O4STUM.js";import{G as K,t as Me,u as ie}from"./chunk-OA2I74DP.js";import{B as _t,K as Wt,S as Go,a as No,v as O}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as T}from"./chunk-IVQ3W7KJ.js";import{D as mo,F as zt,L as Gt,O as E,ta as Je}from"./chunk-FJ67REU6.js";import{e as xt}from"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as k}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as x,h as l,m as Buffer,n as d}from"./chunk-FPMOV6V2.js";l();d();var g=x(k());l();d();var pe=x(k());l();d();var io=x(k());var pi="calc(100% - 16px)",li=s(et.div)`
  width: 100%;
  height: ${pi};
  margin: 0;
  background: #222;
  position: absolute;
  padding: 16px;
  padding-top: 0;
`,di=s.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: ${e=>e.settingsContainerHeight??"100%"};
`,Ke=(e,o)=>{let{pushDetailView:t}=ne(),{isActive:n,showAutoConfirmRow:r,untilDate:i,save:a,settings:c,isAutoConfirmIsTouched:p,loading:m}=zn({origin:new URL(e).origin});return{open:io.default.useCallback(f=>{t(io.default.createElement(li,null,io.default.createElement(Gn,{dappUrl:e}),io.default.createElement(ot,{isLoading:m},io.default.createElement(di,null,io.default.createElement($n,{dappUrl:e,autoConfirmStatusCode:f,networkID:o})))))},[t,e,o,m]),isActive:n,untilDate:i,save:a,settings:c,isAutoConfirmIsTouched:p,showAutoConfirmRow:r}};l();d();var tt=x(k());function Ye({block:e,warnings:o,isLoadingSimulation:t}){let{data:[n]}=Je(["enable-friction-interstitial"]),i=o?.some(m=>m.severity===1)&&n,a="loading";!t&&e?a="block":t||(a="main");let[c,p]=(0,tt.useState)(a);return(0,tt.useEffect)(()=>{p(t?"loading":e?"block":"main")},[e,t]),{showFrictionInterstitial:!!i,initialScreen:a,screen:c,setScreen:p}}l();d();var Pt=x(k());var tr=Qt(e=>({transactionSpeed:"standard",setTransactionSpeed:o=>e({transactionSpeed:o})})),nr="calc(100% - 15px)",mi=s(et.div)`
  width: 100%;
  height: ${nr};
  margin: 0;
  padding: 15px;
  background: #222;
  position: absolute;
`,rr=(e,o)=>{let{status:t,data:n}=pn({networkID:e,enableFallback:!0}),r=tr(m=>m.transactionSpeed),i=tr(m=>m.setTransactionSpeed),{popDetailView:a,pushDetailView:c}=ne(),p;return t!=="error"&&n&&r&&o&&(p=()=>{c(Pt.default.createElement(mi,null,Pt.default.createElement(Ln,{onSelectTransactionSpeed:i,selectedTransactionSpeed:r,networkID:e,transactionUnitAmount:o,closeModal:a,settingsContainerHeight:nr})))}),{transactionSpeed:r,openGasSettings:p}};l();d();var nt=x(k());async function ui(e){try{let o=e.networkID.replace("eip155:",""),t=ie(e.networkID.replace("eip155:",""));if(t?.chainType!=="eip155")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Ethereum Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:"eth_sendTransaction"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function gi(e){try{let o=e.networkID.replace("eip155:",""),t=ie(o);if(t?.chainType!=="eip155")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Ethereum Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:"eth_sendTransaction"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function fi(e,o){return(t,n)=>{let{networkID:r,origin:i}=n,a=(0,nt.useRef)(!1);return(0,nt.useCallback)(async c=>(j.isEVMNetworkID(r)&&!a.current&&("error"in c?await o({networkID:r,origin:i}):await e({networkID:r,origin:i}),a.current=!0),t(c)),[t,r,i])}}var ir=fi(ui,gi);l();d();var V=x(k());l();d();var U=x(k());var yi=s.div`
  background: #2a2a2a;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
`,Mt=s.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
`,ar=s.div`
  width: ${e=>e.size}px;
  height: ${e=>e.size}px;
  overflow: hidden;
  flex: none;
`,cr=s.div`
  flex: 2;
  display: flex;
  align-items: center;
  gap: 8px;
`,hi=s.div`
  flex-shrink: 1;
`,sr=s.div`
  border-bottom: 1px solid #222222;
  border-bottom-width: 1px;
  margin: 0 -16px;
`,rt=({rows:e})=>U.default.createElement(yi,null,U.default.createElement("div",null,e.map((o,t)=>o.type==="AssetChange"?U.default.createElement(U.default.Fragment,{key:`change-row-${t}`},U.default.createElement(wi,{key:`expected-change-${t}`,change:o}),t!==e.length-1&&e.length>1&&U.default.createElement(sr,null)):o.type==="MessageOnly"?U.default.createElement(U.default.Fragment,{key:`change-row-${t}`},U.default.createElement(Si,{key:`expected-change-${t}`,change:o}),t!==e.length-1&&e.length>1&&U.default.createElement(sr,null)):U.default.createElement(Mt,{key:`expected-change-${t}`},U.default.createElement(u,{size:14,weight:500,lineHeight:20,whiteSpace:"pre-line",wordBreak:"break-word",textAlign:"left",color:"WHITE",margin:"0 0 0 8px"},o.fallbackMessage))))),wi=({change:e})=>{let o=e.asset.type==="native"||e.asset.type==="unknown"?"fungible":e.asset.type,t=e.changeText||e.fallbackMessage,n=Xt(e.changeSign);return U.default.createElement(Mt,null,U.default.createElement(cr,null,e.image?U.default.createElement(ar,{size:24,"data-testid":"estimated-change-image"},U.default.createElement(ro,{image:{type:o,src:e.image},size:24})):U.default.createElement("div",{className:Bo({backgroundColor:e.changeSign==="PLUS"?"accentSuccess":e.changeSign==="MINUS"?"accentAlert":"textSecondary",size:24,flex:"none",borderRadius:12,display:"flex",justifyContent:"center",alignItems:"center"})},e.changeSign==="PLUS"&&U.default.createElement(no.Plus,{"data-testid":"estimated-changes-icon-receive",size:16,color:"bgWallet"}),e.changeSign==="MINUS"&&U.default.createElement(no.Send,{"data-testid":"estimated-changes-icon-send",size:16,color:"bgWallet"}),e.changeSign==="EQUAL"&&U.default.createElement(no.Check,{"data-testid":"estimated-changes-icon-check",size:16,color:"bgWallet"})),U.default.createElement(u,{size:14,weight:500,lineHeight:20,whiteSpace:"pre-line",wordBreak:"break-word",textAlign:"left",color:"WHITE"},e.name)),U.default.createElement(hi,null,U.default.createElement(u,{size:14,weight:500,lineHeight:20,whiteSpace:"pre-line",wordBreak:"break-word",color:n,textAlign:"right"},t)))},Si=({change:e})=>U.default.createElement(Mt,null,U.default.createElement(cr,null,e.image&&U.default.createElement(ar,{size:24},U.default.createElement(ro,{image:{type:"fungible",src:e.image},size:24})),!e.image&&e.changeType==="approval"&&U.default.createElement("div",{className:Bo({backgroundColor:"textSecondary",size:24,flex:"none",borderRadius:12,display:"flex",justifyContent:"center",alignItems:"center"})},U.default.createElement(no.Check,{size:16,color:"bgWallet"})),U.default.createElement(u,{size:14,weight:500,lineHeight:20,whiteSpace:"pre-line",wordBreak:"break-word",textAlign:"left",color:"WHITE"},e.message||e.fallbackMessage)));l();d();var re=x(k());var Ci=s.div`
  margin-right: 4px;
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
`,xi=s.div`
  height: 1px;
  background-color: #222222;
`,Ii=s.div`
  padding: 4px;
  display: flex;
  align-items: center;
  cursor: pointer;
`,Ti=s.div`
  display: flex;
  flex-direction: column;
`,vi=s.div`
  background: #2a2a2a;
  border-top-left-radius: ${({isFirstRow:e})=>e?"16px":"0px"};
  border-top-right-radius: ${({isFirstRow:e})=>e?"16px":"0px"};
  border-bottom-left-radius: ${({isLastRow:e})=>e?"16px":"0px"};
  border-bottom-right-radius: ${({isLastRow:e})=>e?"16px":"0px"};
  width: 100%;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: flex-start;
  text-align: left;
`,Ai=s.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  gap: 8px;
  cursor: ${({onClick:e})=>e?"pointer":"auto"};
`,De=({header:e,rows:o=[]})=>{let t=!!e,[n,r]=(0,re.useState)(!t),i=(0,re.useCallback)(()=>{r(!n)},[n]);return re.default.createElement(re.default.Fragment,null,e&&re.default.createElement(Ii,{"data-testid":"toggle-table",onClick:i},re.default.createElement(Ci,null,n?re.default.createElement(Xo,{fill:"#999999"}):re.default.createElement(wo,{fill:"#999999"})),re.default.createElement(u,{color:"#999999",textAlign:"left",size:14,weight:600,lineHeight:17},e)),n&&re.default.createElement(Ti,null,o.map(({label:a,value:c,description:p,onClick:m},y)=>re.default.createElement(re.default.Fragment,{key:`table-row-${a}-${y}`},a?re.default.createElement(vi,{isFirstRow:y===0,isLastRow:y===o.length-1},re.default.createElement(Ai,{onClick:m},re.default.createElement(u,{size:14,weight:400,lineHeight:17,color:"#ffffff"},a),c),p):c,y!==o.length-1&&o.length>1&&re.default.createElement(xi,null)))))};l();d();var Ge=x(k());l();d();var pr=x(ai()),lr=e=>{let{data:o}=zt({cacheTime:0,queryKey:["tabMeta",e],queryFn:async()=>{if(e===void 0)return;let t=await pr.default.tabs.get(e),n=await Cn(e);return{iconUrl:n?.iconUrl??t?.favIconUrl,title:n?.title??t?.title}}});return o??{}};var ki=s.div`
  color: ${({color:e})=>e};
  font-size: 13px;
  font-family: Inter;
  font-weight: 500;
  margin-top: 6px;
  line-height: 16px;
`,bi=s(u).attrs({size:22,weight:600,lineHeight:24,textAlign:"left"})``,Di=s(u).attrs({size:15,color:"#999999",textAlign:"left",lineHeight:20})``,we=e=>{let{title:o,type:t,description:n,domain:r}=e,{t:i}=T(),{originIsBlocklisted:a}=Ko(e.domain),c;c=lr("tabId"in e?e.tabId:void 0).iconUrl,"iconUrl"in e&&e.iconUrl&&(c=e.iconUrl),a&&(c=void 0);function m(f){switch(f){case"APPROVE_TRANSACTION":return"notificationSignatureRequestConfirmTransactionCapitalized";case"APPROVE_TRANSACTIONS":return"notificationSignatureRequestConfirmTransactionsCapitalized";case"SIGN_MESSAGE":return"dappApprovePopupSignMessage";case"CONNECT":return"notificationApplicationApprovalActionButtonConnect";case"SIGN_IN":return"notificationApplicationApprovalActionButtonSignIn"}}let y="#999999";return a&&(y=ye),Ge.createElement(Ro,{margin:"16px 0 8px 0"},Ge.createElement(bt,null,Ge.createElement(ro,{image:{type:"dapp",src:c},size:56}),Ge.createElement(Ro,{margin:"0 0 0 8px"},Ge.createElement(bi,null,o||i(m(t))),r&&Ge.createElement(ki,{color:y},O(r??"")))),n&&Ge.createElement(bt,{margin:"8px 0 0 0"},typeof n=="string"?Ge.createElement(Di,null,n):n))};l();d();var st=x(k());l();d();var Qe=s.div`
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 16px;
`,it=s.div`
  margin-left: 16px;
`,dr=s(ro)`
  margin-right: 4px;
`,mr=s(u)`
  &:hover {
    color: #ab9ff2;
  }
`,ur=s.div`
  margin-left: 8px;
`;var Ue=e=>{let{t:o}=T(),t=j.getChainName(e),n="solana";switch(t){case"Solana":n="solana";break;case"Ethereum":n="ethereum";break;case"Polygon":n="polygon";break;case"Base":n="base";break;case"Bitcoin":n="bitcoin";break}let r=st.default.createElement(Qe,null,st.default.createElement(dr,{image:{type:"network",preset:n},size:16}),st.default.createElement(u,{size:14,weight:400,lineHeight:17,color:"#999999"},t));return{label:o("notificationTransactionApprovalNetwork"),value:r}};var Ei=s.div`
  margin-top: 24px;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Pi=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 8px;
  margin-top: 16px;
`,Mi=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Ni=s.div`
  display: flex;
  justify-content: center;
  margin: 16px 0;
`,gr=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  padding: 16px 0 8px;
`,fr=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Fi=s(he)`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`,To=V.default.memo(({advancedRows:e=[],confirmApproval:o,denyApproval:t,hasSimulationFailed:n,numTransactions:r,domain:i,rows:a=[],networkFeeRows:c=[],isLoading:p,isErrorNetworkFee:m,isErrorNativeTokenBalance:y,simulationResults:f,simulationWarnings:I,tabId:b,icon:w,networkID:q,showFriction:P,showConfirmAnyway:D})=>{let{t:h}=T(),C=Ue(q),A=I.length>0||m||y||n,H=I.some(S=>S.severity===1),L=f.length===0,W=!n&&!(L&&A),F=(0,V.useMemo)(()=>{let S=[{text:h(o?"commandCancel":"commandClose"),onClick:t,testID:"secondary-button"}];return!P&&!D&&o&&S.push({text:h("commandConfirm"),theme:H||n?"warning":"primary",onClick:()=>o(),disabled:p,testID:"primary-button"}),S},[o,t,H,n,P,D,p,h]);return V.default.createElement(ee,null,V.default.createElement(Z,null),V.default.createElement(Fi,null,V.default.createElement("div",null,V.default.createElement(we,{domain:i,type:r&&r>1?"APPROVE_TRANSACTIONS":"APPROVE_TRANSACTION",tabId:b,iconUrl:w,description:h("notificationBalanceChangesText")}),A&&V.default.createElement(Ei,{"data-testid":"warning-container"},I.map((S,M)=>V.default.createElement(Q,{message:S.message,variant:S.severity,key:`simulation-warning-${M}`})),n&&V.default.createElement(Q,{message:h("notificationFailedToScan"),variant:1,"data-testid":"simulation-failed"}),y&&V.default.createElement(Q,{message:h("nativeTokenBalanceErrorWarning"),variant:3}),m&&V.default.createElement(Q,{message:h("gasEstimationErrorWarning"),variant:3})),V.default.createElement(Pi,null,W&&V.default.createElement(rt,{rows:f}),V.default.createElement(De,{rows:[C,...c,...a]}),e.length>0&&V.default.createElement(De,{header:h("notificationAdvancedDetailsText"),rows:[...e]}))),V.default.createElement(Ni,null,V.default.createElement(Mi,{color:"#999999"},h("notificationConfirmFooter")))),V.default.createElement(oe,null,V.default.createElement(Le,{buttons:F}),P&&o&&V.default.createElement(gr,null,V.default.createElement(fr,{hoverColor:ye,onClick:o,color:"#777777"},h("commandConfirmUnsafe"))),D&&o&&!P&&V.default.createElement(gr,null,V.default.createElement(fr,{hoverColor:"#ab9ff2",onClick:o,color:"#777777"},h("commandConfirmAnyway")))))});l();d();var ge=x(k());var Bi=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})`
  margin-top: 16px;
  margin-bottom: 8px;
`,Ri=s.div`
  margin-top: 16px;
`,qi=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  padding: 16px 0 8px;
`,Li=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Ui=s(he)`
  display: flex;
  flex-wrap: wrap;
  align-content: space-between;
  padding: 16px 16px;
`,_i=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Wi=s(u).attrs({size:28,weight:600,lineHeight:32,textAlign:"left",letterSpacing:"-2%"})``,Oi=s.div`
  color: ${ye};
  font-size: 13px;
  font-family: Inter;
  font-weight: 500;
  line-height: 16px;
`,_e=({origin:e,onConfirm:o,onClose:t,warningMessage:n})=>{let{t:r}=T();return ge.default.useEffect(()=>{B.capture("blockScreenSeenByUser",{data:{warningMessage:n,url:e}})},[e,n]),ge.default.createElement(ee,{"data-testid":"blocklist-connect-request"},ge.default.createElement(Z,null),ge.default.createElement(Ui,null,ge.default.createElement("div",null,ge.default.createElement(_i,null,ge.default.createElement(Zo,{width:36,height:36}),ge.default.createElement(Wi,null,r("maliciousRequestBlockedTitle")),ge.default.createElement(Oi,null,O(e))),n&&ge.default.createElement(Ri,null,ge.default.createElement(Q,{message:n,variant:1})),ge.default.createElement(Bi,{color:"#FFFFFF"},r("maliciousRequestBlocked")))),ge.default.createElement(oe,null,ge.default.createElement(So,{onClick:t},r("commandClose")),ge.default.createElement(qi,null,ge.default.createElement(Li,{hoverColor:ye,onClick:o,color:"#777777"},r("commandProceedAnywayUnsafe")))))};l();d();var ce=x(k());l();d();var so=x(k());var yr=({setRiskAcknowledged:e})=>{let{t:o}=T(),[t,n]=so.useState(!1),r=()=>{n(a=>!a)};so.useEffect(()=>{e(t)},[t,e]);let i=Bo({textAlign:"left"});return so.createElement(Hi,{onClick:r,"data-testid":"acknowledge--button"},so.createElement(In,{checked:t,onChange:r,label:{text:o("maliciousRequestAcknowledge"),color:"accentAlert",className:i},variant:{shape:"square",theme:"alert"}}))},Hi=s.button`
  background-color: ${Go(ye,.1)};
  border: none;
  border-radius: 8px;
  padding: 16px;
  display: flex;
  flex-direction: row;
  width: 100%;
  cursor: pointer;
`;var Vi=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})`
  margin-top: 16px;
  margin-bottom: 8px;
`,zi=s.div`
  margin-top: 16px;
`,Gi=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,$i=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin-bottom: 8px;
`,ji=s(he)`
  display: flex;
  flex-wrap: wrap;
  align-content: space-between;
  padding: 16px 16px;
`,Ji=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Ki=s(oe)`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,Yi=s(u).attrs({size:28,weight:600,lineHeight:32,textAlign:"left",letterSpacing:-.56})``,Qi=s.div`
  color: #999999;
  font-size: 13px;
  font-family: Inter;
  font-weight: 500;
  line-height: 16px;
`,Xe=({origin:e,onConfirm:o,onClose:t,onBack:n,warningMessage:r})=>{let[i,a]=ce.default.useState(!1),{t:c}=T();return ce.default.createElement(ee,{"data-testid":"friction-notifictaion"},ce.default.createElement(Z,null),ce.default.createElement(ji,null,ce.default.createElement("div",null,ce.default.createElement(Ji,null,ce.default.createElement(Zo,{width:36,height:36}),ce.default.createElement(Yi,null,c("maliciousRequestAreYouSure")),ce.default.createElement(Qi,null,O(e))),r&&ce.default.createElement(zi,null,ce.default.createElement(Q,{message:r,variant:1})),ce.default.createElement(Vi,{color:"#FFFFFF"},c("maliciousRequestFrictionDescription")))),ce.default.createElement(Ki,{plain:!0},ce.default.createElement(yr,{setRiskAcknowledged:a}),ce.default.createElement(Le,{buttons:[{text:c("commandBack"),onClick:n},{text:c("commandClose"),onClick:t}]}),ce.default.createElement($i,null,ce.default.createElement(Gi,{onClick:i?o:void 0,color:i?ye:Go(ye,.5)},c("commandYesConfirmUnsafe")))))};l();d();var N=x(k());l();d();var z=x(k());var hr=96,Xi=s.div`
  background: #2a2a2a;
  border-radius: ${({isInTable:e})=>e?"0 0 16px 16px":"16px"};
  overflow: hidden;
  position: relative;
`,Zi=s.div`
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: ${({isOverflow:e})=>e?"pointer":"auto"};
`,es=s.div`
  position: relative;
  overflow-wrap: break-word;
  max-height: ${({isOpen:e})=>e?"none":`${hr}px`};

  &:after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    height: 100%;
    width: 100%;
    background: ${({isOverflow:e})=>e?"linear-gradient(to top, #2a2a2a, transparent)":"none"};
    transition: background 200ms ease;
    display: ${({isOpen:e})=>e?"none":"block"};
  }
`,os=s.div`
  padding: ${({isOpen:e,isOverflow:o})=>!o||e?"0 16px 16px 16px":"0 16px"};
`,ts=s(u)`
  pre {
    text-align: left;
    font-size: 14px;
    font-weight: 400;
    line-height: 17px;
    color: #999999;
    white-space: pre-wrap;
  }
`,ns=s.div`
  margin-right: 4px;
`,rs=s.div`
  display: flex;
  width: 100%;
`,is=s.div``,ss=s(An)`
  &:hover {
    path {
      stroke: #ffffff;
    }
  }
`,at=z.default.memo(({message:e,allowCopy:o,isInTable:t=!1,header:n})=>{let{t:r}=T(),i=(0,z.useRef)(null),[a,c]=(0,z.useState)(!1),[p,m]=(0,z.useState)(!1),{copied:y,copy:f}=Rn(e),I=(0,z.useCallback)(()=>{f(),Pn.success(r("notificationMessageCopied"))},[f,r]),b=(0,z.useCallback)(()=>{c(!a)},[a]);return(0,z.useEffect)(()=>{if(i.current){let w=i.current.scrollHeight>hr;m(w)}},[e,a]),z.default.createElement(Xi,{isInTable:t},z.default.createElement(Zi,{isOverflow:p,onClick:p?b:void 0},z.default.createElement(rs,null,p&&z.default.createElement(ns,{"data-testid":"toggle"},a?z.default.createElement(Xo,null):z.default.createElement(wo,null)),z.default.createElement(u,{textAlign:"left",size:14,weight:400,lineHeight:17,wordBreak:"break-word"},n)),o&&z.default.createElement(is,{onClick:w=>{w.stopPropagation(),I()}},z.default.createElement(ss,{copied:y,fill:"#999999","data-testid":"copy-icon"}))),z.default.createElement(es,{isOpen:a,isOverflow:p},z.default.createElement(os,{isOpen:a,isOverflow:p},z.default.createElement("div",{ref:i},z.default.createElement(ts,null,z.default.createElement("pre",null,e))))))});var wr=s.div`
  background: #2a2a2a;
  border-radius: 16px;
`,as=s.div`
  border-radius: 16px 16px 0 0;
  padding: 12px 16px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  gap: 8px;
  align-items: center;
  background: #2a2a2a;
  color: #999999;
`,cs=s.div`
  padding-top: 0px;
  padding-bottom: 12px;
  padding-left: 18px;
  padding-right: 18px;
  border-top: 1px solid #222222;

  > * {
    margin-top: 12px;
  }
`,Sr=s.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`,ps=s.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  cursor: pointer;
`,ls=s.div`
  height: 8px;
  background-color: #222222;
`,vo=({parsedInstructions:e})=>e.map(({title:o,rowItems:t},n)=>N.default.createElement(N.default.Fragment,null,N.default.createElement(ws,{key:`instruction-row-${n}`,title:o,rowItems:t}),n!==e.length-1&&e.length>1&&N.default.createElement(ls,null)));var ds=({detailName:e,detailValue:o,errorObject:t})=>{let{t:n}=T(),r=t!==void 0;return N.default.createElement(us,{style:{flexDirection:"column"}},N.default.createElement("div",{style:{display:"flex",justifyContent:"space-between",width:"100%"}},N.default.createElement(fs,{size:14,lineHeight:17,wordBreak:"break-word",textAlign:"left"},n(`siwsFieldLable_${e}`)),N.default.createElement(gs,{size:14,lineHeight:17,wordBreak:"break-word",textAlign:"right",style:{width:"70%"}},e==="resources"?o.join(`
`):o)),r&&e in t&&N.default.createElement(u,{color:r&&e in t?Dt:"default",size:12.5,style:{marginTop:8,textAlign:"left"}},n(t[e])))},ct=({signInData:e,errorObject:o})=>{let{t}=T(),[n,r]=(0,N.useState)(!1),i=(0,N.useCallback)(y=>{r(!n),setTimeout(()=>{!n&&y.target.scrollIntoView({behavior:"smooth",block:"start"})},1)},[n]),a=y=>y.map(([f,I])=>N.default.createElement(ds,{detailName:f,detailValue:I,errorObject:o})),c=o!==void 0,p=Object.entries(e).filter(([y,f])=>y!=="statement"),m=n?p:p.filter(([y,f])=>o&&y in o);return N.default.createElement(N.default.Fragment,null,N.default.createElement(ms,{isSticky:n,onClick:i,isCollapsible:!0},N.default.createElement(ys,{isExpanded:n},N.default.createElement(wo,{fill:"#999999"})),N.default.createElement(u,{color:"#999999",textAlign:"left",size:14,weight:600,lineHeight:17},t("notificationAdvancedDetailsText")),c&&N.default.createElement(u,{color:Dt,textAlign:"left",size:14,weight:400,lineHeight:17},"(",t("siwsErrorNumIssues",{n:Object.keys(o).length}),")")),N.default.createElement(wr,null,a(m)))},ms=s.div`
  border-radius: 16px 16px 0 0;
  display: flex;
  flex-direction: row;
  gap: 4px;
  transition:
    box-shadow 0.2s ease,
    color 0.2s ease;
  scroll-margin-top: 10px;

  ${({isCollapsible:e})=>e&&`
    cursor: pointer;
    :hover {
      color: #ffffff;
    }
  `}

  ${({isSticky:e})=>e&&`
    box-shadow: 0px 81px 33px rgba(0, 0, 0, 0.02), 0px 46px 27px rgba(0, 0, 0, 0.08), 0px 20px 20px rgba(0, 0, 0, 0.13), 0px 5px 11px rgba(0, 0, 0, 0.15), 0px 0px 0px rgba(0, 0, 0, 0.15);
    position: sticky;
    top: 0;
    z-index: 1000;
  `}
`,us=s.div`
  padding: 14px 16px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: flex-start;
  border-top: 1px solid #222222;
`,gs=s(u)`
  flex-shrink: 1;
`,fs=s(u)`
  flex-shrink: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,ys=s.div`
  cursor: pointer;
  transition: background-color 0.2s ease;

  :hover {
    background-color: #333333;
  }

  svg {
    color: currentColor;
    position: relative;
    fill: currentColor;
    transition: transform 0.1s ease-in-out;
    transform: ${({isExpanded:e})=>e?"rotate(90deg)":"none"};

    * {
      color: currentColor;
    }
  }
`,Ul=s.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 0px;
  gap: 8px;
`,hs=({condition:e,wrapper:o,children:t})=>e?o(t):t,ws=({title:e,rowItems:o})=>N.default.createElement(Ss,{title:e,rowItems:o}),Ss=({title:e,rowItems:o,emptyDescription:t,info:n})=>N.default.createElement(wr,null,!!e&&N.default.createElement(as,null,N.default.createElement(u,{textAlign:"left",size:14,weight:500,lineHeight:17,color:"currentColor"},e),n&&N.default.createElement(qn,{info:n})),N.default.createElement(cs,null,o.map((r,i)=>N.default.createElement(Cs,{key:`${r.value||r.key}-${i}`,item:r})),o.length===0&&N.default.createElement(Sr,null,N.default.createElement(u,{"data-testid":"instruction-row-empty-description",size:14,weight:400,lineHeight:17,whiteSpace:"normal",color:"#EB3742"},t))));function Cs({item:e,key:o}){return N.default.createElement(Sr,{key:o},e.key&&N.default.createElement(u,{size:14,lineHeight:17,color:"#777777"},e.key),e.value.length>200&&N.default.createElement(at,{header:e.key,message:e.value,allowCopy:!0}),e.value.length<=200&&N.default.createElement(hs,{condition:e.link,wrapper:t=>N.default.createElement(ps,{href:e.link},t)},N.default.createElement(u,{size:14,weight:500,lineHeight:20,color:e.link?"#AB9FF2":void 0,whiteSpace:e.key?"normal":"pre-line",wordBreak:"break-word",textAlign:"left"},e.value)))}l();d();var Ze=x(k());var pt=(e,o,t,n,r="#999999",i,a,c)=>[{label:e("bottomSheetNetworkFeeRow"),onClick:c,value:Ze.default.createElement(Qe,null,Ze.default.createElement(u,{size:14,weight:400,lineHeight:17,whiteSpace:"normal",wordBreak:"break-word","data-testid":"transactionFee",color:r},t&&!n?Ze.default.createElement(xo,{width:"75px","data-testid":"network-fee-loading",height:"8px",borderRadius:"8px",backgroundColor:"#484848"}):o),c&&Ze.default.createElement(it,null,Ze.default.createElement(Qo,null))),description:i&&Ze.default.createElement(u,{size:12,weight:400,lineHeight:14,color:a,textAlign:"left"},i)}],Cr=(e,o)=>o?[{label:e("bottomSheetEstimatedTimeRow"),value:Ze.default.createElement(u,{size:14,weight:400,lineHeight:17,color:"#999999"},o)}]:[];l();d();var eo=x(k());var xs=s(u)`
  font-weight: 400;
  font-size: 14px;
  line-height: 17px;
  color: #999999;
  cursor: pointer;
`,Is=s(u)`
  font-weight: 400;
  font-size: 14px;
  line-height: 17px;
  color: #ffdc62;
  cursor: pointer;
`,Ts=s(u).attrs({size:14,weight:400,lineHeight:17,whiteSpace:"normal",wordBreak:"break-word",color:"#999999"})`
  cursor: pointer;
`,Ao=({origin:e,autoConfirmStatusCode:o,networkID:t})=>{let{t:n}=T(),{open:r,isActive:i,untilDate:a}=Ke(e,t),c=()=>{r(o)},m=eo.createElement(Qe,null,o!=null&&o!="DISABLED"&&o!="OK"?eo.createElement(Is,null,eo.createElement(Io,{i18nKey:"autoConfirmUnavailable"})):i(t)&&a?eo.createElement(xs,null,"Until ",_t(a).toLowerCase()):eo.createElement(Ts,{"data-testid":"networkName"},n("notificationAutoConfirmOff")),eo.createElement(it,null,eo.createElement(Qo,null)));return{label:n("notificationAutoConfirm"),value:m,onClick:c}};l();d();var te=x(k());function We({domain:e,type:o,onClose:t,tabId:n,icon:r}){let{t:i}=T(),a=o==="APPROVE_TRANSACTION"||o==="APPROVE_TRANSACTIONS"?i("notificationBalanceChangesText"):void 0;return te.default.createElement(ee,{"data-testid":"scan-loading"},te.default.createElement(Z,null),te.default.createElement(he,null,te.default.createElement(vs,null,te.default.createElement(we,{domain:e,type:o,tabId:n,iconUrl:r,description:a||te.default.createElement(Es,null,te.default.createElement(Ir,{width:270}),te.default.createElement(Ir,{width:320}))}),te.default.createElement(As,null,te.default.createElement(Nt,null),te.default.createElement(Nt,null),te.default.createElement(Nt,null)))),te.default.createElement(oe,null,te.default.createElement(Le,{buttons:[{text:i("commandCancel"),onClick:t,testID:"btn-cancel"},{text:i("commandConfirm"),onClick:()=>!0,disabled:!0,testID:"btn-confirm"}]})))}function Nt(){return te.default.createElement(ks,null,te.default.createElement(bs,null,te.default.createElement(Ds,null),te.default.createElement(xr,null)),te.default.createElement(xr,null))}var vs=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,As=s.div`
  display: flex;
  flex-direction: column;
  border-radius: 16px;
  overflow: hidden;
  gap: 1px;
`,ks=s.div`
  display: flex;
  flex-direction: row;
  padding: 16px;
  background: #2c2d30;
  justify-content: space-between;
`,bs=s.div`
  display: flex;
  flex-direction: row;
  gap: 8px;
`,Ds=s(xo)`
  width: 24px;
  height: 24px;
  border-radius: 100%;
`,xr=s(xo)`
  width: 78px;
  height: 24px;
  border-radius: 16px;
`,Es=s.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 8px;
`,Ir=s(xo)`
  width: ${e=>e.width}px;
  height: 16px;
  background: ${e=>e.theme.skeletonLight};
  border-radius: 16px;
`;var Ps=({transaction:e,maxFeePerGas:o="0x0",maxPriorityFeePerGas:t="0x0",postOutgoingBackgroundResponse:n,requestId:r})=>{let i=mo(),{data:a}=se(),[c,p]=(0,pe.useMemo)(()=>[a?.identifier??"",a?.type==="ledger"],[a]);return{ledgerSignTransaction:(0,pe.useCallback)(async()=>{let y=ke(),I=await(async()=>(e.maxFeePerGas=o,e.maxPriorityFeePerGas=t,ze(i,go),y.sign(c,{chainType:"eip155",signingType:"transaction",message:an(e)}).finally(()=>ze(i,uo))))(),b;switch(I.status){case"success":b={jsonrpc:"2.0",id:r,result:{type:"send",maxFeePerGas:o,maxPriorityFeePerGas:t,signature:I.signature}};break;case"error":b={jsonrpc:"2.0",id:r,error:R.userRejectedRequest(r).error};break}n(b)},[c,o,t,n,e,i,r]),isLedgerAccount:p}},Ms=(e,o,t,n)=>{let{data:r,isLoading:i,isError:a}=ln({networkID:e,multichainTransaction:o,transactionSpeed:t,queryOptions:{refetchInterval:Wt}}),{data:c,isLoading:p}=dn(e,r),m=t?nn.get(e).transactionSpeedDescription(t,!0):void 0,y=m?n(m):"";return{networkFee:mn({networkID:o.networkID,gasEstimation:r,gasEstimationPrice:c}),isLoadingNetworkFee:i||p,gasEstimation:r,isErrorGasEstimation:a,estimatedTime:y}},Tr=e=>{let o=O(e.url.origin),{url:t,requestId:n,icon:r}=e,i=t.origin,a=$t.parse(`eip155:${e.transaction.chainId?parseInt(e.transaction.chainId,16):void 0}`),{t:c}=T(),{data:p,isError:m,isFetched:y,isLoading:f}=ho({networkID:a,url:t.href,userAccount:e.transaction.from,params:{transactions:[e.transaction],method:"eth_sendTransaction"},type:"transaction"}),I=p?.error===yo.INSUFFICIENT_GAS||p?.error===yo.INSUFFICIENT_FUNDS,{screen:b,setScreen:w,showFrictionInterstitial:q}=Ye({block:p?.block,isLoadingSimulation:f&&!y,warnings:p?.warnings}),P=X(),D=ir(P,{networkID:a,origin:i}),h=(0,pe.useCallback)(()=>{D({jsonrpc:"2.0",id:n,error:R.userRejectedRequest(n).error})},[n,D]),C=(0,pe.useMemo)(()=>typeof e.transaction.gas=="string"?new No(e.transaction.gas,16):void 0,[e.transaction.gas]),{transactionSpeed:A,openGasSettings:H}=rr(a,C?{gasLimit:C}:void 0),L={networkID:a,unsignedTransaction:e.transaction},{networkFee:W,isLoadingNetworkFee:F,isErrorGasEstimation:S,gasEstimation:M,estimatedTime:$}=Ms(a,L,A,c),{hasSufficientFunds:ue,nativeTokenSymbol:xe,isLoading:Ne,isError:Pe}=yn(a,"eip155",M,void 0),{maxFeePerGas:J,maxPriorityFeePerGas:Ie}=rn(M||{gasLimit:new No(0),maxFeePerGas:new No(0),maxPriorityFeePerGas:new No(0),networkID:a}),{ledgerSignTransaction:Ae,isLedgerAccount:Re}=Ps({transaction:e.transaction,maxFeePerGas:J,maxPriorityFeePerGas:Ie,postOutgoingBackgroundResponse:D,requestId:n}),{pushDetailView:Po}=ne(),{save:Wo,isAutoConfirmIsTouched:Oo,showAutoConfirmRow:Ho}=Ke(e.url.origin),Mo=(0,pe.useCallback)(async()=>{Oo&&await Wo(),Re?Po(pe.default.createElement(Te,null,pe.default.createElement(be,{ledgerApp:"EVM",ledgerAction:Ae,cancel:h}))):D({jsonrpc:"2.0",id:n,result:{type:"signAndSend",maxFeePerGas:J||"0x0",maxPriorityFeePerGas:Ie||"0x0"}})},[Oo,Wo,Re,Po,Ae,h,D,n,J,Ie]),Ct=(0,pe.useCallback)(()=>{B.capture("userIgnoredKnownMaliciousWarning",{data:{origin:i}}),w("main")},[i,w]),{data:fe}=Jo(),Ve=(0,pe.useCallback)(Vo=>{if(!fe)return"";let zo=fe.explorers[a??Ee.Solana.Mainnet];return fo({endpoint:"address",explorerType:zo,networkID:a??Ee.Ethereum.Mainnet,param:Vo})},[fe,a]),qe=(0,pe.useMemo)(()=>{if(!p||!p.advancedDetails?.advancedRows)return[];let Vo=p.advancedDetails.advancedRows.map(zo=>({title:zo.title,rowItems:zo.items.map(lo=>({key:lo.title,link:lo.isAddress?Ve(lo.value):void 0,value:lo.isAddress?jo(lo.value):lo.value}))}));return Vo.length===0?[]:[{value:pe.default.createElement(vo,{parsedInstructions:Vo})}]},[p,Ve]),ri=Ao({origin:e.url.origin,networkID:e.transaction.chainId?$o(e.transaction.chainId):void 0,autoConfirmStatusCode:e.autoConfirmStatusCode}),Ut=[];if(Ho&&Ut.push(ri),b==="block")return pe.default.createElement(_e,{warningMessage:p?.block?.message??"",origin:i,onConfirm:Ct,onClose:h});let ii={networkID:a,unsignedTransaction:e.transaction};return b==="loading"?pe.default.createElement(We,{type:"APPROVE_TRANSACTION",tabId:e.tabId,icon:r,domain:o,onClose:h}):b==="friction"?pe.default.createElement(Xe,{onClose:h,onConfirm:Mo,onBack:()=>w("main"),origin:i,warningMessage:p?.warnings?.[0]?.message}):pe.default.createElement(To,{advancedRows:qe,confirmApproval:q?()=>w("friction"):Mo,denyApproval:h,hasSimulationFailed:!!m,numTransactions:1,domain:o,rows:Ut,simulationResults:p?.expectedChanges??[],simulationWarnings:p?.warnings??[],tabId:e.tabId,icon:r,networkID:ii.networkID,showFriction:q,showConfirmAnyway:!q&&I,isErrorNativeTokenBalance:Pe,isErrorNetworkFee:S,isLoading:F&&!S||Ne,networkFeeRows:[...pt(c,W,F,S,ue==="insufficient"?"#EB3742":"#999999",ue==="insufficient"?c("transactionNotEnoughNative",{nativeTokenSymbol:xe}):S?c("gasEstimationCouldNotFetch"):void 0,"#EB3742",H),...Cr(c,$)]})};l();d();var Se=x(k());l();d();var lt=x(k());async function Ns(e){try{let o=e.networkID.replace("eip155:",""),t=ie(e.networkID.replace("eip155:",""));if(t?.chainType!=="eip155")throw new Error(`Failed to capture message signature event analytics: Unsupported Ethereum Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:e.method})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function Fs(e){try{let o=e.networkID.replace("eip155:",""),t=ie(o);if(t?.chainType!=="eip155")throw new Error(`Failed to capture message signature event analytics: Unsupported Ethereum Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:e.method})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function Bs(e,o){return(t,n)=>{let{networkID:r,origin:i,originalMethod:a}=n,c=(0,lt.useRef)(!1);return(0,lt.useCallback)(async p=>{if(j.isEVMNetworkID(r)&&!c.current){let m=a;"error"in p?await o({networkID:r,origin:i,method:m}):await e({networkID:r,origin:i,method:m}),c.current=!0}return t(p)},[t,r,i,a])}}var vr=Bs(Ns,Fs);l();d();var _=x(k());l();d();var ao=x(k());var Ar=(e,o)=>{let{t}=T(),n=(0,ao.useCallback)(()=>{if(e){let i=fo({networkID:o,endpoint:"address",param:e});self.open(i)}},[e,o]),r=ao.default.createElement(Qe,null,ao.default.createElement(mr,{size:14,weight:400,lineHeight:17,color:"#ab9ff2",onClick:n},Fo(e??"",4)),ao.default.createElement(ur,null,ao.default.createElement(kn,{fill:"#999999"})));return e?{label:t("notificationContractAddress"),value:r}:{label:"",value:null}};l();d();var Bt=x(k());var $e=Bt.default.memo(({message:e,isJson:o,isInTable:t=!1,header:n})=>Bt.default.createElement(at,{header:n,message:e,allowCopy:o,isInTable:t})),dt=e=>{let o=e,t=!1;try{let n=JSON.parse(e);o=JSON.stringify(n,null,2),t=!0}catch{}return{formattedMessage:o,isJson:t}};var Rs=s.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 1;
  overflow: auto;
  padding: 0px 16px;
`,qs=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Ls=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 24px;
`,Us=s.div`
  display: flex;
  justify-content: center;
  margin: 16px 0;
`,_s=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  padding: 16px 0 8px;
`,Ws=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Os=s.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 24px;
  gap: 8px;
`,mt=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,kr=e=>{let{t:o}=T(),{data:[t]}=Je(["enable-friction-interstitial"]),{origin:n,message:r,originalMethod:i,advancedDetails:a,tabId:c,icon:p,networkID:m,autoConfirmStatusCode:y,simulationResults:f,scanWarnings:I,scanFailed:b,confirmApproval:w,denyApproval:q}=e,{formattedMessage:P,isJson:D}=dt(r),h=Ue(m),C=Ar(a?.contractAddress,m),{save:A,isAutoConfirmIsTouched:H,showAutoConfirmRow:L}=Ke(n),W=Ao({origin:n,autoConfirmStatusCode:y,networkID:m}),F=["eth_signTypedData_v3","eth_signTypedData_v4"].includes(i??""),S=[];C.value&&S.push(C);let M=!!f&&f?.length>0;M&&S.push({value:_.default.createElement($e,{header:o("notificationMessageHeader"),message:P,isJson:D,isInTable:!0})});let $=async()=>{H&&await A(),w?.()},ue=(I||[]).some(Pe=>Pe.severity===1),xe=t&&ue,Ne=[{text:o("commandCancel"),onClick:q,testID:"secondary-button"}];return xe||Ne.push({text:o("commandConfirm"),theme:ue?"warning":"primary",onClick:$,testID:"primary-button"}),_.default.createElement(ee,null,_.default.createElement(Z,null),_.default.createElement(Rs,null,_.default.createElement("div",null,_.default.createElement(we,{type:"SIGN_MESSAGE",domain:O(n),iconUrl:p,tabId:c}),_.default.createElement(Ls,null,M?_.default.createElement(_.default.Fragment,null,_.default.createElement(mt,{color:"#999999"},o("notificationPermissionRequestText")),_.default.createElement(mt,{color:"#999999"},o("notificationBalanceChangesText"))):_.default.createElement(mt,{color:"#999999"},o("notificationBalanceChangesText"))),_.default.createElement("div",null,(I?.length||b)&&_.default.createElement(Os,null,I&&I?.length>0&&_.default.createElement(_.default.Fragment,null,I.map((Pe,J)=>_.default.createElement(Q,{message:Pe.message,variant:Pe.severity,key:`simulation-warning-${J}`}))),b&&_.default.createElement(Q,{message:o("notificationFailedToScan"),variant:1,"data-testid":"simulation-failed"})),_.default.createElement(qs,null,_.default.createElement("div",{"data-testid":"message"},M?f?_.default.createElement(rt,{rows:f}):null:_.default.createElement($e,{header:o("notificationMessageHeader"),message:P,isJson:D})),_.default.createElement(De,{rows:[h,...L&&F?[W]:[]]}),S.length>0&&_.default.createElement(De,{rows:S,header:o("notificationAdvancedDetailsText")})))),_.default.createElement(Us,null,_.default.createElement(mt,{color:"#999999"},o("notificationConfirmFooter")))),_.default.createElement(oe,null,_.default.createElement(Le,{buttons:Ne}),xe?_.default.createElement(_s,null,_.default.createElement(Ws,{hoverColor:ye,onClick:$,color:"#777777"},o("commandConfirmUnsafe"))):void 0))};l();d();var G=x(k());var Hs=s.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 1;
  overflow: auto;
  padding: 0px 16px;
`,Vs=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,zs=s.div`
  margin-bottom: 24px;
`,Gs=s.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 24px;
  gap: 8px;
`,br=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,$s=s.div`
  display: flex;
  justify-content: center;
  margin: 16px 0;
`,js=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  padding: 16px 0 8px;
`,Js=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Do=e=>{let{t:o}=T(),{data:[t]}=Je(["enable-friction-interstitial"]),{origin:n,message:r,tabId:i,networkID:a,scanWarnings:c,confirmApproval:p,denyApproval:m,scanFailed:y,icon:f}=e,{formattedMessage:I,isJson:b}=dt(r),w=(0,G.useCallback)(async()=>{c?.length&&e.advancedDetails&&e.advancedDetails.errorSignInWithSolana&&await B.capture("userIgnoredSignInWithMessageError",{data:{type:e.advancedDetails.errorSignInWithSolana?.type,format:e.advancedDetails.errorSignInWithSolana?.format,origin:n,error:e.advancedDetails.errorSignInWithSolana?.error}}),p?.()},[c,p,n,e.advancedDetails]),q=Ue(a),P=(c||[]).some(C=>C.severity===1),D=t&&P,h=[{text:o(p?"commandCancel":"commandClose"),onClick:m,testID:"secondary-button"}];return!D&&p&&h.push({text:o("commandConfirm"),theme:P||y?"warning":"primary",onClick:()=>p(),testID:"primary-button"}),G.default.createElement(ee,null,G.default.createElement(Z,null),G.default.createElement(Hs,null,G.default.createElement("div",null,G.default.createElement(we,{type:"SIGN_MESSAGE",domain:O(n),iconUrl:f,tabId:i}),G.default.createElement(zs,null,G.default.createElement(br,{color:"#999999"},o("notificationSignMessageParagraphText"))),G.default.createElement("div",null,(c?.length||y)&&G.default.createElement(Gs,null,c&&c?.length>0&&G.default.createElement(G.default.Fragment,null,c.map((C,A)=>G.default.createElement(Q,{message:C.message,variant:C.severity,key:`simulation-warning-${A}`}))),y&&G.default.createElement(Q,{message:o("notificationFailedToScan"),variant:1,"data-testid":"simulation-failed"})),G.default.createElement(Vs,null,G.default.createElement("div",{"data-testid":"message"},G.default.createElement($e,{header:o("notificationMessageHeader"),message:I,isJson:b})),G.default.createElement(De,{rows:[q]})))),G.default.createElement($s,null,G.default.createElement(br,{color:"#999999"},o("notificationConfirmFooter")))),G.default.createElement(oe,null,G.default.createElement(Le,{buttons:h}),D?G.default.createElement(js,null,G.default.createElement(Js,{hoverColor:ye,onClick:w,color:"#777777"},o("commandConfirmUnsafe"))):void 0))};var Dr=e=>{let{tabId:o,icon:t,url:n,requestId:r,message:i,originalMethod:a,hexChainId:c,autoConfirmStatusCode:p}=e,m=n.origin,y=$o(c),f=(0,Se.useMemo)(()=>Sn(i),[i]),I=mo(),b=X(),w=vr(b,{networkID:y,origin:n.origin,originalMethod:a}),{data:q}=se(),[P,D]=(0,Se.useMemo)(()=>[q?.identifier??"",q?.type==="ledger",q?.addresses],[q]),h=(0,Se.useCallback)(()=>{w({jsonrpc:"2.0",id:r,error:R.userRejectedRequest(r).error}),B.capture("messageSubmissionTransactionBlockedAndClosed",{data:{origin:m}})},[r,m,w]),{pushDetailView:C}=ne(),A=(0,Se.useCallback)(async()=>{let Ne=ke(),J=await(async()=>(ze(I,go),Ne.sign(P,{chainType:"eip155",signingType:"message",message:Buffer.from(i.substring(2),"hex").toString("utf8")}).finally(()=>ze(I,uo))))(),Ie;switch(J.status){case"success":Ie={jsonrpc:"2.0",id:r,result:{approvalType:"hardware",signature:J.signature}};break;case"error":Ie={jsonrpc:"2.0",id:r,error:R.userRejectedRequest(r).error};break}w(Ie)},[P,i,w,I,r]),H=(0,Se.useCallback)(async()=>{D?C(Se.default.createElement(Te,null,Se.default.createElement(be,{ledgerApp:"EVM",ledgerAction:A,cancel:h}))):(B.capture("messageSubmissionTransactionConfirmation",{data:{originalMethod:a}}),w({jsonrpc:"2.0",id:r,result:{approvalType:"user"}}))},[D,a,C,A,h,w,r]),{data:L,isError:W,isLoading:F,isFetched:S}=Yo({networkID:y,url:n.href,type:"message",params:{message:f}},{disabled:a==="personal_sign"}),{screen:M,setScreen:$,showFrictionInterstitial:ue}=Ye({block:L?.block,isLoadingSimulation:F&&!S,warnings:L?.warnings}),xe=(0,Se.useCallback)(()=>{B.capture("userIgnoredKnownMaliciousWarning",{data:{origin:m}}),$("main")},[m,$]);return M==="block"?Se.default.createElement(_e,{warningMessage:L?.block?.message??"",origin:m,onConfirm:xe,onClose:h}):M==="loading"?Se.default.createElement(We,{type:"SIGN_MESSAGE",domain:O(m),onClose:h,tabId:o,icon:t}):M==="friction"?Se.default.createElement(Xe,{onClose:h,onConfirm:H,onBack:()=>$("main"),origin:m,warningMessage:L?.warnings?.[0]?.message}):a==="eth_sign"||a==="personal_sign"?Se.default.createElement(Do,{denyApproval:h,autoConfirmStatusCode:p,message:f,simulationResults:L?.expectedChanges||[],scanWarnings:L?.warnings||[],scanFailed:W,advancedDetails:L?.advancedDetails,confirmApproval:ue?()=>$("friction"):H,networkID:y,origin:m,tabId:o,icon:t}):Se.default.createElement(kr,{denyApproval:h,autoConfirmStatusCode:p,message:f,simulationResults:L?.expectedChanges||[],scanWarnings:L?.warnings||[],scanFailed:W,advancedDetails:L?.advancedDetails,confirmApproval:ue?()=>$("friction"):H,networkID:y,origin:m,tabId:o,icon:t})};l();d();var oo=x(k());l();d();var co=x(k());l();d();var le=x(k());var Er=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Ks=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin: 16px 0;
`,Ys=s.div`
  display: flex;
  flex-direction: column;
`,Qs=s.div`
  margin-bottom: 24px;
`,Xs=s(he)`
  display: flex;
  flex-wrap: wrap;
  align-content: space-between;
`,Zs=s.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 24px;
`,Pr=({tabId:e,icon:o,origin:t,confirmApproval:n,denyApproval:r,originIsBlocklisted:i})=>{let{t:a}=T(),{data:c}=se();return le.default.createElement(ee,null,le.default.createElement(Z,null),le.default.createElement(Xs,null,le.default.createElement("div",null,le.default.createElement(we,{type:"CONNECT",domain:O(t),tabId:e,iconUrl:o}),le.default.createElement(Qs,null,le.default.createElement(Er,{color:"#999999"},a("notificationApplicationApprovalParagraphText"))),le.default.createElement(ot,{isLoading:!1},le.default.createElement(Ys,null,i&&le.default.createElement(Zs,null,le.default.createElement(Q,{message:a("notificationApplicationApprovalWebsiteIsUnsafeWarning"),variant:1})),le.default.createElement(De,{rows:[{label:"Account",value:le.default.createElement(u,{size:14,weight:400,lineHeight:17,color:"#999999"},c?.name)}]})))),le.default.createElement(Ks,null,le.default.createElement(Er,{color:"#999999"},a("notificationApplicationApprovalConnectDisclaimer")))),le.default.createElement(oe,null,le.default.createElement(Co,{primaryText:a("notificationApplicationApprovalActionButtonConnect"),primaryTheme:i?"warning":"primary",secondaryText:a("commandCancel"),onPrimaryClicked:n,onSecondaryClicked:r})))};var ea=s.div.attrs({"data-testid":"loading-wrapper"})`
  display: flex;
  flex-direction: column;
  height: 100%;
  justify-content: center;
  align-items: center;
`,Mr=co.default.memo(({isLoading:e,originIsBlocklisted:o,tabId:t,icon:n,origin:r,confirmApproval:i,denyApproval:a})=>{let[c,p]=co.default.useState(!1);return e?co.default.createElement(ea,null,co.default.createElement(bn,null)):o&&!c?co.default.createElement(_e,{origin:r,onConfirm:()=>{p(!0)},onClose:a}):co.default.createElement(Pr,{tabId:t,origin:r,icon:n,confirmApproval:i,denyApproval:a,originIsBlocklisted:o})});var ut=oo.default.memo(({tabId:e,url:o,icon:t,requestId:n,allowSwitchingAccountsFor:r})=>{let i=o.origin,a=X(),c=0;n!==null&&(c=n);let p=(0,oo.useCallback)(()=>{a({jsonrpc:"2.0",id:c,error:R.userRejectedRequest(n).error})},[n,c,a]),m=(0,oo.useCallback)(()=>{a({jsonrpc:"2.0",id:c,result:null})},[c,a]),y=(0,oo.useCallback)(b=>b.addresses?.every(w=>w.addressType!==r),[r]),{isLoading:f,originIsBlocklisted:I}=Ko(i);return oo.default.createElement(jn,{accountDisabler:y,disableAccountManagement:!0},oo.default.createElement(Mr,{icon:t,isLoading:f,originIsBlocklisted:I,tabId:e,origin:i,confirmApproval:m,denyApproval:p}))});var ni=x(si());l();d();var je=x(k());var oa=ke(),ta=e=>{let{url:o,requestId:t,messageBytes:n,tabId:r,icon:i}=e,a=o.origin,{data:c}=se(),p=c?.identifier??"",{networkID:m,addressType:y}=c?.addresses?.find(h=>j.isBitcoinNetworkID(h.networkID))??{addressType:"bip122_p2wpkh",networkID:Ee.Bitcoin.Mainnet},f=c?.type==="ledger",I=(0,je.useCallback)(async h=>{let C=await oa.sign(p,{chainType:y,signingType:"message",message:h});if(C.status==="error")throw new Error(`[btc provider][${C.type}] ${C.message}`);let A=C.message;if(!A)throw new Error("[btc sign message notification] no message on vault response");return{type:"send",signature:Buffer.from(C.signature,"hex"),signedMessage:A}},[p,y]),{pushDetailView:b}=ne(),w=X(),q=(0,je.useCallback)(()=>{let h=R.userRejectedRequest(t);w(h)},[t,w]),P=(0,je.useCallback)(async()=>{try{let h=await I(n);w(R.result(t,h))}catch(h){let C=R.internalError(t,h.message);w(C)}},[I,n,t,w]),D=(0,je.useCallback)(()=>{f?b(je.default.createElement(Te,null,je.default.createElement(be,{ledgerApp:"Bitcoin",ledgerAction:P,cancel:q}))):w(R.result(t,{type:"signAndSend"}))},[q,f,w,b,t,P]);return{networkID:m,message:Buffer.from(n).toString("utf8"),tabId:r,icon:i,origin:a,requestId:t,confirmApproval:D,denyApproval:q}},Nr=e=>{let o=ta({...e});return je.default.createElement(Do,{...o})};l();d();var Fr=x(ci()),ve=x(k());var na=async({message:e,accountIdentifier:o,addressType:t,inputsToSign:n,finalize:r})=>{let i=await ke().sign(o,{chainType:t,signingType:"transaction",message:Buffer.from(e).toString("hex"),inputsToSign:n,finalize:r});if(i.status==="error")throw new Error(`[btc provider][${i.type}] ${i.message}`);return{type:"send",signature:Buffer.from(i.signature,"hex")}},Br=e=>{let{url:o,requestId:t,message:n,tabId:r,icon:i,inputsToSign:a,finalize:c}=e,p=O(o.origin),m=o.origin,{data:y}=se(),f=y?.identifier??"",{networkID:I,addressType:b,address:w}=y?.addresses?.find(J=>j.isBitcoinNetworkID(J.networkID))??{addressType:"bip122_p2wpkh",networkID:Ee.Bitcoin.Mainnet},q=y?.type==="ledger",{pushDetailView:P}=ne(),D=X(),h=(0,ve.useCallback)(async()=>{try{let J=await na({message:Buffer.from(n,"hex"),accountIdentifier:f,addressType:b,inputsToSign:a,finalize:c});D(R.result(t,J))}catch(J){let Ie=R.internalError(t,J.message);D(Ie)}},[a,f,b,c,n,t,D]),C=(0,ve.useCallback)(()=>{let J=R.userRejectedRequest(t);D(J)},[t,D]),A=(0,ve.useCallback)(()=>{q?P(ve.default.createElement(Te,null,ve.default.createElement(be,{ledgerApp:"Bitcoin",ledgerAction:h,cancel:C}))):D(R.result(t,{type:"signAndSend"}))},[h,D,t,C,q,P]),H=y?.addresses.map(J=>J.address),{isError:L,data:W,isFetched:F,isLoading:S}=ho({networkID:Ee.Bitcoin.Mainnet,type:"transaction",url:o.href,userAccount:w??"",params:{transaction:n,userAddresses:H??[]}}),{screen:M,setScreen:$,showFrictionInterstitial:ue}=Ye({block:W?.block,isLoadingSimulation:S&&!F,warnings:W?.warnings}),xe=(0,ve.useCallback)(()=>{B.capture("userIgnoredKnownMaliciousWarning",{data:{origin:m}}),$("main")},[m,$]),Ne=(0,ve.useMemo)(()=>{let{inputs:J,outputs:Ie}=W?.advancedDetails??{};return!J||!Ie?[]:[{value:ve.default.createElement(vo,{parsedInstructions:[...J.map((Ae,Re)=>({title:`Input #${Re+1}`,rowItems:[{key:"address",value:(H?.includes(Ae.address)?"You \xB7 ":"")+Fo(Ae.address),link:`https://mempool.space/address/${Ae.address}`},{key:"value",value:`${vt(Ae.amount)} BTC`}]})),...Ie.map((Ae,Re)=>({title:`Output #${Re+1}`,rowItems:[{key:"address",value:(H?.includes(Ae.address)?"You \xB7 ":"")+Fo(Ae.address),link:`https://mempool.space/address/${Ae.address}`},{key:"value",value:`${vt(Ae.amount)} BTC`}]}))]})}]},[W,H]),Pe={networkID:I,psbt:Fr.Psbt.fromHex(n),vb:0,inputsToSign:[],psbtChain:void 0};return M==="block"?ve.default.createElement(_e,{warningMessage:W?.block?.message||"",origin:m,onConfirm:xe,onClose:C}):M==="loading"?ve.default.createElement(We,{type:"APPROVE_TRANSACTION",tabId:r,icon:i,domain:p,onClose:C}):M==="friction"?ve.default.createElement(Xe,{onClose:C,onConfirm:A,onBack:()=>$("main"),origin:m,warningMessage:W?.warnings?.[0]?.message}):ve.default.createElement(To,{advancedRows:Ne,confirmApproval:ue?()=>$("friction"):A,denyApproval:C,hasSimulationFailed:L,numTransactions:1,domain:p,simulationResults:W?.expectedChanges??[],simulationWarnings:W?.warnings??[],tabId:r,icon:i,networkID:Pe.networkID,isErrorNativeTokenBalance:!1,isErrorNetworkFee:!1,isLoading:!1,networkFeeRows:[],showFriction:ue})};l();d();var gt=x(k());l();d();var Oe=x(k());function to({origin:e,title:o,children:t,onClose:n,...r}){let{t:i}=T();return Oe.default.createElement(ra,{...r},Oe.default.createElement(ia,null,Oe.default.createElement(sa,null,Oe.default.createElement(no.XCircle,{size:36,color:"accentAlert"}),Oe.default.createElement(aa,null,o),Oe.default.createElement(ca,null,e)),Oe.default.createElement(pa,null,t)),Oe.default.createElement(la,null,Oe.default.createElement(So,{onClick:n},i("commandClose"))))}var ra=s.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
  width: 100%;
  padding: 16px;
`,ia=s.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,sa=s.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,aa=s.h1`
  font-size: 28px;
  font-weight: 600;
  line-height: 32px;
  letter-spacing: -2%;
  color: #fff;
`,ca=s.p`
  font-size: 13px;
  line-height: 16px;
  color: #999999;
`,pa=s.p`
  font-size: 16px;
  line-height: 20px;
  color: #fff;
`,la=s.div`
  display: flex;
  gap: 16px;
`;var Rr=s(u)`
  text-align: left;
  font-size: 16px;
  line-height: 20px;
  strong {
    font-weight: 600;
  }
`,qr=({url:e,connectedChainId:o,messageChainId:t})=>{let{t:n}=T(),r=e.origin;return gt.createElement(to,{"data-testid":"incorrect-chain_id",origin:r,title:n("notificationIncorrectEIP712ChainId"),onClose:()=>self.close()},gt.createElement(Rr,null,n("notificationIncorrectEIP712ChainId")),gt.createElement(Rr,{style:{marginTop:16}},n("notificationIncorrectEIP712ChainIdDescription",{messageChainId:parseInt(t,16),connectedChainId:parseInt(o,16)})))};l();d();var ft=x(k());var Lr=s(u)`
  text-align: left;
  font-size: 16px;
  line-height: 20px;
  strong {
    font-weight: 600;
  }
`,Ur=({hostname:e,enabledChains:o})=>{let{t}=T(),[n,r,i]=o==="testnet"?[t("notificationIncorrectModeInTestnetTitle"),t("notificationIncorrectModeInTestnetDescription",{origin:e}),t("notificationIncorrectModeInTestnetProceed")]:[t("notificationIncorrectModeNotInTestnetTitle"),t("notificationIncorrectModeNotInTestnetDescription",{origin:e}),t("notificationIncorrectModeNotInTestnetProceed")];return ft.createElement(to,{origin:e,title:n,onClose:()=>self.close(),"data-testid":"incorrect-mode"},ft.createElement(Lr,null,r),ft.createElement(Lr,{style:{marginTop:16}},i))};l();d();var de=x(k());var da=s.div`
  display: flex;
  flex-direction: row;
  align-items: center;

  > * {
    margin: 0px ${e=>e.spacing}px;
    text-align: left;
  }
`,ma=s.div`
  margin-bottom: 24px;
`,ua=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,_r=de.default.memo(({tabId:e,url:o,requestId:t})=>{let n=o.origin,r=X(),i=0;t!==null&&(i=t);let a=(0,de.useCallback)(()=>{r({jsonrpc:"2.0",id:i,error:R.userRejectedRequest(t).error})},[t,i,r]);return de.default.createElement(ga,{tabId:e,origin:n,denyApproval:a})}),ga=({tabId:e,origin:o,denyApproval:t})=>{let{t:n}=T(),r=()=>t(o);return de.default.createElement(ee,null,de.default.createElement(Z,null),de.default.createElement(he,null,de.default.createElement(we,{type:"SIGN_MESSAGE",domain:O(o),tabId:e}),de.default.createElement(ma,null,de.default.createElement(ua,{color:"#999999"},n("notificationSignMessageParagraphText"))),de.default.createElement(fa,null,de.default.createElement(Q,{message:n("bottomSheetReadOnlyAccountDescription"),variant:2})),de.default.createElement(Kn,null,de.default.createElement(da,{spacing:4},de.default.createElement(u,{size:14,lineHeight:17,color:"#777"},n("bottomSheetReadOnlyWarning"))))),de.default.createElement(oe,null,de.default.createElement(So,{onClick:r,"data-testid":"secondary-button"},n("commandCancel"))))},fa=s.div`
  margin-bottom: 12px;
`;l();d();var Or=x(xt()),Y=x(k());l();d();var yt=x(k());async function ya(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:"signAllTransactions"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function ha(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:"signAllTransactions"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function wa(e,o){return(t,n)=>{let{networkID:r,origin:i}=n,a=(0,yt.useRef)(!1);return(0,yt.useCallback)(async c=>(r&&j.isSolanaNetworkID(r)&&!a.current&&("error"in c?await o({networkID:r,origin:i}):await e({networkID:r,origin:i}),a.current=!0),t(c)),[t,r,i])}}var Rt=wa(ya,ha);l();d();var ht=x(k());async function Sa(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:"signTransaction"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function Ca(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture transaction signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:"signTransaction"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function xa(e,o){return(t,n)=>{let{networkID:r,origin:i}=n,a=(0,ht.useRef)(!1);return(0,ht.useCallback)(async c=>(r&&j.isSolanaNetworkID(r)&&!a.current&&("error"in c?await o({networkID:r,origin:i}):await e({networkID:r,origin:i}),a.current=!0),t(c)),[t,r,i])}}var qt=xa(Sa,Ca);var Hr=["signAndSendAllTransactions","signAllTransactions"],Ia=(e,o,t,n)=>{let{t:r}=T(),i=mo(),{data:a}=se(),[c,p,m,y]=(0,Y.useMemo)(()=>{let C=a?.addresses?.find(W=>j.isSolanaNetworkID(W.networkID)),A=C?.address,H=C?C.networkID:void 0,L=a?.type==="ledger";return[a?.identifier,A??"",H,L]},[a]),{connection:f}=At(),{pushDetailView:I,popDetailView:b}=ne(),w=X(),q=qt(w,{networkID:m,origin:t}),P=X(),D=Rt(P,{networkID:m,origin:t}),h=(0,Y.useCallback)(async()=>{let C=new Zt;if(!c||!m||!e||Array.isArray(e)&&e.length===0)throw new Error("missing accountIdentifier or chainId or transaction");let A=Hr.includes(n);try{let H=ke(),L={ownerAddress:p,networkID:m,data:{signature:""},type:"dappInteraction",display:{summary:{topLeft:{text:r("transactionsPendingAppInteraction")}}}},W=[];for(let S=0;S<e.length;S++){let M=e[S];ze(i,go),W.push(await cn({accountIdentifier:c,feePayer:new It.PublicKey(p),connection:f,accountSigner:H,transaction:M,pendingTransactionInput:L,storage:C}).finally(()=>ze(i,uo)))}let F=W.map(S=>({signedTransaction:sn.serialize(S).transaction,signature:Or.default.encode(Ht(S)[0]),version:"version"in S?S.version:"legacy"}));A?D(R.result(o,{type:"send",result:F})):q(R.result(o,{type:"send",...F[0]}))}catch(H){throw Un(H)&&I(Y.default.createElement(Te,null,Y.default.createElement(_n,{ledgerActionError:H,onRetryClick:()=>{b()},onCancelClick:()=>{let L=R.userRejectedRequest(o);A?D(L):q(L)}}))),new Error("error signing with ledger: "+H,{cause:H})}},[c,m,e,n,p,r,i,f,D,o,q,I,b]);return{owner:p,isLedgerAccount:y,connection:f,ledgerSignAllTransactions:h,networkID:m}},Ta=e=>{let o=e.url.origin,t=O(o),{t:n}=T(),r=(0,Y.useMemo)(()=>{let fe=[];for(let Ve of e.transactions){let qe=Ot(Ve,"bs58");fe.push(qe)}return fe},[e.transactions]),{owner:i,isLedgerAccount:a,ledgerSignAllTransactions:c,networkID:p}=Ia(r,e.requestId,o,e.originalMethod),{pushDetailView:m}=ne(),y=X(),f=qt(y,{networkID:p,origin:o}),I=X(),b=Rt(I,{networkID:p,origin:o}),w=(0,Y.useMemo)(()=>Hr.includes(e.originalMethod)?b:f,[e.originalMethod,b,f]),{connection:q}=At(),{data:P,isLoading:D,isError:h}=un(q,e.transactions),{isError:C,data:A,isFetched:H,isLoading:L}=ho({networkID:p??"solana:101",type:"transaction",url:e.url.href,userAccount:i,params:{transactions:e.transactions,method:e.originalMethod}}),{fungible:W}=gn({key:"SolanaNative"}),F=(0,Y.useMemo)(()=>{let fe=W?.data.amount??"";return fe?P?BigInt(fe)>P.estimatedFee:!0:!1},[W,P]),S=A?.error===yo.INSUFFICIENT_GAS||A?.error===yo.INSUFFICIENT_FUNDS||!F,{screen:M,setScreen:$,showFrictionInterstitial:ue}=Ye({block:A?.block,isLoadingSimulation:L&&!H,warnings:A?.warnings}),xe=(0,Y.useCallback)(()=>{let fe=R.userRejectedRequest(e.requestId);w(fe)},[e.requestId,w]),{save:Ne,isAutoConfirmIsTouched:Pe,showAutoConfirmRow:J}=Ke(e.url.origin),Ie=(0,Y.useCallback)(async()=>{Pe&&await Ne(),a?m(Y.default.createElement(Te,null,Y.default.createElement(be,{ledgerAction:c,cancel:xe}))):w(R.result(e.requestId,{type:"signAndSend"}))},[Pe,Ne,a,m,c,xe,w,e.requestId]),Ae=(0,Y.useCallback)(()=>{B.capture("userIgnoredKnownMaliciousWarning",{data:{origin:o}}),$("main")},[o,$]),{data:Re}=Jo(),Po=(0,Y.useCallback)(fe=>{if(!Re)return"";let Ve=Re.explorers[p??Ee.Solana.Mainnet];return fo({endpoint:"address",explorerType:Ve,networkID:p??Ee.Solana.Mainnet,param:fe})},[Re,p]),Wo=(0,Y.useMemo)(()=>{if(!A||!A.advancedDetails?.advancedRows)return[];let fe=A.advancedDetails.advancedRows.map(Ve=>({title:Ve.title,rowItems:Ve.items.map(qe=>({key:qe.title,link:qe.isAddress?Po(qe.value):void 0,value:qe.isAddress?jo(qe.value):qe.value}))}));return fe.length===0?[]:[{value:Y.default.createElement(vo,{parsedInstructions:fe})}]},[A,Po]),Oo=Ao({origin:e.url.origin,autoConfirmStatusCode:e.autoConfirmStatusCode,networkID:p||void 0}),Ho=[],Mo=(0,Y.useMemo)(()=>P?.highFees?n("notificationTransactionApprovalNetworkFeeHighWarning"):S?n("transactionNotEnoughNative",{nativeTokenSymbol:"SOL"}):h?n("networkFeeCouldNotFetch"):void 0,[P,n,S,h]);if(J&&Ho.push(Oo),M==="block")return Y.default.createElement(_e,{warningMessage:A?.block?.message??"",origin:e.url.origin,onConfirm:Ae,onClose:xe});let Ct={networkID:p??"solana:101",transaction:r};return M==="loading"?Y.default.createElement(We,{type:e.transactions.length===1?"APPROVE_TRANSACTIONS":"APPROVE_TRANSACTION",tabId:e.tabId,icon:e.icon,domain:t,onClose:xe}):M==="friction"?Y.default.createElement(Xe,{onClose:xe,onConfirm:Ie,onBack:()=>$("main"),origin:e.url.origin,warningMessage:A?.warnings?.[0]?.message}):Y.default.createElement(To,{advancedRows:Wo,confirmApproval:ue?()=>$("friction"):Ie,denyApproval:xe,hasSimulationFailed:!!C,numTransactions:r.length,domain:t,rows:Ho,simulationResults:A?.expectedChanges??[],simulationWarnings:A?.warnings??[],tabId:e.tabId,icon:e.icon,networkID:Ct.networkID,showFriction:ue,showConfirmAnyway:!ue&&S,isErrorNativeTokenBalance:!1,isErrorNetworkFee:h,isLoading:D,networkFeeRows:[...pt(n,P?`${fn(Vt(P?.estimatedFee))} SOL`:"",D,h,S?"#EB3742":"#999999",Mo,P?.highFees||S||Mo?"#EB3742":"#999999")]})},Uo=Ta;l();d();var Jr=x(xt()),Be=x(k());l();d();var wt=x(k());async function va(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture message signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:"signIn"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function Aa(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture message signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:"signIn"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function ka(e,o){return(t,n)=>{let{networkID:r,origin:i}=n,a=(0,wt.useRef)(!1);return(0,wt.useCallback)(async c=>(r&&j.isSolanaNetworkID(r)&&!a.current&&("error"in c?await o({networkID:r,origin:i}):await e({networkID:r,origin:i}),a.current=!0),t(c)),[t,r,i])}}var Vr=ka(va,Aa);l();d();var me=x(k());var ba=s.div`
  margin-bottom: 24px;
`,zr=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Da=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin: 16px 0;
  align-items: flex-end;
`,Ea=s(he)`
  display: flex;
  flex-direction: column;
  align-content: space-between;
`,Gr=e=>{let{tabId:o,origin:t,signInData:n,icon:r,errorDetails:i,confirmApproval:a,denyApproval:c}=e,{t:p}=T(),m=i.reduce((f,I)=>(f[I.label]=I.message,f),{}),y=Ue(e.networkID);return me.default.createElement(ee,null,me.default.createElement(Z,null),me.default.createElement(Ea,null,me.default.createElement("div",null,me.default.createElement(we,{type:"SIGN_IN",domain:O(t),iconUrl:r,tabId:o}),me.default.createElement(ba,null,me.default.createElement(zr,{color:"#999999"},p("notificationApplicationApprovalParagraphText"))),me.default.createElement(Ro,{margin:"24px 0px 24px 0px ",justify:"center"},me.default.createElement(Q,{message:p("siwsVerificationErrorDescription"),variant:3})),me.default.createElement("div",{style:{display:"flex",gap:8,flexDirection:"column",marginBottom:8}},me.default.createElement($e,{header:p("notificationMessageHeader"),message:e.message,isJson:!1}),me.default.createElement(De,{rows:[y]}),me.default.createElement(ct,{signInData:n,errorObject:m}))),me.default.createElement(Da,null,me.default.createElement(zr,{color:"#999999"},p("notificationApplicationApprovalSignInDisclaimer")))),me.default.createElement(oe,null,me.default.createElement(Co,{primaryText:p("commandConfirm"),secondaryText:p("commandCancel"),onPrimaryClicked:a,onSecondaryClicked:c,primaryTheme:"warning"})))};l();d();var Ce=x(k());var Pa=s.div`
  margin-bottom: 24px;
`,$r=s(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left"})``,Ma=s.div`
  display: flex;
  flex: 1;
  justify-content: center;
  margin: 16px 0;
  align-items: flex-end;
`,Na=s(he)`
  display: flex;
  flex-direction: column;
  align-content: space-between;
`,jr=e=>{let{tabId:o,origin:t,signInData:n,icon:r,confirmApproval:i,denyApproval:a}=e,{t:c}=T(),p=Ue(e.networkID);return Ce.default.createElement(ee,null,Ce.default.createElement(Z,null),Ce.default.createElement(Na,null,Ce.default.createElement("div",null,Ce.default.createElement(we,{type:"SIGN_IN",domain:O(t),iconUrl:r,tabId:o}),Ce.default.createElement(Pa,null,Ce.default.createElement($r,{color:"#999999"},c("notificationApplicationApprovalParagraphText"))),Ce.default.createElement("div",{style:{display:"flex",gap:8,flexDirection:"column"}},Ce.default.createElement($e,{header:c("notificationMessageHeader"),message:e.message,isJson:!1}),Ce.default.createElement(De,{rows:[p]}),Ce.default.createElement(ct,{signInData:n}))),Ce.default.createElement(Ma,null,Ce.default.createElement($r,{color:"#999999"},c("notificationApplicationApprovalSignInDisclaimer")))),Ce.default.createElement(oe,null,Ce.default.createElement(Co,{primaryText:c("commandConfirm"),secondaryText:c("commandCancel"),onPrimaryClicked:i,onSecondaryClicked:a})))};var Fa=ke(),Ba=()=>{let{data:e}=se();return(0,Be.useMemo)(()=>{let o=e?.identifier??"",t=e?.addresses?.find(n=>j.isSolanaNetworkID(n.networkID));return{isLedger:e?.type==="ledger",networkID:t?.networkID,signMessage:async n=>{let r=Buffer.from(n).toString("utf-8"),i=await Fa.sign(o,{chainType:"solana",signingType:"message",message:r});if(i.status==="success")return i.signature;throw new Error(`[${i.type}] ${i.message}`)}}},[e])},Ra=e=>{let{isLedger:o,networkID:t,signMessage:n}=Ba(),{tabId:r,url:i,requestId:a,signInData:c,message:p,errorDetails:m,icon:y}=e,f=i.origin,I=Jr.default.decode(p),b=X(),w=Vr(b,{networkID:t,origin:f}),{pushDetailView:q}=ne(),P=(0,Be.useCallback)(()=>{let C=R.userRejectedRequest(a);w(C)},[a,w]),D=(0,Be.useCallback)(async()=>{try{let C=await n(I),A=R.result(a,{type:"send",signature:C});w(A)}catch(C){let A=R.internalError(a,C.message);w(A)}},[n,I,a,w]),h=(0,Be.useCallback)(()=>{o?q(Be.default.createElement(Te,null,Be.default.createElement(be,{ledgerAction:D,cancel:P}))):w(R.result(a,{type:"signAndSend"}))},[P,w,o,q,a,D]);return{tabId:r,icon:y,origin:f,signInData:c,message:I.toString("utf8"),errorDetails:m,networkID:t??"solana:101",confirmApproval:h,denyApproval:P}},Kr=e=>{let o=Ra(e);return"errorDetails"in o&&o.errorDetails?Be.default.createElement(Gr,{...o}):Be.default.createElement(jr,{...o})};l();d();var Xr=x(xt()),He=x(k());l();d();var St=x(k());async function qa(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture message signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userApprovedAction(B,{...t,origin:e.origin,method:"signMessage"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (approve)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserApprove: ${typeof o}`),"provider")}}async function La(e){try{let o=Me(e.networkID.replace("solana:",""))??"localnet",t=ie(o);if(t?.chainType!=="solana")throw new Error(`Failed to capture message signature event analytics: Unsupported Solana Network ID "${o}"`);return await ae.userDeniedAction(B,{...t,origin:e.origin,method:"signMessage"})}catch(o){E.addBreadcrumb("analytics","Could not log dapp user action (deny)","error"),o instanceof Error?E.captureError(o,"provider"):E.captureError(new Error(`Non-Error instance thrown in captureUserDeny: ${typeof o}`),"provider")}}function Ua(e,o){return(t,n)=>{let{networkID:r,origin:i}=n,a=(0,St.useRef)(!1);return(0,St.useCallback)(async c=>(j.isSolanaNetworkID(r)&&!a.current&&("error"in c?await o({networkID:r,origin:i}):await e({networkID:r,origin:i}),a.current=!0),t(c)),[t,r,i])}}var Yr=Ua(qa,La);l();d();var po=x(k());var Qr=po.memo(({tabId:e,icon:o,origin:t,message:n,display:r,confirmApproval:i,denyApproval:a,networkID:c,isSimulationLoading:p,hasSimulationFailed:m,scanResult:y})=>{let f=po.useMemo(()=>{switch(r){case"hex":return`0x${Buffer.from(n).toString("hex")}`;case"utf8":default:return new TextDecoder().decode(n)}},[r,n]);return p?po.createElement(We,{type:"SIGN_MESSAGE",tabId:e,icon:o,domain:t,onClose:a}):po.createElement(Do,{tabId:e,icon:o,origin:t,message:f,networkID:c,confirmApproval:i,denyApproval:a,scanFailed:m,scanIsLoading:p,scanWarnings:y?.warnings||[],advancedDetails:y?.advancedDetails})});var _a=ke(),Wa=()=>{let{data:e}=se();return(0,He.useMemo)(()=>{let o=e?.identifier??"",{address:t,networkID:n}=e?.addresses?.find(r=>j.isSolanaNetworkID(r.networkID))??{address:"",networkID:Ee.Solana.Mainnet};return{isLedger:e?.type==="ledger",publicKey:t,networkID:n,signMessage:async r=>{let i=Buffer.from(r).toString("utf-8"),a=await _a.sign(o,{chainType:"solana",signingType:"message",message:i});if(a.status==="success")return a.signature;throw new Error(`[${a.type}] ${a.message}`)}}},[e])},Oa=e=>{let{url:o,requestId:t,message:n,display:r,tabId:i,networkID:a,icon:c}=e,p=o.origin,m=Xr.default.decode(n),y=X(),f=Yr(y,{networkID:a,origin:p}),{pushDetailView:I}=ne(),b=(0,He.useCallback)(()=>{let C=R.userRejectedRequest(t);f(C)},[t,f]),w=(0,He.useCallback)(async()=>{try{let C=await e.signMessage(m),A=R.result(t,{type:"send",signature:C});f(A)}catch(C){let A=R.internalError(t,C.message);f(A)}},[e,m,t,f]),q=(0,He.useCallback)(()=>{e.isLedger?I(He.default.createElement(Te,null,He.default.createElement(be,{ledgerAction:w,cancel:b}))):f(R.result(t,{type:"signAndSend"}))},[b,f,e.isLedger,I,t,w]),{isError:P,data:D,isLoading:h}=Yo({networkID:a??"solana:101",type:"message",url:o.href,params:{message:Buffer.from(m).toString("utf8")}});return{networkID:a,tabId:i,icon:c,origin:p,requestId:t,message:m,display:r,isSimulationLoading:h,hasSimulationFailed:P,scanResult:D,confirmApproval:q,denyApproval:b}},Zr=e=>{let o=Wa(),t=Oa({...e,...o});return He.default.createElement(Qr,{...t})};l();d();var _o=x(k());var ei=s(u)`
  text-align: left;
  font-size: 16px;
  line-height: 20px;
  strong {
    font-weight: 600;
  }
`,Lt=({url:e,targetAddressType:o,addressType:t})=>{let{t:n}=T(),r=e.origin;return _o.createElement(to,{origin:r,title:n("notificationUnsupportedAccount"),onClose:()=>self.close()},_o.createElement(ei,null,_o.createElement(Io,{t:n,i18nKey:"notificationUnsupportedAccountDescription",values:{origin:r,targetChainType:Tt.getDisplayName(o),chainType:Tt.getDisplayName(t)}})),_o.createElement(ei,{margin:"16px 0 0 0"},n("notificationUnsupportedAccountDescription2")))};l();d();var Eo=x(k());var oi=s(u)`
  text-align: left;
  font-size: 16px;
  line-height: 20px;
  strong {
    font-weight: 600;
  }
`,ti=({url:e})=>{let{t:o}=T(),t=e.origin;return Eo.createElement(to,{origin:t,title:o("unsupported_network",{defaultValue:"Unsupported network"}),onClose:()=>self.close()},Eo.createElement(oi,null,o("notificationUnsupportedNetworkDescription")),Eo.createElement(oi,{margin:"16px 0 0 0"},Eo.createElement(Io,{t:o,i18nKey:"notificationUnsupportedNetworkDescriptionInterpolated"},"To proceed with a different extension, turn off",Eo.createElement("strong",null,"Settings \u2192 Default App Wallet, and select Always Ask"),". Then refresh the page and reconnect.")))};en();var Ha=g.default.lazy(()=>import("./EthSelectWallet-ACL4QAU4.js"));Gt.init({provider:Xn});tn();var Va=({req:e,url:o,tabId:t,icon:n})=>{let{method:r}=e,{data:i=[]}=Yt(),{data:[a]}=Je(["frontend-enable-session-start"]);return Nn(()=>{Fn.onAppSessionStart(i)},i.length>0&&a),(0,g.useEffect)(()=>{B.captureOptOutStatus()},[]),(0,g.useEffect)(()=>{B.capture("notificationOpen",{data:{method:r}})},[r]),g.default.createElement(za,{req:e,url:o,tabId:t,icon:n})},za=g.default.memo(({req:e,url:o,tabId:t,icon:n})=>{let{id:r}=e,i=new URL(o),a=K.user_confirmIncorrectMode.request.safeParse(e);if(a.success){let{params:F}=a.data;return g.default.createElement(Ur,{hostname:O(i.origin),enabledChains:F[1]})}let c=K.user_confirmEIP712IncorrectChainId.request.safeParse(e);if(c.success){let{params:F}=c.data,{connectedChainId:S,messageChainId:M}=F[1];return g.default.createElement(qr,{url:i,connectedChainId:S,messageChainId:M})}let p=K.user_confirmUnsupportedNetwork.request.safeParse(e);if(p.success){let F=p.data.params[1];return g.default.createElement(ti,{url:i,targetNetworkId:F})}let m=K.user_confirmUnsupportedAccount.request.safeParse(e);if(m.success&&m.data.params[1]==="ethereum")return g.default.createElement(Lt,{targetAddressType:"eip155",addressType:"solana",url:i});if(m.success&&m.data.params[1]==="solana")return g.default.createElement(Lt,{targetAddressType:"solana",addressType:"eip155",url:i});if(K.user_approveSolConnect.request.safeParse(e).success)return g.default.createElement(ut,{tabId:t,icon:n,url:i,requestId:r,allowSwitchingAccountsFor:"solana"});let f=K.user_approveSolSignTransaction.request.safeParse(e);if(f.success){let{params:F}=f.data,{transaction:S,autoConfirmStatusCode:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Uo,{tabId:t,icon:n,url:i,requestId:r,transactions:[S],autoConfirmStatusCode:M,originalMethod:"signTransaction"}))}let I=K.user_approveSolSignAndSendTransaction.request.safeParse(e);if(I.success){let{params:F}=I.data,{transaction:S,autoConfirmStatusCode:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Uo,{tabId:t,icon:n,url:i,requestId:r,transactions:[S],autoConfirmStatusCode:M,originalMethod:"signAndSendTransaction"}))}let b=K.user_approveSolSignAllTransactions.request.safeParse(e);if(b.success){let{params:F}=b.data,{transactions:S,autoConfirmStatusCode:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Uo,{tabId:t,icon:n,url:i,requestId:r,transactions:S,autoConfirmStatusCode:M,originalMethod:"signAllTransactions"}))}let w=K.user_approveSolSignAndSendAllTransactions.request.safeParse(e);if(w.success){let{params:F}=w.data,{transactions:S,autoConfirmStatusCode:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Uo,{tabId:t,url:i,icon:n,requestId:r,transactions:S,autoConfirmStatusCode:M,originalMethod:"signAndSendAllTransactions"}))}let q=K.user_approveSolSignMessage.request.safeParse(e);if(q.success){let{params:F}=q.data,{message:S,display:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Zr,{tabId:t,icon:n,url:i,requestId:r,message:S,display:M}))}let P=K.user_approveSolSignIn.request.safeParse(e);if(P.success){let{params:F}=P.data,{signInData:S,message:M,errorDetails:$}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Kr,{tabId:t,icon:n,url:i,requestId:r,signInData:S,message:M,errorDetails:$}))}let D=K.user_approveEthRequestAccounts.request.safeParse(e),h=K.user_approveWalletRequestPermissions.request.safeParse(e);if(D.success||h.success)return g.default.createElement(ut,{tabId:t,icon:n,url:i,requestId:r,allowSwitchingAccountsFor:"eip155"});let C=K.user_approveEthSendTransaction.request.safeParse(e);if(C.success){let{params:F}=C.data,{transaction:S,autoConfirmStatusCode:M}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Tr,{tabId:t,icon:n,url:i,requestId:r,transaction:S,autoConfirmStatusCode:M}))}let A=K.user_approveEthSignMessage.request.safeParse(e);if(A.success){let{params:F}=A.data,{message:S,originalMethod:M,chainId:$,autoConfirmStatusCode:ue}=F[1];return g.default.createElement(Fe,null,g.default.createElement(Dr,{tabId:t,icon:n,url:i,requestId:r,message:S,originalMethod:M,hexChainId:$,autoConfirmStatusCode:ue}))}if(K.user_approveBtcRequestAccounts.request.safeParse(e).success)return g.default.createElement(ut,{tabId:t,icon:n,url:i,requestId:r,allowSwitchingAccountsFor:"bip122_p2tr"});let L=K.user_approveBtcSignPSBT.request.safeParse(e);if(L.success)return g.default.createElement(Fe,null,g.default.createElement(Br,{tabId:t,icon:n,url:i,requestId:r,message:Buffer.from(L.data.params[1].psbt).toString("hex"),finalize:L.data.params[1].finalize,inputsToSign:L.data.params[1].inputsToSign}));let W=K.user_approveBtcSignMessage.request.safeParse(e);return W.success?g.default.createElement(Fe,null,g.default.createElement(Nr,{tabId:t,icon:n,url:i,requestId:r,messageBytes:W.data.params[1].message})):null}),Ga=()=>{let e=(0,g.useCallback)(()=>{on({url:"onboarding.html"}),self.close()},[]),o=or(),{data:t}=se(),n=t?.isReadOnly;if(!o)return null;let{url:r,req:i,tabId:a,icon:c}=o,{id:p,method:m}=i,y=K.user_selectEthWallet.method.safeParse(m).success,f=K.user_approveEthRequestAccounts.method.safeParse(m).success||K.user_approveSolConnect.method.safeParse(m).success||K.user_approveBtcRequestAccounts.method.safeParse(m).success;return g.default.createElement(g.default.Fragment,null,y?g.default.createElement(g.Suspense,{fallback:g.default.createElement(Dn,{color:"#AB9FF2"})},g.default.createElement(Ha,{requestId:p})):g.default.createElement(Yn,{openOnboarding:e},g.default.createElement(Jn,null,g.default.createElement(Wn,null,g.default.createElement(kt,{title:f?"Connection Error":"Transaction Error",message:`There was an error attempting to ${f?"connect to the application":"sign the transaction"}. Please try again.`},n&&!f?g.default.createElement(_r,{tabId:a,url:new URL(r),requestId:p}):g.default.createElement(Va,{req:i,url:r,tabId:a,icon:c}),g.default.createElement(Mn,null))))))},$a=()=>g.default.createElement(g.default.Fragment,null,g.default.createElement(xn,{future:{v7_startTransition:!0}},g.default.createElement(Tn,{theme:Bn},g.default.createElement(Zn,{backgroundColor:"#222222"}),g.default.createElement(kt,null,g.default.createElement(En,null,g.default.createElement(Qn,null,g.default.createElement(vn,null,g.default.createElement(hn,null,g.default.createElement(jt,{analytics:B},g.default.createElement(Jt,{authRepository:On},g.default.createElement(Kt,{userRepository:Vn,claimUsernameSigner:Hn},g.default.createElement(er,null,g.default.createElement(Ga,null)))))),g.default.createElement("div",{id:wn})))))))),ja=document.getElementById("root"),Ja=(0,ni.createRoot)(ja);Ja.render(g.default.createElement($a,null));
