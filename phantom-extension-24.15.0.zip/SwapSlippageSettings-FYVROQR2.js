import{a as w}from"./chunk-V5HJYMXJ.js";import{b as C,p as S}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import{K as f}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{za as x}from"./chunk-KB2UMCDM.js";import{A as h,E as a,p as o}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as k}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as b,h as m,n as u}from"./chunk-FPMOV6V2.js";m();u();var e=b(k());var O=o.div`
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 16px;
`,T=o.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  margin: 20px 0 16px;
  width: 100%;
`,F=o(a).attrs({size:28,lineHeight:32,weight:600,color:"#fff"})`
  margin: 20px 0 12px;
`,I=o(a).attrs({size:16,lineHeight:18,weight:400,color:"#777777"})`
  margin-bottom: 32px;
`,H=o.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  padding: 2px;
  width: 100%;
  background-color: ${t=>t.theme.backgroundDark};
`,P=o.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  padding: 10px 8px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  background-color: ${t=>t.selected?"#AB9FF2":"transparent"};
  cursor: pointer;
`,y=o(a).attrs(t=>({size:14,lineHeight:18,weight:t.selected?600:500,color:t.selected?"#222":"#fff"}))`
  text-align: center;
`,V=o(a).attrs(t=>({size:14,lineHeight:18,weight:500,color:t.severity==="critical"?"#EB3742":"#FFDC62"}))`
  align-self: stretch;
  margin-top: 8px;
  text-align: left;
`,B=o.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`,z=o.input`
  background: transparent;
  color: #222;
  ::placeholder {
    color: #22222299;
  }
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 18px;
  text-align: right;
  border: none;
  padding: 0;
`,D=()=>{let{handleHideModalVisibility:t}=S(),i=(0,e.useCallback)(()=>{t("slippageSettings")},[t]);return f({onDismiss:i})},E=({options:t,selectedIndex:i,customSlippageValue:r,i18nStrings:n,error:l,submitDisabled:g,onConfirm:c,onSelectOption:s,onChangeCustomSlippage:p,onDismiss:d})=>e.default.createElement(O,null,e.default.createElement(C,{leftButton:{type:"close",onClick:d},titleSize:"small"},n.title),e.default.createElement(T,null,e.default.createElement(w,{diameter:96,color:"#181818"},e.default.createElement(x,{width:38,fill:"#181818"})),e.default.createElement(F,null,n.title),e.default.createElement(I,null,n.subtitle),e.default.createElement(L,{options:t,selectedIndex:i,customOptionLabel:n.custom,customOptionValue:r,onSelectOption:s,onCustomOptionChange:p}),l?e.default.createElement(V,{severity:l.severity},l.message):null),e.default.createElement(h,{disabled:g,theme:"primary",onClick:c},n.button)),j=()=>{let t=D();return e.default.createElement(E,{...t})},Q=j,A=({value:t,onChangeText:i})=>{let r=n=>{n.target.validity.valid?i(n.target.value):n.preventDefault()};return e.default.createElement(B,null,e.default.createElement(z,{autoFocus:!t,placeholder:"0.00%",value:t??"",style:t?{width:`${t.length*10}px`,textAlign:"right"}:{width:"100%",textAlign:"center"},onChange:r}),e.default.createElement(y,{selected:!0},t?"%":""))},L=({options:t,selectedIndex:i,customOptionLabel:r,customOptionValue:n,onSelectOption:l,onCustomOptionChange:g})=>e.default.createElement(H,null,t.map((c,s)=>{let p=s===i,d=s===t.length-1&&p,v=()=>l(s);return e.default.createElement(P,{key:`segment-control-option-${s}`,selected:p,onClick:v},d?e.default.createElement(A,{value:n,onChangeText:g}):e.default.createElement(y,{selected:p},c==="custom"?r:c))}));export{j as SwapSlippageSettings,Q as default};
