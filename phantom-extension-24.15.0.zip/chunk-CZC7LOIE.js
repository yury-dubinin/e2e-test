import{h as R,n as O}from"./chunk-FPMOV6V2.js";R();O();var t="#FFDC62",e="#EB3742",C="#eb3742";export{t as a,e as b,C as c};
