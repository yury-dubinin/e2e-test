import{b as x}from"./chunk-UMXXII74.js";import{a as h}from"./chunk-V5HJYMXJ.js";import{a as s}from"./chunk-JQSMP2U7.js";import{I as A,U as f}from"./chunk-KB2UMCDM.js";import{p as a}from"./chunk-OJG7N72N.js";import{Td as g}from"./chunk-Q5O4STUM.js";import{O as d}from"./chunk-FJ67REU6.js";import{a as E}from"./chunk-MVAHBHCD.js";import{f as C,h as m,n as l}from"./chunk-FPMOV6V2.js";m();l();var t=C(E());var y={xsmall:{size:10,weight:600},small:{size:12,weight:600},medium:{size:14,weight:700},large:{size:28,weight:700}},v={xsmall:24,small:32,medium:48,large:90},j={xsmall:14,small:18,medium:24,large:48},F=a.p`
  font-size: ${e=>e.size}px;
  font-weight: ${e=>e.weight};
`,T=a.span`
  font-size: ${e=>e.emojiSize}px;
`,B=a(h)(e=>`
  border: ${e.withBorder?"2px solid white":"none"};
  cursor: ${e.onClick?"pointer":"default"};
  overflow: hidden;
`),z=t.default.memo(e=>{let{accountName:o,accountIndex:n,size:r,weight:c}=e,i=g(o,n),{textRef:u}=I(r,e.accountName);return t.default.createElement(F,{ref:u,size:r,weight:c},i)}),N=t.default.memo(e=>{let{accountIcon:o,emojiSize:n,imageSize:r,iconSize:c,iconColor:i}=e;try{switch(o?.type??"default"){case"image":if(o?.imageUrl)return t.default.createElement(x,{uri:o.imageUrl,width:r,height:r});throw new Error("Icon type is Image, but no field: imageUrl found.");case"emoji":if(o?.unicode)return t.default.createElement(T,{emojiSize:n},o.unicode);throw new Error("Icon type is Emoji, but no field: unicode found.");case"read-only-default":return t.default.createElement(f,{width:n,height:n,fill:c==="large"?"#999":i});default:return t.default.createElement(z,{...e})}}catch(u){return d.captureError(u,"account"),t.default.createElement(z,{...e})}}),p=t.default.memo(e=>{let{accountName:o,accountIndex:n,accountIcon:r}=e,{size:c,weight:i}=y[e.size],{containerRef:u}=I(c,e.accountName),S=P(e.accountIcon,e.size);return t.default.createElement(B,{"data-testid":e.testID,color:S,diameter:v[e.size],ref:u,withBorder:e.withBorder,onClick:e.onClick},t.default.createElement(N,{accountIcon:r,accountName:o,accountIndex:n,emojiSize:j[e.size],imageSize:v[e.size],size:c,weight:i,iconSize:e.size,iconColor:e.iconColor||"#000"}))}),I=(e,o)=>{let n=(0,t.useRef)(null),r=(0,t.useRef)(null);return(0,t.useEffect)(()=>{r.current&&(r.current.style.fontSize=`${e}px`),n.current&&r.current&&w(n,r,e)},[o,e,n,r]),{containerRef:n,textRef:r}},P=(e,o)=>e&&e.type==="read-only-default"?o==="large"?"#181818":"#AB9FF2":"#333",D=5,w=(e,o,n)=>{let r=e.current?.clientWidth||0;(o.current?.clientWidth||0)>=r-D&&o.current&&(n=n-1,o.current.style.fontSize=`${n}px`,w(e,o,n))},G=t.default.memo(e=>{let{accountName:o,accountIndex:n,accountIcon:r,onClick:c,withBorder:i}=e;return t.default.createElement(b,null,t.default.createElement(p,{accountIndex:n,accountName:o,accountIcon:r,withBorder:i,size:"large"}),t.default.createElement(L,{"data-testid":"edit-avatar-icon",onClick:c},t.default.createElement(A,{fill:"#777"})))}),J=t.default.memo(e=>{let{accountName:o,accountIndex:n,accountIcon:r,withBorder:c}=e;return t.default.createElement(b,null,t.default.createElement(p,{accountIndex:n,accountName:o,accountIcon:r,withBorder:c,size:"large"}))}),Y=a(s).attrs({justify:"center"})`
  margin: 0 auto;
`,q=a(s).attrs({justify:"center"})`
  margin: 20px auto;
`,b=a.div`
  position: relative;
`,L=a.div`
  position: absolute;
  bottom: -4px;
  right: -4px;

  height: 32px;
  width: 32px;

  display: flex;
  align-items: center;
  justify-content: center;

  cursor: pointer;

  border: 2px solid #222;
  border-radius: 50%;
  background: #333;

  &:hover {
    background: #ab9ff2;
    path {
      fill: #333;
    }
  }
`;export{B as a,p as b,G as c,J as d,Y as e,q as f};
