import{a as y}from"./chunk-246MQMRD.js";import{a as C}from"./chunk-PK6WRZ47.js";import{a as h}from"./chunk-WK2JI25E.js";import{b as x}from"./chunk-XBQBBV2G.js";import{V as b,q as f}from"./chunk-KB2UMCDM.js";import{p as i}from"./chunk-OJG7N72N.js";import{e as p}from"./chunk-D3AP5534.js";import{L as g}from"./chunk-PAHUG44L.js";import{a as z}from"./chunk-MVAHBHCD.js";import{f as k,h as m,n as u}from"./chunk-FPMOV6V2.js";m();u();var t=k(z());var T=i.div`
  background: #2a2a2a;
  border-radius: ${e=>e.borderRadius?e.borderRadius:x.radiusRow};
  width: 100%;
`,I=i.div`
  border-bottom: 1px solid #222222;
  border-bottom-width: 1px;
  padding: 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: space-between;
  font-size: 14px;
`,$=i.div`
  display: flex;
  flex-direction: column;
  border-bottom: 1px solid #222222;
  border-bottom-width: ${e=>e.border?1:0}px;
  padding: ${e=>e.padding?e.padding:14}px;
  cursor: ${e=>e.onClick?"pointer":"default"};
`,S=i.div`
  padding-top: 3px;
`,L=i.div`
  display: flex;
  justify-content: space-between;
  font-size: ${e=>e.fontSize?e.fontSize:14}px;
`,D=i.div`
  display: flex;
  justify-content: space-between;
`,P=i.div`
  text-align: left;
  flex: 1;
`,N=i.div`
  text-align: right;
  flex: 1;
`,A=i.div`
  display: flex;
  align-items: center;
  ${e=>e.truncate?"flex: 1; min-width: 0; justify-content:end;":""}
`,V=i.div`
  padding-left: 8px;
  color: #999;
`,v=({children:e,showArrow:o})=>t.createElement(A,{truncate:!o},e,o&&t.createElement(V,null,t.createElement(f,{height:12}))),r=i.span`
  color: ${e=>e.color||"white"};
  text-align: ${e=>e.align||"left"};
  font-weight: ${e=>e.weight||400};
  overflow-wrap: break-word;
  ${e=>e.margin?"margin: "+e.margin+";":""};
  ${e=>e.size?"font-size: "+e.size+"px;":""}
  ${e=>e.truncate?"white-space: nowrap; text-overflow: ellipsis; overflow:hidden; width: 100%;"+(e.size?"line-height: "+e.size*1.2+"px;":"line-height: 17px;"):""}
`,j=i.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  color: #ab9ff2;
  text-decoration: none;
  cursor: pointer;
`,F=i.div`
  text-align: center;
  width: 100%;
`,H=({children:e,label:o,tooltipContent:a,fontSize:l})=>t.createElement(t.Fragment,null,t.createElement(C,{tooltipAlignment:"topLeft",iconSize:12,lineHeight:17,fontSize:l,fontWeight:500,info:a?t.createElement(h,null,a):null},o),e),W=e=>{p.capture("historyItemDetailLinkClicked",{data:{hostname:g(e)}})},U=({header:e,rows:o,borderRadius:a,padding:l,fontSize:c})=>t.createElement(T,{borderRadius:a},e?t.createElement(I,null,e):null,o.map((n,s)=>{if(n.value===void 0)return null;let d=n.onClick?{role:"button"}:void 0;return t.createElement($,{border:o.length-1!==s,padding:l,onClick:n.onClick,key:`summary-row-${s}`,...d},t.createElement(L,{key:n.label,fontSize:c},typeof n.value=="string"?n.type==="link"?t.createElement(F,null,t.createElement(j,{href:n.value,onClick:()=>W(n.value)},n.label)):t.createElement(H,{label:n.label,tooltipContent:n.tooltipContent,fontSize:c},t.createElement(v,{showArrow:!!n.onClick},t.createElement(r,{color:n.color,weight:500,align:"right",truncate:!n.onClick},n.value))):t.createElement(t.Fragment,null,t.createElement(r,{color:"#777777",size:c},n.label),t.createElement(v,{showArrow:!!n.onClick},n.value))),t.createElement(D,null,n.leftSubtext?t.createElement(P,null,t.createElement(S,null,t.createElement(r,{color:n.leftSubtextColor||"#777777",size:13},n.leftSubtext))):null,n.rightSubtext?t.createElement(N,null,t.createElement(S,null,t.createElement(r,{color:n.rightSubtextColor||"#777777",size:13},n.rightSubtext))):null))})),rt=({name:e,imageURL:o})=>t.createElement("div",{style:{display:"flex",flexDirection:"row",alignItems:"center"}},t.createElement(y,{iconUrl:o,width:16}),t.createElement(r,{margin:"0 0 0 5px",weight:500},e)),B=i.div`
  height: 100%;
  overflow: scroll;
  margin-top: -16px;
  padding-top: 16px;
  padding-bottom: 64px;
`,E=i.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`,O=i.div`
  margin-top: 10px;
  margin-bottom: 10px;
`,_=i.div`
  margin-top: 10px;
  margin-bottom: 20px;
`,q=i.div`
  margin-bottom: 10px;
`,G=i.div`
  position: relative;
  width: 100%;
  text-align: center;
  margin: 10px 0 10px 0;
`,J=i(r)`
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  max-width: 100%;
`,K=i.div`
  background-color: #ffdc62;
  width: 100%;
  margin-top: 24px;
  margin-bottom: 14px;
  border-radius: 9px;
  padding: 16px;
  gap: 8px;
  display: flex;
  align-items: flex-start;
  align-self: stretch;
`,M=i.div`
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
`,at=({title:e,primaryText:o,secondaryText:a,image:l,sections:c,leftButton:n,warning:s})=>t.createElement(B,null,t.createElement(E,null,t.createElement(G,null,n||!1,t.createElement(r,{weight:500,size:22},e)),t.createElement(O,null,l),o.value&&t.createElement(J,{weight:600,size:34,color:o.color,align:"center",margin:"10px 0 10px 0"},o.value),a.value&&t.createElement(r,{size:16,color:"#777777",margin:"0 0 10px 0"},a.value),s&&t.createElement(K,null,t.createElement(M,null,t.createElement(b,null)),t.createElement(r,{size:14,color:"#222222",margin:"3px 0px 3px 8px"},s))),c.map(({title:d,rows:R},w)=>t.createElement(_,{key:`summary-item-${w}`},d&&t.createElement(q,null,t.createElement(r,{size:14,weight:500,color:"#777777"},d)),t.createElement(U,{rows:R}))));export{U as a,rt as b,at as c};
