import{a as m}from"./chunk-PLKS6FEO.js";import{b as h}from"./chunk-S366KFSE.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import{c as C}from"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import{a as f}from"./chunk-DDQ3VOL7.js";import{ca as g}from"./chunk-KB2UMCDM.js";import{A as x,E as p,p as e}from"./chunk-OJG7N72N.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as a}from"./chunk-IVQ3W7KJ.js";import"./chunk-RO2HUFH7.js";import{a as A}from"./chunk-MVAHBHCD.js";import{f as k,h as c,n as d}from"./chunk-FPMOV6V2.js";c();d();var o=k(A());var w=16,P=e.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 16px;
  height: 100%;
`,D=e.div`
  overflow: scroll;
`,S=e.div`
  margin: 45px 16px 16px 16px;
  padding-top: 16px;
`,H=e(C)`
  left: ${w}px;
  position: absolute;
`,b=e.div`
  align-items: center;
  background: #222;
  border-bottom: 1px solid #323232;
  display: flex;
  height: 46px;
  padding: ${w}px;
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
`,G=e.div`
  display: flex;
  flex: 1;
  justify-content: center;
`,I=e.footer`
  margin-top: auto;
  flex-shrink: 0;
  min-height: 16px;
`,y=e(p)`
  text-align: left;
`;y.defaultProps={margin:"12px 0px"};var F=e(p).attrs({size:16,weight:500,lineHeight:25})``;function M(r){let{actions:i,shortcuts:l,trackAction:n,onClose:s}=r;return(0,o.useMemo)(()=>{let T=i.more.map(t=>({icon:o.default.createElement(m,{size:18,type:t.type,color:t.isDestructive?"accentAlert":"white"}),title:t.text,onClick:()=>{n(t),s(),t.onClick(t.type)},rightNode:null,type:t.isDestructive?"alert":"default"})),v=l?.map(t=>({icon:o.default.createElement(m,{size:18,type:t.type,color:t.isDestructive?"accentAlert":"white"}),title:t.text,onClick:()=>{n(t),s(),t.onClick(t.type)},rightNode:null,type:t.isDestructive?"alert":"default"}))??[];return[{rows:T},{rows:v}]},[i,s,l,n])}function z(r){let{t:i}=a(),{headerText:l,hostname:n,shortcuts:s}=r,u=M(r);return o.default.createElement(P,null,o.default.createElement(D,null,o.default.createElement(b,{onClick:r.onClose},o.default.createElement(H,null,o.default.createElement(g,null)),o.default.createElement(G,null,o.default.createElement(F,null,l))),o.default.createElement(S,null,o.default.createElement(h,{groups:u}),o.default.createElement(I,null,n&&s&&s.length>0&&o.default.createElement(y,{color:"#777777",size:14,lineHeight:17},i("shortcutsWarningDescription",{url:n})))),o.default.createElement(f,{removeFooterExpansion:!0},o.default.createElement(x,{onClick:r.onClose},i("commandClose")))))}var O=z;export{z as CTAModal,O as default};
