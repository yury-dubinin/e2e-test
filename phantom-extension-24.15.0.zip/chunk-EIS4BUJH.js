import{a as f}from"./chunk-PLKS6FEO.js";import{p as k}from"./chunk-Y3KNGKBS.js";import{c as h}from"./chunk-XBQBBV2G.js";import{xc as g}from"./chunk-NAMHSCI2.js";import{p as t}from"./chunk-OJG7N72N.js";import{e as b}from"./chunk-D3AP5534.js";import{r as u}from"./chunk-IVQ3W7KJ.js";import{ta as y}from"./chunk-FJ67REU6.js";import{a as I}from"./chunk-MVAHBHCD.js";import{f as E,h as i,n as a}from"./chunk-FPMOV6V2.js";i();a();var m=new g(b);i();a();var o=E(I());var z=t.div`
  display: grid;
  grid-gap: 8px;
  grid-template-columns: ${e=>`repeat(${e.buttonCount}, minmax(0, 1fr));`};
  width: 100%;
  height: 74px;
`,C=t.button`
  display: flex;
  border: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 12px;
  border-radius: 16px;
  gap: 4px;
  font-size: 12px;
  font-style: normal;
  font-weight: 600;
  line-height: 16px;
  cursor: pointer;

  &:disabled {
    cursor: default;
  }
`,F=t.div`
  height: 24px;
  overflow: hidden;
`,H=t(C)`
  background: #2a2a2a;
  * {
    color: ${e=>e.theme.grayLight};
  }
  &:hover:enabled {
    background: #333333;
  }
`,W=t(C)`
  background: #2a2a2a;
  * {
    color: ${e=>e.theme.grayLight};
  }
  &:hover:enabled {
    background: #333333;
  }
`,A=t.span`
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
  word-break: break-word;
  text-overflow: ellipsis;
  word-break: break-all;
`;function Z({actions:e,shortcuts:c,hostname:x,headerText:B,maxButtons:n,uiContextName:l,disabled:p=!1}){let{t:w}=u(),{data:[T]}=y(["enable-home-search"]),M=e.primary.length+e.more.length+(c?.length??0),s=e.more.length>0,v=Math.min(e.primary.length+(s?1:0),n),{handleShowModalVisibility:S,handleHideModalVisibility:P}=k(),d=(0,o.useCallback)((r,L)=>{m.ctaBarTrackPrimaryButtonsClick({uiContext:{name:l},position:L,type:r.type,typeSpecificMetadata:r.typeSpecificMetadata,maxButtons:n,primaryActions:e.primary,moreActions:e.more})},[n,e.more,e.primary,l]);return o.default.createElement(z,{buttonCount:v},e.primary.map(r=>o.default.createElement(H,{disabled:p,key:r.type,type:"button",onClick:()=>{d(r,"primary"),r.onClick(r.type)}},o.default.createElement(F,null,o.default.createElement(f,{color:p?"gray":"accentPrimary",type:r.type,useAltIcon:T})),o.default.createElement(A,null,r.singleWordAltText??r.text))),s?o.default.createElement(W,{disabled:p,type:"button",onClick:()=>{m.ctaBarTrackMoreButtonClick({uiContext:{name:l},maxButtons:n,totalButtons:M}),S("callToActionSheet",{headerText:B,actions:e,shortcuts:c,hostname:x,onClose:()=>{P("callToActionSheet")},trackAction:r=>{d(r,"more")}})}},o.default.createElement(h.MoreHorizontal,{size:24,color:"accentPrimary"}),o.default.createElement(A,null,w("commandMore"))):null)}export{m as a,Z as b};
