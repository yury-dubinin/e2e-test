import{a as F,c as L,d as N,g as D}from"./chunk-KZGVCNHZ.js";import{a as f}from"./chunk-73LC6UPQ.js";import"./chunk-73NY4HVH.js";import"./chunk-YML3RMB7.js";import"./chunk-6TM7UJPN.js";import"./chunk-5CR56F4P.js";import{a as $}from"./chunk-YO7AFFW5.js";import"./chunk-PLCKHDK3.js";import"./chunk-6LXDUOIB.js";import"./chunk-MDQQE27Q.js";import"./chunk-CZC7LOIE.js";import{a as m}from"./chunk-V5HJYMXJ.js";import"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import{w as T}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as _}from"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-2OUSFATI.js";import"./chunk-QSY3A4J6.js";import"./chunk-U5GOBD2Y.js";import"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import{a as g}from"./chunk-JOOIVSPU.js";import"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{p as E}from"./chunk-KB2UMCDM.js";import{p as c,q as P,r as O}from"./chunk-OJG7N72N.js";import"./chunk-B3RYBV57.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{md as v,od as B}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{g as y}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as H}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as b,h as r,n}from"./chunk-FPMOV6V2.js";r();n();var o=b(H());r();n();var i=b(H());r();n();var G=c(m)`
  cursor: pointer;
  width: 24px;
  height: 24px;
  transition: background-color 200ms ease;
  background-color: ${t=>t.$isExpanded?"#000":"#333"} !important;
  :hover {
    background-color: #444444;
    svg {
      fill: white;
    }
  }
  svg {
    fill: ${t=>t.$isExpanded?"white":"#666666"};
    transition: fill 200ms ease;
    position: relative;
    ${t=>t.top?`top: ${t.top}px;`:""}
    ${t=>t.right?`right: ${t.right}px;`:""}
  }
`;var U=c(_).attrs({justify:"space-between"})`
  background-color: #222222;
  padding: 10px 16px;
  border-bottom: 1px solid #323232;
  height: 46px;
  opacity: ${t=>t.opacity??"1"};
`,V=c.div`
  display: flex;
  margin-left: 10px;
  > * {
    margin-right: 10px;
  }
`,I=c.div`
  width: 24px;
  height: 24px;
`,M=({onBackClick:t,totalSteps:a,currentStepIndex:p,isHidden:l,showBackButtonOnFirstStep:e,showBackButton:u=!0})=>i.default.createElement(U,{opacity:l?0:1},u&&(e||p!==0)?i.default.createElement(G,{right:1,onClick:t},i.default.createElement(E,null)):i.default.createElement(I,null),i.default.createElement(V,null,y(a).map(s=>{let d=s<=p?"#AB9FF2":"#333";return i.default.createElement(m,{key:s,diameter:12,color:d})})),i.default.createElement(I,null));r();n();var z=()=>{let{mutateAsync:t}=B(),{hardwareStepStack:a,pushStep:p,popStep:l,currentStep:e,setOnConnectHardwareAccounts:u,setOnConnectHardwareDone:w,setExistingAccounts:s}=F(),{data:d=[],isFetched:x,isError:k}=v(),C=T(a,(h,J)=>h?.length===J.length),W=a.length>(C??[]).length,A=C?.length===0,X={initial:{x:A?0:W?150:-150,opacity:A?1:0},animate:{x:0,opacity:1},exit:{opacity:0},transition:{duration:.2}},j=(0,o.useCallback)(()=>{e()?.props.preventBack||(e()?.props.onBackCallback&&e()?.props.onBackCallback?.(),l())},[e,l]);return $(()=>{u(async h=>{await t(h),await g.set(f,!await g.get(f))}),w(()=>self.close()),p(o.default.createElement(D,null))},a.length===0),(0,o.useEffect)(()=>{s({data:d,isFetched:x,isError:k})},[d,x,k,s]),o.default.createElement(L,null,o.default.createElement(M,{totalSteps:3,onBackClick:j,showBackButton:!e()?.props.preventBack,currentStepIndex:a.length-1}),o.default.createElement(O,{mode:"wait"},o.default.createElement(P.div,{style:{display:"flex",flexGrow:1},key:`${a.length}_${C?.length}`,...X},o.default.createElement(N,null,e()))))},yt=z;export{yt as default};
