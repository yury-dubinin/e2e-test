import{a as I,b as a,c as l,d as y}from"./chunk-A65D3ZQB.js";import{a as x}from"./chunk-73NY4HVH.js";import"./chunk-PK6WRZ47.js";import"./chunk-V5HJYMXJ.js";import{p as g}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import"./chunk-KB2UMCDM.js";import{A as u,E as r,p as o}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Oa as p}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as d}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as w}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as h,h as c,n as m}from"./chunk-FPMOV6V2.js";c();m();var n=h(w());var C=o.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  overflow-y: scroll;
`,b=o.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 90px;
`,T=o(r).attrs({size:28,weight:500,color:"#FFF"})`
  margin: 16px;
`,k=o(r).attrs({size:14,weight:400,lineHeight:17,color:"#999"})`
  max-width: 275px;
  span {
    color: white;
  }
`,S=o(I)`
  width: 100%;
  margin-top: 32px;
`,M=({networkId:s,token:t})=>{let{t:i}=d(),{handleHideModalVisibility:f}=g(),B=(0,n.useCallback)(()=>{f("insufficientBalance")},[f]),e=s?p.getTokenSymbol(s):i("tokens");return n.default.createElement(C,null,n.default.createElement("div",null,n.default.createElement(b,null,n.default.createElement(x,{type:"failure",backgroundWidth:75}),n.default.createElement(T,null,i("insufficientBalancePrimaryText",{tokenSymbol:e})),n.default.createElement(k,null,i("insufficientBalanceSecondaryText",{tokenSymbol:e})),t?n.default.createElement(S,{roundedTop:!0,roundedBottom:!0},n.default.createElement(a,{label:i("insufficientBalanceRemaining")},n.default.createElement(l,{color:"#EB3742"},`${t.balance} ${e}`)),n.default.createElement(y,{gap:1}),n.default.createElement(a,{label:i("insufficientBalanceRequired")},n.default.createElement(l,null,`${t.required} ${e}`))):null)),n.default.createElement(u,{onClick:B},i("commandCancel")))},E=M;export{M as InsufficientBalance,E as default};
