import{a as Ee}from"./chunk-6JTJBVH3.js";import{d as We}from"./chunk-A65D3ZQB.js";import"./chunk-PK6WRZ47.js";import"./chunk-354SN5AZ.js";import{a as oe}from"./chunk-V5HJYMXJ.js";import{f as j,p as M}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import{a as U}from"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import{h as L}from"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import{a as K}from"./chunk-7ZDPJAUC.js";import{a as u,b as Le,c as Ne,j as k,n as O,q as J,s as De,v as H,w as ze}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import{I as Pe,L as Ie,M as ke,Q as Te,S as Fe,r as Y,t as _,w as ve,y as Ae}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{O as Me,X as Ve,o as ee}from"./chunk-KB2UMCDM.js";import{A as te,E as z,j as Be,p as m}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import{e as Ce}from"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Gd as ye,Kb as xe,Oa as he}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{S as R}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as S}from"./chunk-IVQ3W7KJ.js";import{ta as be,x as Se}from"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as I}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as P,h as f,n as w}from"./chunk-FPMOV6V2.js";f();w();f();w();f();w();f();w();var N=P(I());var V=m.div`
  display: flex;
  align-items: center;
  height: 36px;
  input {
    font-size: ${e=>e.fontSize??34}px;
    line-height: 1;
    font-weight: 600;
    padding: 0;
    background: none;
  }
`,rt=m.div`
  width: 100%;
  margin-top: 11px;
  margin-bottom: 10px;
`,re=({decimals:e,disabled:o,hasWarning:r,isLoadingAmount:n,value:i,name:s="amount","aria-labelledby":a,"aria-label":p,onUserInput:h,maxSellAmount:d,setMaxSellAmount:y,currencyValue:x,fontSize:c})=>{let{t:A}=S();return N.default.createElement(V,{hasWarning:r,fontSize:c},n?N.default.createElement(rt,null,N.default.createElement(U,{width:"100px",height:"20px",backgroundColor:"#434343",borderRadius:"10px"})):N.default.createElement(L,{"aria-labelledby":a,"aria-label":p,name:s,border:"0",placeholder:"0",warning:r,value:i,decimalLimit:e,disabled:o,onUserInput:h}),d&&y!==void 0&&N.default.createElement(nt,{onClick:y},A("maxInputMax")),n?N.default.createElement(U,{width:"50px",height:"12px",backgroundColor:"#434343",borderRadius:"10px"}):x?N.default.createElement(z,{size:16,color:"#777"},x):void 0)},nt=m.div`
  color: #ab9ff2;
  font-size: 14px;
  font-weight: 400;
  white-space: nowrap;
  cursor: pointer;
  margin-left: 5px;
  border-radius: 8px;
  padding: 8px;
  &:hover {
    background-color: #333333;
  }
`;f();w();var F=P(I()),G={container:u({display:"flex",flexDirection:"column",gap:0,backgroundColor:"bgRow",borderRadius:"table",padding:20}),tokenContainer:u({display:"flex",flexDirection:"row",alignItems:"center",minHeight:48}),accessoryContainer:u({display:"flex",height:18,flexDirection:"row",gap:6}),actionsContainer:u({display:"flex",flexDirection:"row",gap:0,backgroundColor:"accentPrimary"}),spacer:u({flex:1}),selector:u({display:"flex",gap:8,flexDirection:"row",backgroundColor:"gray",paddingY:4,paddingLeft:4,paddingRight:8,alignItems:"center",borderRadius:"full"})},$=({input:e,isLoading:o,onSelectorPress:r,perspective:n,selectorIcon:i,selectorLabel:s,accessories:a})=>{let{t:p}=S(),h=p(n==="buy"?"swapAssetCardBuyTitle":"swapAssetCardSellTitle");return F.default.createElement("div",{className:G.container},F.default.createElement(k,{font:"labelSemibold",color:"textTertiary",children:h}),F.default.createElement("div",{className:G.tokenContainer},e,F.default.createElement("div",{className:G.spacer}),o?F.default.createElement(H,{width:112,height:24}):F.default.createElement("div",{onClick:r,className:G.selector,"data-testid":`${n}-token-button`},i,F.default.createElement(k,{font:"captionSemibold",color:"textPrimary",children:s}),F.default.createElement(Ne.ChevronDown,{size:14}))),F.default.createElement("div",{className:G.accessoryContainer},a))};var g=P(I()),X={filters:u({display:"flex",flexDirection:"row",alignItems:"center",gap:4,marginLeft:8}),secondaryContainer:u({display:"flex",flexDirection:"row",alignItems:"center",gap:6}),currencyPrefix:u({marginRight:2}),accessoryContainer:u({display:"flex",height:18,flexDirection:"row",gap:0}),spacer:u({flex:1})},Oe=({asset:e,perspective:o,onInputChange:r,onFungibleTap:n,onFilterTap:i,switchCurrencyDenomination:s,onBalanceTap:a})=>{let{amount:p,balance:h,fungible:d,isAmountEditable:y,isAmountLoading:x,isSecondaryAmountLoading:c,isWarning:A,secondaryAmount:B,amountPrefix:de,selectedFilter:ce,filters:ue,supportsCurrencyDenominationSwitching:me}=e,{t:fe}=S(),Re=g.default.createElement(j,{image:{type:"fungible",src:d.data?.logoUri,fallback:d.data?.symbol||d.data?.tokenAddress},size:32,tokenType:d.type,chainMeta:d.data?.chain}),et=D=>D.length>16?16:D.length>14?18:D.length>12?20:22,tt=(0,g.useMemo)(()=>{let D=et(p);return x?g.default.createElement(H,{width:100,height:18,borderRadius:12}):g.default.createElement(V,{hasWarning:A,fontSize:D},g.default.createElement(k,{font:"heading3",children:de,className:X.currencyPrefix}),g.default.createElement(L,{name:"amount",border:"0",placeholder:"0",warning:A,value:p,decimalLimit:d.data?.decimals,disabled:!y,onUserInput:r}))},[x,A,de,p,d.data?.decimals,y,r]),we=(0,g.useMemo)(()=>c?g.default.createElement(H,{width:40,height:18,borderRadius:12}):g.default.createElement(k,{font:"caption",color:"textSecondary",children:B}),[c,B]),ge=(0,g.useMemo)(()=>{let D=E=>{switch(E){case .25:return"25%";case .5:return"50%";case 1:return fe("swapAssetCardMaxButton")}};return ue.map(E=>g.default.createElement(J,{key:E,active:E===ce,children:D(E),variant:{size:"small"},onChange:()=>i(E)}))},[ue,fe,ce,i]),ot=(0,g.useMemo)(()=>g.default.createElement(g.default.Fragment,null,g.default.createElement("div",{className:X.secondaryContainer,onClick:s},we,me?g.default.createElement(O,{icon:"SwapVertical",size:20,shape:"circle",backgroundColor:"gray",color:"textSecondary"}):null),g.default.createElement("div",{className:X.spacer}),g.default.createElement(k,{font:"caption",color:"textSecondary",children:h,onClick:a}),g.default.createElement("div",{className:X.filters},ge)),[h,ge,a,we,me,s]);return g.default.createElement($,{perspective:o,input:tt,selectorIcon:Re,selectorLabel:d.data?.symbol??"",onSelectorPress:n,accessories:ot})};f();w();var Q=P(I());var Ue=({onSelectorTap:e,perspective:o})=>{let{t:r}=S();return Q.default.createElement($,{perspective:o,input:Q.default.createElement(V,{hasWarning:!1,fontSize:32},Q.default.createElement(L,{name:"amount",border:"0",placeholder:"0",warning:!1,value:"",decimalLimit:0,disabled:!0,onUserInput:()=>{}})),selectorIcon:Q.default.createElement(O,{icon:"Plus",size:28,shape:"circle",color:"textPrimary",backgroundColor:"bgArea"}),selectorLabel:r("commandSelect"),onSelectorPress:e,accessories:Q.default.createElement(k,{font:"caption",color:"textSecondary",children:"$0"})})};var C=P(I());f();w();var b=P(I()),ne={filters:u({display:"flex",flexDirection:"row",alignItems:"center",gap:4,marginLeft:8}),secondaryContainer:u({display:"flex",flexDirection:"row",alignItems:"center",gap:6}),currencyPrefix:u({marginRight:2}),accessoryContainer:u({display:"flex",height:18,flexDirection:"row",gap:6}),spacer:u({flex:1})},it=[.5,1],$e=({perspective:e})=>{let{t:o}=S(),r=(0,b.useMemo)(()=>{let a=Number(Le.typography.font.heading3.fontSize.replace("px",""));return b.default.createElement(V,{fontSize:a},b.default.createElement(L,{name:"amount",border:"0",placeholder:"0",warning:!1,value:e==="sell"?"":"0",onUserInput:()=>{}}))},[e]),n=(0,b.useMemo)(()=>b.default.createElement(k,{font:"caption",color:"textSecondary",children:"$0"}),[]),i=(0,b.useMemo)(()=>{let a=p=>{switch(p){case .25:return"25%";case .5:return"50%";case 1:return o("swapAssetCardMaxButton")}};return it.map(p=>b.default.createElement(J,{active:!1,children:a(p),variant:{size:"small"},onChange:()=>{}}))},[o]),s=(0,b.useMemo)(()=>b.default.createElement(b.default.Fragment,null,b.default.createElement("div",{className:ne.secondaryContainer},n,e==="sell"?b.default.createElement(O,{icon:"SwapVertical",size:20,shape:"circle",backgroundColor:"gray",color:"textSecondary"}):null),b.default.createElement("div",{className:ne.spacer}),b.default.createElement(ze,{font:"caption",width:64}),e==="sell"?b.default.createElement("div",{className:ne.filters},i):null),[i,n,e]);return b.default.createElement($,{perspective:e,input:r,isLoading:!0,selectorIcon:null,selectorLabel:"",onSelectorPress:()=>{},accessories:s})};var ie={container:u({display:"flex",flexDirection:"column",flex:1}),assets:u({position:"relative",gap:12,display:"flex",flexDirection:"column"}),centeredElement:u({position:"absolute",top:0,left:0,right:0,bottom:0,display:"flex",alignItems:"center",justifyContent:"center"})},Qe=({onSelectAsset:e,isLoadingInitialAssets:o})=>{let{buy:r,sell:n,switchPerspective:i,setAmount:s,switchCurrencyDenomination:a,setFilter:p}=Te(),{t:h}=S(),d=(0,C.useCallback)(async(x,c)=>{await Ce.capture("swapperSwapDefaultQuoteSelected",{data:{quotePercentageValue:x}}),p(x,c)},[p]),y=(0,C.useMemo)(()=>[{perspective:"sell",asset:n},{perspective:"buy",asset:r}].map(({asset:x,perspective:c})=>{if(!x)return C.default.createElement(Ue,{key:c,perspective:c,onSelectorTap:()=>e(c)});if(o)return C.default.createElement($e,{perspective:c});let A=x.filters.length>0?()=>p(1,c):void 0;return C.default.createElement(Oe,{key:c,asset:x,perspective:c,switchCurrencyDenomination:a,onFungibleTap:()=>e(c),onInputChange:B=>{s(c,B)},onFilterTap:B=>d(B,c),onBalanceTap:A})}),[n,r,o,a,d,e,s,p]);return C.default.createElement("div",{className:ie.container},C.default.createElement("div",{className:ie.assets},y,C.default.createElement("div",{className:ie.centeredElement,style:{pointerEvents:"none"}},C.default.createElement(De,{style:{pointerEvents:"auto"},label:h("swapperSwitchTokens"),size:32,shape:"circle",backgroundColor:"accentPrimary",color:"gray",onClick:i,icon:"SwapVertical"}))))};var l=P(I());f();w();var t=P(I());var Z=8,qe=t.default.memo(({onClick:e})=>t.default.createElement(ut,null,t.default.createElement(mt,{onClick:e},t.default.createElement(Ve,{fill:"#000000"})))),st=()=>{let e=Ae({isBalanceHidden:!1}),{handleShowModalVisibility:o}=M(),r=(0,t.useCallback)(()=>{o("swapSellAssetSelect")},[o]);return{...e,onSellAssetClicked:r}},He=()=>{let e=st();return t.default.createElement(at,{...e})},at=t.default.memo(({assetButtonTitle:e,assetSubheadline:o,decimals:r,formattedMaxSellAmount:n,sellFungible:i,notEnoughAssets:s,hasMinimumSellAmount:a,uiSellAmount:p,onSellAssetClicked:h,handleMaxButtonClick:d,updateSellAmount:y})=>{let{chain:x,logoUri:c,symbol:A,tokenAddress:B}=i.data;return t.default.createElement(se,{roundedTop:!0},t.default.createElement(pe,{"data-testid":"sell-token-button",onClick:h},t.default.createElement(j,{image:{type:"fungible",src:c,fallback:A||B},size:44,tokenType:i.type,chainMeta:x}),t.default.createElement(le,null,t.default.createElement(Ge,null,i.data.name),t.default.createElement(ae,null,o)),t.default.createElement(ee,{fill:"#999999"})),t.default.createElement(Ye,null,t.default.createElement(re,{dropdownTestID:"swap-sell-asset-dropdown",assetButtonTitle:e,decimals:r,disabled:!1,hasWarning:s||!a,isLoadingAmount:!1,isLoadingAssets:!1,onClick:h,onUserInput:y,value:p,maxSellAmount:n,setMaxSellAmount:d,fontSize:28})))}),pt=t.default.memo(({t:e,assetButtonTitle:o,assetSubheadline:r,buyAmount:n,currencyValue:i,decimals:s,symbol:a,logoUri:p,tokenAddress:h,tokenType:d,network:y,isFetchingQuote:x,onBuyAssetClicked:c,handleSwitchTokensClickLegacy:A})=>!y||!d?t.default.createElement(dt,{t:e,onClick:c}):t.default.createElement(t.default.Fragment,null,t.default.createElement(qe,{onClick:A}),t.default.createElement(se,{roundedBottom:!0},t.default.createElement(pe,{"data-testid":"buy-token-button",onClick:c},t.default.createElement(j,{image:{type:"fungible",src:p,fallback:a||h},size:44,tokenType:d,chainMeta:y}),t.default.createElement(le,null,t.default.createElement(Ge,null,o),t.default.createElement(ae,null,r)),t.default.createElement(ee,{fill:"#999999"})),t.default.createElement(Ye,null,t.default.createElement(re,{dropdownTestID:"swap-buy-asset-dropdown",assetButtonTitle:o,decimals:s,disabled:!0,hasWarning:!1,isLoadingAmount:x,isLoadingAssets:!1,onClick:c,onUserInput:()=>{},value:n,currencyValue:i,fontSize:28}))))),lt=()=>{let{t:e}=S(),{handleShowModalVisibility:o}=M(),r=(0,t.useCallback)(()=>{o("swapBuyAssetSelect")},[o]),{isSingleChainEnabled:n}=xe();return{...ve({isSingleChainEnabled:n}),onBuyAssetClicked:r,t:e}},je=()=>{let e=lt();return t.default.createElement(pt,{...e})},dt=({t:e,onClick:o})=>t.default.createElement(t.default.Fragment,null,t.default.createElement(qe,null),t.default.createElement(ct,{"data-testid":"buy-token-button",onClick:o},t.default.createElement(pe,null,t.default.createElement(ft,null,t.default.createElement(Me,{width:20})),t.default.createElement(le,null,t.default.createElement(ae,{size:16,weight:600},e("swapSelectToken")))))),se=m.div`
  background: #2a2a2a;
  border-top-right-radius: ${e=>e.roundedTop?Z:0}px;
  border-top-left-radius: ${e=>e.roundedTop?Z:0}px;
  border-bottom-right-radius: ${e=>e.roundedBottom?Z:0}px;
  border-bottom-left-radius: ${e=>e.roundedBottom?Z:0}px;
  padding: 8px;
`,ct=m(se).attrs({roundedBottom:!0})`
  cursor: pointer;
`,Ge=m(z).attrs({size:16,color:"#FFF",weight:600,lineHeight:19,textAlign:"left"})``,ae=m(z).attrs(e=>({size:e.size||14,color:"#777",weight:e.weight||400,lineHeight:17,textAlign:"left"}))``,ut=m.div`
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  height: 1px;
`,mt=m(oe).attrs({color:"#AB9FF2",diameter:32})`
  z-index: 0;
  cursor: pointer;
  &:hover {
    background: #e2dffe;
  }
  margin-top: -16px;
  margin-bottom: -16px;
`,ft=m(oe).attrs({color:"#181818",diameter:44})``,pe=m.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  cursor: pointer;
  &:hover {
    background: #333333;
  }
  padding: 8px;
  border-radius: 8px;
`,le=m.div`
  display: flex;
  flex-direction: column;
  margin-left: 10px;
  width: 100%;
`,Ye=m.div`
  padding: 0 0 8px 8px;
`;f();w();var W=P(I());var wt=()=>{let{t:e}=S();return W.default.createElement(te,{type:"submit",theme:"default",disabled:!0},e("swapFlowActionButtonText"))},gt=()=>{let{disabled:e,theme:o,title:r,onClick:n}=St();return W.default.createElement(te,{type:"submit",theme:o,disabled:e,onClick:n},r)},St=()=>{let{t:e}=S(),{hasEnoughAssets:o,hasNoRoutes:r,canSwap:n,hasNoFundsForFees:i,sourceNativeToken:s}=Fe(),a=Y(y=>y.setQuoteFetchIntervalToggle),{data:[p]}=be(["enable-swapper-v2"]),{handleShowModalVisibility:h}=M(),d=(0,W.useCallback)(()=>{i?h("insufficientBalance",{networkId:s.networkId,token:{balance:s.balance,required:s.required}}):(a(!1),h("swapReview"))},[i,h,s.networkId,s.balance,s.required,a]);return n?{disabled:!1,theme:"primary",title:e("swapFlowActionButtonText"),onClick:d}:o?r?{disabled:!0,theme:"default",title:e("swapNoQuotesFound"),onClick:d}:{disabled:!0,theme:"default",title:e("swapFlowActionButtonText"),onClick:d}:{disabled:!0,theme:"warning",title:e(p?"swapReviewInsufficientBalance":"sendFormErrorInsufficientBalance"),onClick:d}},_e=()=>{let{quoteResponse:e}=_();return e?W.default.createElement(gt,null):W.default.createElement(wt,null)};f();w();var q=P(I());f();w();var v=P(I());var bt=m.div`
  overflow-y: "scroll";
  padding-top: 16px;
`,ht=m.fieldset.attrs({disabled:!0})`
  pointer-events: none;
  user-select: none;
`,xt=m.div`
  position: absolute;
  z-index: 1;
  top: 0;
  height: 100vh;
  width: 100%;
  background-color: ${R("#222222",.75)};
`,Je=m.div`
  background-color: ${R("#E5A221",.7)};
  padding: 12px 15px;
  position: absolute;
  /* TODO: change 15px to 16px and create a screen padding constant like on mobile */
  top: -15px;
  left: -15px;
  right: 15px;
  width: calc(100% + 2 * 15px);
`,Ke=m(z).attrs({size:14,lineHeight:19,weight:500,color:"#fff",textAlign:"left"})``,Xe=({message:e,swapDisabled:o=!0,children:r})=>o?v.default.createElement(v.default.Fragment,null,v.default.createElement(xt,{"data-testid":"disable-overlay"},v.default.createElement(Je,null,v.default.createElement(Ke,null,e))),v.default.createElement(ht,{"data-testid":"disable-wrapper"},r)):v.default.createElement(bt,null,v.default.createElement(Je,null,v.default.createElement(Ke,null,e)),v.default.createElement(v.default.Fragment,null,r));var yt=m.div`
  display: flex;
  flex: 1;
  padding-bottom: 16px;
  margin-bottom: -16px; // fix extension padding issue when scrollable or not
`,Ze=q.default.memo(({children:e})=>{let r=ye().every(s=>he.isMainnetNetworkID(s)),{t:n}=S(),i=(0,q.useMemo)(()=>({availableOnlyOnMainnet:n("swapAvailableOnMainnet")}),[n]);return r?q.default.createElement(yt,null,e):q.default.createElement(Xe,{message:i.availableOnlyOnMainnet,swapDisabled:!0},e)});var Ct=()=>{let[e]=Be(),o=e.get("sellFungible")??void 0,r=e.get("sellAmount")??void 0,n=e.get("buyFungible")??void 0,i=Y(a=>a.resetSwapper);ke({skipInitialBuyFungible:!0}),Ie();let{isLoading:s}=Pe({paramsSellFungible:o,paramsSellAmount:r,paramsBuyFungible:n});return(0,l.useLayoutEffect)(()=>i,[i]),{isLoadingInitialAssets:s}},vt=({isLoadingInitialAssets:e})=>{let{quoteResponse:o,hasNoRoutes:r}=_(),n=Se.isFeatureEnabled("enable-swapper-v2"),{handleShowModalVisibility:i}=M(),s=(0,l.useCallback)(p=>{i(p==="sell"?"swapSellAssetSelect":"swapBuyAssetSelect")},[i]),a=(0,l.useMemo)(()=>n?l.default.createElement(Qe,{onSelectAsset:s,isLoadingInitialAssets:e}):l.default.createElement(l.default.Fragment,null,l.default.createElement(He,null),l.default.createElement(je,null)),[n,e,s]);return l.default.createElement(Ze,null,l.default.createElement(K,{justify:"space-between",flex:1},l.default.createElement(K,{align:"normal"},a,o||r?l.default.createElement(Ee,null):null),l.default.createElement(K,null,o?l.default.createElement(_e,null):null)))},At=()=>{let{isLoadingInitialAssets:e}=Ct();return e?l.default.createElement(l.default.Fragment,null,l.default.createElement(U,{height:"120px",borderRadius:"8px 8px 0 0"}),l.default.createElement(We,{gap:1}),l.default.createElement(U,{height:"120px",borderRadius:"0 0 8px 8px"})):l.default.createElement(vt,{isLoadingInitialAssets:e})},wr=At;export{wr as default};
