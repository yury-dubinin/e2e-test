import{f as s}from"./chunk-Y3KNGKBS.js";import{E as o,p as t}from"./chunk-OJG7N72N.js";import{a as g}from"./chunk-MVAHBHCD.js";import{f as x,h as i,n}from"./chunk-FPMOV6V2.js";i();n();var e=x(g());var A=t.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 100%;
  height: 83px;
  padding: 16px;
`,b=t.div`
  margin-left: 12px;
  width: 100%;
`,r=t(o).attrs({size:14,weight:400,color:"#999",textAlign:"left"})``,h=t.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`,u=t(o).attrs({size:28,lineHeight:32,weight:600,color:"#FFFFFF",textAlign:"left"})`
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
`,T=({title:l,network:a,tokenType:m,symbol:p,logoUri:w,tokenAddress:f,amount:c,amountUsd:d})=>e.default.createElement(A,null,e.default.createElement(s,{image:{type:"fungible",src:w,fallback:p||f},size:44,tokenType:m,chainMeta:a}),e.default.createElement(b,null,e.default.createElement(h,null,e.default.createElement(r,null,l),e.default.createElement(r,null,d)),e.default.createElement(u,null,c)));export{T as a};
