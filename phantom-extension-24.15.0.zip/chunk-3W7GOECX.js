import{a as K}from"./chunk-DNB2Z6FU.js";import{a as _}from"./chunk-QB2OYLHW.js";import{b as U,c as G,g as O,j as W}from"./chunk-DPCFVZS3.js";import{a as z}from"./chunk-PKMQW4MF.js";import{b as D}from"./chunk-BFWITKCK.js";import{C as f}from"./chunk-FGDP4DIS.js";import{a as F,k as M,t as B}from"./chunk-ICR7ECHM.js";import{t as E}from"./chunk-FDMFY2TH.js";import{Bb as V,ic as L,qb as P}from"./chunk-NAMHSCI2.js";import{a as H}from"./chunk-U4OVRE4G.js";import{B as N,E as n,p as a,y as I}from"./chunk-OJG7N72N.js";import{K as v,Kd as w,L as A,O as So,cc as k,hb as h}from"./chunk-Q5O4STUM.js";import{b as y}from"./chunk-PAHUG44L.js";import{r as p}from"./chunk-IVQ3W7KJ.js";import{a as go}from"./chunk-MVAHBHCD.js";import{f as fo,h as b,n as T}from"./chunk-FPMOV6V2.js";b();T();var o=fo(go());var xo=i=>{let{t}=p(),{voteAccountPubkey:s}=i,{showStakeAccountCreateAndDelegateStatusModal:Y,closeAllModals:j}=D(),J=()=>{i.onClose(),j()},{data:X}=w("solana"),{fungible:Z}=L({key:"SolanaNative"}),$=Z?.data.amount??"";E(X,"STAKE_FUNGIBLE");let{cluster:R,connection:u}=V(),r=B(u),oo=h("solana"),{data:to}=P({query:{data:oo}}),eo=to?.usd,e=(0,o.useMemo)(()=>r.results?.find(po=>po.voteAccountPubkey===s),[r.results,s]),no=e?.info?.name??e?.info?.keybaseUsername??k(s),ao=U(u),[l,g]=(0,o.useState)(""),m=y(l),c=v(1+(O(u).data??0)),S=G({balance:$,cluster:R,rentExemptionMinimum:c}),io=()=>g(S.toString()),ro=m.isLessThan(c),so=m.isGreaterThan(S),lo=m.isFinite(),d=l&&ro?t("validatorViewAmountSOLRequiredToStakeInterpolated",{amount:c}):l&&so?t("validatorViewInsufficientBalance"):"",mo=ao.isLoading,x=lo&&!d&&!mo,uo=()=>{Y({lamports:A(m).toNumber(),votePubkey:s,usdPerSol:eo,onClose:J,validatorName:no})},{data:C=null}=W(),co=C?M(C,e?.commission??0):null;return o.default.createElement(Co,null,r.isLoading?o.default.createElement(I,null):r.isError||!e?o.default.createElement(o.default.Fragment,null,o.default.createElement(f,null,t("validatorViewPrimaryText")),o.default.createElement(q,null,o.default.createElement(n,{size:16,color:"#777777",lineHeight:20},t("validatorViewErrorFetching")," ",r.error?.message??""))):o.default.createElement(o.default.Fragment,null,o.default.createElement(f,null,t("validatorViewPrimaryText")),o.default.createElement(q,null,o.default.createElement(n,{size:16,color:"#777777",lineHeight:20,margin:"0 0 20px 0"},o.default.createElement(H,{i18nKey:"validatorViewDescriptionInterpolated"},"Choose how much SOL you\u2019d like to ",o.default.createElement("br",null),"stake with this validator. ",o.default.createElement(Q,{href:F},"Learn more"))),o.default.createElement(z,{value:l,symbol:"SOL",alignSymbol:"right",buttonText:t("maxInputMax"),width:47,warning:!!d,onSetTarget:io,onUserInput:g}),o.default.createElement(To,null,o.default.createElement(n,{color:d?"#EB3742":"transparent",size:16,textAlign:"left"},d)),o.default.createElement(vo,{onEdit:i.onClose}),o.default.createElement(_,{identifier:e.voteAccountPubkey,name:e.info?.name,keybaseUsername:e.info?.keybaseUsername,iconUrl:e.info?.iconUrl,website:e.info?.website,data:[{label:t("validatorCardEstimatedApy"),value:o.default.createElement(n,{textAlign:"right",weight:500,size:14,noWrap:!0},co,"%")},{label:t("validatorCardCommission"),value:o.default.createElement(n,{textAlign:"right",weight:500,size:14,noWrap:!0},e.commission,"%")},{label:t("validatorCardTotalStake"),value:o.default.createElement(n,{textAlign:"right",weight:500,size:14,noWrap:!0},o.default.createElement(K,null,e.activatedStake))}]})),o.default.createElement(bo,null,o.default.createElement(N,{primaryText:t("validatorViewActionButtonStake"),secondaryText:t("commandClose"),onPrimaryClicked:uo,onSecondaryClicked:i.onClose,primaryTheme:x?"primary":"default",primaryDisabled:!x}))))},Ro=xo,Co=a.div`
  display: grid;
  grid-template-rows: 42px auto 47px;
  height: 100%;
`,q=a.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`,Q=a.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  color: #ab9ff2;
  text-decoration: none;
  cursor: pointer;
`,bo=a.section`
  display: flex;
  gap: 15px;
`,To=a.div`
  width: 100%;
`,yo=a(n)`
  width: 100%;
  margin-top: 15px;
  > a {
    color: #ab9ff2;
    cursor: pointer;
  }
`,vo=i=>{let{t}=p();return o.default.createElement(yo,{size:16,color:"#777777",lineHeight:20,textAlign:"left"},t("validatorViewValidator")," \u2022 ",o.default.createElement(Q,{onClick:i.onEdit},t("commandEdit")))};export{xo as a,Ro as b};
