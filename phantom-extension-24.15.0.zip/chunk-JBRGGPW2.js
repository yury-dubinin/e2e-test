import{m as x}from"./chunk-XBQBBV2G.js";import{rc as m,sc as B}from"./chunk-NAMHSCI2.js";import{D as T,p as s}from"./chunk-OJG7N72N.js";import{Gb as g}from"./chunk-Q5O4STUM.js";import{S as l}from"./chunk-PAHUG44L.js";import{a as p}from"./chunk-MVAHBHCD.js";import{f as i,h as d,n}from"./chunk-FPMOV6V2.js";d();n();var o=i(p());d();n();var a=i(p());var c=({text:e})=>a.default.createElement(k,null,a.default.createElement(y,null,e)),u=s.div`
  display: flex;
  align-items: center;
`,k=s.div`
  background: ${l("#FFFFFF",.1)};
  border-radius: 3px;
  padding: 0px 4px;
  color: white;
  display: inline-block;
  margin-left: 5px;
`,y=s(T).attrs({size:12,lineHeight:17,weight:600,noWrap:!0})``;var G=({children:e,networkID:r,walletAddress:t})=>o.default.createElement(u,null,e,t?o.default.createElement(F,{networkID:r,address:t}):null),F=({networkID:e,address:r})=>{let t=w({networkID:e,address:r});return t?o.default.createElement(c,{text:t}):null},H=({networkID:e,address:r})=>{let t=w({networkID:e,address:r});return t?o.default.createElement(x,{children:t,size:"small"}):null},w=({networkID:e,address:r})=>{let t=g();return B(t,e)?m(e,r)??null:null};export{c as a,k as b,G as c,F as d,H as e};
