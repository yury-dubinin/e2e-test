import{a as Pe}from"./chunk-UG36FTUI.js";import{a as je,b as Ce}from"./chunk-UMXXII74.js";import{a as Ie}from"./chunk-IB7UF4X6.js";import{a as Se,b as xe,h as he,k as ve}from"./chunk-QVVAGMA5.js";import{g as H}from"./chunk-W5GLT6IB.js";import{s as Ee}from"./chunk-FGDP4DIS.js";import{$ as ne,D as te,R as ie,S as re,da as se,fa as le,t as oe}from"./chunk-ZHACRE4R.js";import{ob as ce,pb as pe,qb as me,rb as ae,sb as de,tb as ue,ub as fe,vb as be}from"./chunk-KB2UMCDM.js";import{E as w,p as s,q as ge}from"./chunk-OJG7N72N.js";import{a as Ze}from"./chunk-LR3UNZEP.js";import{i as X,j as K}from"./chunk-T2EVB3DU.js";import{Dc as W,Ec as Q,sd as ee}from"./chunk-Q5O4STUM.js";import{V as N,c as Z}from"./chunk-PAHUG44L.js";import{r as M}from"./chunk-IVQ3W7KJ.js";import{a as C}from"./chunk-MVAHBHCD.js";import{f as v,h as a,n as d}from"./chunk-FPMOV6V2.js";a();d();var E=v(C());var Xe=s.nav`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`,eo=s.ul`
  display: flex;
  position: relative;
  z-index: 2;
  margin-top: 16px;
`,oo=s.div`
  position: absolute;
  width: 300vw;
  left: -100vw;
  bottom: 0px;
  height: 1px;
  background: #2c2d30;
`,to=s.li`
  position: relative;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-width: 0;
  position: relative;
  user-select: none;
  margin-right: 20px;
  padding-bottom: 15px;
`,io=s.div`
  position: absolute;
  z-index: 1;
  bottom: 0;
  left: -2px;
  height: 1px;
  width: calc(100% + 4px);
  background: #fff;
`,ro=s(w).attrs({size:16,lineHeight:19,weight:500})`
  color: ${e=>e.isSelected?"#fff":"#777"};
`,no=s.div`
  height: 100%;
  display: ${e=>e.isVisible?"block":"none"};
`,Bo=E.default.memo(({children:e,selectedIndex:r,setSelectedIndex:t,tabs:n})=>E.default.createElement(Xe,null,E.default.createElement(eo,{role:"tablist"},n.map((o,i)=>{let c=i===r;return E.default.createElement(to,{key:o,role:"tab","aria-controls":o,"aria-selected":c,tabIndex:0,onClick:()=>t(i)},E.default.createElement(ro,{isSelected:c},o),c?E.default.createElement(io,{as:ge.div,layoutId:"underline"}):null)}),E.default.createElement(oo,null)),e)),No=E.default.memo(({children:e,selectedIndex:r,tabs:t})=>E.default.createElement(E.default.Fragment,null,E.default.Children.map(e,(n,o)=>{let i=r===o;return E.default.createElement(no,{id:t[o],key:`page-${o}`,role:"tabpanel","aria-expanded":i,isVisible:i,tabIndex:i?0:-1},n)})));a();d();var ye=v(Ze()),k=v(C()),so=200,Do=()=>{let e=k.default.useRef(null),[r,t]=(0,k.useState)(0),n=()=>{e.current&&t(e.current?.scrollTop)},o=(0,k.useMemo)(()=>(0,ye.default)(n,so),[]);return k.default.useEffect(()=>{let i=e.current;return i?.addEventListener("scroll",o,{capture:!1,passive:!0}),()=>{i?.removeEventListener("scroll",o),o.cancel()}},[o]),{scrollContainerRef:e,scrollPosition:r}};a();d();var g=v(C());a();d();var L=v(C());a();d();var Te=46,lo=2,ke=`
  border: ${lo}px solid white;
  padding: 0px;
`,Ae=s.div`
  position: relative;
  display: flex;
  width: ${Te}px;
  height: ${Te}px;
  cursor: pointer;
  border-radius: 10px;
  padding: 2px;

  &:hover {
    ${ke}
  }

  ${e=>e.isSelected?ke:""}
`;var co=s.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
`,we=L.default.memo(()=>L.default.createElement(co,null,[...Array(9).keys()].map(e=>L.default.createElement(Ae,{isSelected:!1},L.default.createElement(je,{key:e,showBadge:!1})))));a();d();var b=v(C());var G=46,Oe=2,po=4,Le=G+Oe*2+po,mo=s.div`
  display: flex;
  gap: 10px;
`,Ge=`
  border: ${Oe}px solid white;
  padding: 0px;
`,ao=s.div`
  flex: 1;
  margin-top: 16px;
  margin-bottom: -20px;
`,uo=s.div`
  position: relative;
  display: flex;
  width: ${G}px;
  height: ${G}px;
  cursor: pointer;
  border-radius: 10px;
  padding: 2px;
  overflow: hidden;
  &:hover {
    ${Ge}
  }
  ${e=>e.isSelected?Ge:""}
`,fo=b.default.memo(e=>{let{collectible:r,previewIcon:t,onCollectibleSelect:n}=e,o=r?.media,i=o?.type??"image",c=ne(o,i,!1,"small"),p=(0,b.useCallback)(()=>{n(c)},[c,n]);return i!=="image"?null:b.default.createElement(uo,{"data-testid":`collectible-avatar-${r.name}`,isSelected:t.imageUrl===c,onClick:p},b.default.createElement(Ce,{uri:c??"",width:G,height:G}))}),bo=e=>{let{style:r,index:t,collectibleRows:n,previewIcon:o,onCollectibleSelect:i}=e,c=n[t];return b.default.createElement(mo,{style:r},c.map(p=>b.default.createElement(fo,{key:p.id,collectible:p,previewIcon:o,onCollectibleSelect:i})))},_e=b.default.memo(e=>{let{collectibles:r,previewIcon:t,onCollectibleSelect:n}=e,o=Pe(Le),i=(0,b.useMemo)(()=>Z(r,o),[r,o]);return b.default.createElement(ao,null,b.default.createElement(he,null,({height:c,width:p})=>b.default.createElement(ve,{height:c,width:p,rowCount:i.length,rowHeight:Le,rowRenderer:m=>b.default.createElement(bo,{...m,collectibleRows:i,previewIcon:t,onCollectibleSelect:n})})))});var go=s.div`
  display: flex;
  flex-direction: column;
  height: 100%;
`,vt=g.default.memo(e=>{let{accountIdentifier:r,previewIcon:t,onCollectibleSelect:n}=e,{t:o}=M(),[i,c]=(0,g.useState)(""),p=N(i)??"",{data:m}=ee(r),u=m?.addresses??[],h=(0,g.useCallback)(J=>{c(J.currentTarget.value)},[]),y=(0,g.useCallback)(()=>{c("")},[]),{data:A=[],isError:_,isLoading:$,refetch:F}=oe({addresses:u}),{getIsHidden:U,getIsSpam:z}=te(r??""),{collections:V}=ie({allCollections:A,getIsHidden:U,getIsSpam:z}),{collectibles:f}=re(V,[],[],p),I=le(f),R=se(I);return g.default.createElement(go,null,g.default.createElement(H,{value:i,placeholder:o("assetListSearch"),onChange:h,showClearIcon:i.length>0,onClear:y}),_?g.default.createElement(xe,{title:o("errorAndOfflineUnableToFetchCollectibles"),description:"",buttonText:o("homeErrorButtonText"),refetch:F}):$?g.default.createElement(Ie,null,g.default.createElement(we,null)):f.length===0?g.default.createElement(Se,null,o("collectiblesNoCollectibles")):!!m&&g.default.createElement(_e,{collectibles:R,previewIcon:t,onCollectibleSelect:n}))});a();d();var l=v(C());a();d();var P=v(C());var q={emojiSuggested:null,emojiSmileys:P.default.createElement(ce,null),emojiAnimals:P.default.createElement(pe,null),emojiFood:P.default.createElement(me,null),emojiTravel:P.default.createElement(ae,null),emojiActivities:P.default.createElement(de,null),emojiObjects:P.default.createElement(ue,null),emojiSymbols:P.default.createElement(fe,null),emojiFlags:P.default.createElement(be,null)},O=Object.keys(q),D=O[1];a();d();var x=v(C());a();d();var T=v(C());var Re=["1f468","1f469","1f9d1"],Eo="fe0f",So="200d",Be=`
  background: #fff;
  svg,
  path {
    fill: #000;
  }
`,xo=s.div`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 8px;
  cursor: pointer;
  transition: fill 200ms ease;
  min-height: 32px;
  width: 32px;
  margin: 4px 0;
  padding-top: 2px;
  svg,
  path {
    fill: #777777;
  }
  :hover {
    ${Be}
  }
  ${e=>e.isSelected?Be:""}

  font-family: "Twemoji Mozilla", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji",
    "EmojiOne Color", "Android Emoji", sans-serif;
  font-size: 24px;
`,Ne=T.default.memo(({code:e,name:r,skinTone:t,supportsSkinTone:n,previewIcon:o,onEmojiSelect:i})=>{let c=(0,T.useMemo)(()=>W(e),[e]),p=(0,T.useMemo)(()=>c?n&&t?ho(e,t):e:"",[e,c,t,n]),m=p===o.unicode,u=(0,T.useCallback)(()=>{i(p)},[p,i]);return c?T.default.createElement(xo,{role:"img",title:r,"aria-label":r,onClick:u,isSelected:m},p):null});function ho(e,r){let t=[...e].map(m=>{let u=m.codePointAt(0);return u?u.toString(16):""}),n=t.findIndex(m=>m===So),o=t.findIndex(m=>m===Eo),i=o>-1;if(n===-1){let m=i?o:t.length;t.splice(m,0,r)}else i&&o<n?t[o]=r:(t.splice(n,0,r),Re.includes(t[0])&&Re.includes(t[t.length-1])&&t.splice(t.length,0,r));return t.map(m=>String.fromCodePoint(parseInt(m,16))).join("")}var Me=s.div`
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 16px;
`,We=x.default.memo(({emojis:e,groupName:r,offset:t,previewIcon:n,scrollPosition:o,skinTone:i,onEmojiSelect:c,setActiveGroupName:p,setOffset:m})=>{let u=x.default.useRef(null),h=r===D,y=De({emojis:e,skinTone:i,previewIcon:n,onEmojiSelect:c});return x.default.useEffect(()=>{h&&u.current&&m(u.current.offsetTop)},[h,m]),x.default.useEffect(()=>{u.current&&o>=u.current.offsetTop-t&&p(r)},[r,t,o,p]),x.default.createElement(Me,{id:r,ref:u},y)}),He=x.default.memo(({emojis:e,groupName:r,previewIcon:t,skinTone:n,onEmojiSelect:o,resetActiveGroupName:i})=>{x.default.useEffect(()=>{i()},[i]);let c=De({emojis:e,skinTone:n,previewIcon:t,onEmojiSelect:o});return x.default.createElement(Me,{id:r},c)}),De=({emojis:e,previewIcon:r,skinTone:t,onEmojiSelect:n})=>(0,x.useMemo)(()=>e.map(o=>x.default.createElement(Ne,{key:o.n,code:o.c,name:o.n,skinTone:t,supportsSkinTone:o.t,previewIcon:r,onEmojiSelect:n})),[e,n,r,t]);a();d();var $e="_1qwevycoh";var vo=200,Je=-16,Qe=0,Ke=0,Fe=Je+Ke,jo=s.div`
  position: relative;
  z-index: 1;
  width: 100%;
  top: ${Qe}px;
  left: 0;
  padding: ${Ke}px 0;
  background: #222;
`,Co=s.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 16px;
`,Io=s.div`
  padding-top: ${Je}px;
`,Po=s.div`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 8px;
  cursor: pointer;
  transition: all 150ms ease;
  height: 32px;
  width: 32px;
  background: ${e=>e.isActive?"#333":"inherit"};

  svg,
  path {
    fill: #777777;
  }
  :hover {
    background: #333;
    path {
      fill: #fff;
    }
  }
`,yo=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 65px;
`,To=s.span`
  filter: grayscale(100%); // gray out emoji
  font-size: 38px;
  margin-bottom: 15px;
`,ko=s(w).attrs({size:16,lineHeight:19,weight:500,textAlign:"center",color:"#777"})``,Ue=s.div`
  padding-top: ${Fe}px;
  margin-top: -${Fe}px;
`,ze=s.div`
  position: sticky;
  top: -16px;
  padding-top: 8px;
  padding-bottom: 8px;
  background: #222;
`,Ve=s(w).attrs({size:13,lineHeight:16,weight:600,color:"#777",textAlign:"left"})``,Ao=l.default.memo(({groupName:e,isActive:r,containerRef:t,setActiveGroupName:n})=>{let o=l.default.useRef(null),i=(0,l.useCallback)(()=>{if(t&&t.current){let c=qe(e),p=document.getElementById(c);p&&t.current.scrollTo(0,p.offsetTop-Qe)}n(e)},[t,e,n]);return e==="emojiSuggested"?null:l.default.createElement(Po,{ref:o,isActive:r,onClick:i},q[e])}),fi=l.default.memo(({onEmojiSelect:e,containerRef:r,scrollPosition:t,skinTone:n,previewIcon:o})=>{let{t:i}=M(),[c,p]=l.default.useState(D),[m,u]=l.default.useState(0),[h,y]=(0,l.useState)(""),A=N(h,vo)??"",_=(0,l.useCallback)(()=>{p(O[0])},[]),$=(0,l.useMemo)(()=>O.map(f=>{let I=f===c;return l.default.createElement(Ao,{key:`icon-${f}`,containerRef:r,groupName:f,isActive:I,setActiveGroupName:p})}),[c,r]),F=(0,l.useMemo)(()=>O.map(f=>{let I=qe(f);return l.default.createElement(Ue,{key:I,id:I},l.default.createElement(ze,null,l.default.createElement(Ve,null,i(f))),l.default.createElement(We,{emojis:Q[f],groupName:f,previewIcon:o,scrollPosition:t,setActiveGroupName:p,skinTone:n,onEmojiSelect:e,offset:m,setOffset:u}))}),[i,o,t,n,e,m]),U=(0,l.useMemo)(()=>{if(!A)return null;let f=[],I=new Set,R=i("emojiSearchResults"),J=Object.values(Q);for(let Ye of J)for(let B of Ye)B.n.includes(A)&&!I.has(B.n)&&(I.add(B.n),f.push(B));return l.default.createElement(Ue,null,l.default.createElement(ze,null,l.default.createElement(Ve,null,R)),f.length>0?l.default.createElement(He,{emojis:f,groupName:R,previewIcon:o,skinTone:n,onEmojiSelect:e,resetActiveGroupName:_}):l.default.createElement(yo,null,W("\u{1FAE5}")&&l.default.createElement(To,null,"\u{1FAE5}"),l.default.createElement(ko,null,i("emojiNoResults"))))},[A,o,n,e,_,i]),z=(0,l.useCallback)(f=>y(f.currentTarget.value),[]),V=(0,l.useCallback)(()=>y(""),[]);return l.default.createElement("div",{className:$e},l.default.createElement(jo,null,l.default.createElement(H,{placeholder:i("assetListSearch"),value:h,showClearIcon:h.length>0,onChange:z,onClear:V}),l.default.createElement(Co,null,$)),l.default.createElement(Io,null,A?U:F))}),qe=e=>e?`emoji-group-${e}`:"";a();d();var S=v(C());var Y=s.div`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 8px;
  cursor: pointer;
  transition: fill 200ms ease;
  height: 24px;
  width: 24px;
  margin: 4px 0;
  :hover {
    background: #333;
  }
`,wo=s.div`
  position: relative;
  margin-right: 8px;
  ${Y} {
    border-radius: 4px;
    margin: 0;
  }
`,Lo=s.div`
  display: flex;
  align-items: center;
  position: absolute;
  z-index: 2;
  background: #333;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.25);
  border-radius: 4px;
  top: 0;
  right: 0;
`,Go=s.div`
  background: #474747;
  width: 1px;
  height: 12px;
`,vi=S.default.memo(({currentSkinTone:e,isVisible:r,onClick:t,onClose:n,onSelect:o})=>{let i=(0,S.useRef)(null);Ee(i,()=>{n()});let c=(0,S.useMemo)(()=>{let p=Object.values(X),m=p.findIndex(u=>u===e);return p.splice(m,1),p.push(e),p.map(u=>{let h="\u270B"+K[u],y=u===e;return S.default.createElement(S.default.Fragment,{key:`skin-tone-button-${h}`},y&&S.default.createElement(Go,null),S.default.createElement(Y,{key:u,onClick:()=>o(u)},h))})},[e,o]);return S.default.createElement(wo,{ref:i},S.default.createElement(Y,{onClick:t},"\u270B"+K[e]),r&&S.default.createElement(Lo,null,c))});export{Bo as a,No as b,Do as c,vt as d,fi as e,vi as f};
