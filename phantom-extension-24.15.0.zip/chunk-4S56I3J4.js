import{a as _}from"./chunk-CYZ74O6J.js";import{a as C}from"./chunk-5CR56F4P.js";import{a as D}from"./chunk-IB7UF4X6.js";import{e as P}from"./chunk-JBRGGPW2.js";import{c as g}from"./chunk-P3IBEZ5F.js";import{c as I}from"./chunk-W5GLT6IB.js";import{C as H,D as S}from"./chunk-FGDP4DIS.js";import{a as v}from"./chunk-7ZDPJAUC.js";import{a as w,l as T}from"./chunk-XBQBBV2G.js";import{t as b}from"./chunk-KB2UMCDM.js";import{A as B,E as c,p as t}from"./chunk-OJG7N72N.js";import{Oa as u,Rb as k,cc as y}from"./chunk-Q5O4STUM.js";import{r as x}from"./chunk-IVQ3W7KJ.js";import{a as h}from"./chunk-MVAHBHCD.js";import{f as l,h as m,n as a}from"./chunk-FPMOV6V2.js";m();a();var p=l(h());var ro=p.default.memo(({chainAddress:i,onQRClick:d})=>{let{networkID:s,address:e}=i,{t:n}=x(),{buttonText:f,copied:W,copy:A}=g(e),E=y(e,4),L=n(u.getNetworkName(s)),M=(0,p.useCallback)(O=>{O.stopPropagation(),A()},[A]);return p.default.createElement(T,{copied:W,copiedText:f,formattedAddress:E,networkBadge:p.default.createElement(P,{networkID:s,address:e}),networkLogo:p.default.createElement(C,{networkID:s,size:40}),networkName:L,onCopyClick:M,onQRClick:d})});m();a();var Q=l(_()),o=l(h());m();a();var r=l(h());var j=t.div`
  width: 100%;
`,F=t(I)`
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 6px 6px 0 0;
  border-bottom: none;
  margin: 0;
  padding: 16px 22px;
  font-size: 16px;
  font-weight: 500;
  line-height: 21px;
  text-align: center;
  resize: none;
  overflow: hidden;
`,U=t.button`
  display: flex;
  justify-content: center;
  align-items: center;
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 0 0 6px 6px;
  border-top: none;
  height: 40px;
  width: 100%;
  padding: 0;
  cursor: pointer;

  &:hover {
    background: #1c1c1c;
  }
`,q=t(c).attrs({size:16,weight:600,lineHeight:16})`
  margin-left: 6px;
`,z=({value:i})=>{let{buttonText:d,copy:s}=g(i),e=(0,r.useRef)(null);return(0,r.useEffect)(()=>{(()=>{if(e&&e.current){let f=e.current.scrollHeight;e.current.style.height=f+"px"}})()},[]),r.default.createElement(j,null,r.default.createElement(F,{ref:e,readOnly:!0,value:i}),r.default.createElement(U,{onClick:s},r.default.createElement(b,null),r.default.createElement(q,null,d)))};var G=48,So=o.default.memo(({address:i,networkID:d,headerType:s,onCloseClick:e})=>{let{t:n}=x();return o.default.createElement(o.default.Fragment,null,o.default.createElement(s==="page"?H:S,null,n("depositAddress")),o.default.createElement(D,null,o.default.createElement(v,{align:"center",justify:"center",id:"column"},o.default.createElement(Z,{id:"QRCodeWrapper"},o.default.createElement(R,{value:i,size:160,level:"Q",id:"styledqrcode"}),o.default.createElement(C,{networkID:d,size:G,borderColor:"bgWallet",className:w({position:"absolute"})}))),o.default.createElement(c,{size:16,lineHeight:22,weight:600,margin:"16px 0 8px"},n("depositAddressChainInterpolated",{chain:u.getNetworkName(d)})),o.default.createElement(z,{value:i}),o.default.createElement(c,{size:14,color:"#777777",lineHeight:20,margin:"16px 0"},n("depositAssetSecondaryText")," ",o.default.createElement(J,{href:k,target:"_blank",rel:"noopener noreferrer"},n("commandLearnMore")))),o.default.createElement(B,{onClick:e},n("commandClose")))}),R=t(Q.default)`
  padding: 8px;
  background: #ffffff;
  border-radius: 6px;
  position: relative;
`,Z=t.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
`,J=t.a`
  color: #ab9ff2;
  text-decoration: none;
  font-weight: 500;
`;export{ro as a,z as b,So as c};
