import{a as S}from"./chunk-JQSMP2U7.js";import{a as m}from"./chunk-7ZDPJAUC.js";import{q as y}from"./chunk-KB2UMCDM.js";import{E as p,p as o,y as R}from"./chunk-OJG7N72N.js";import{a as P}from"./chunk-MVAHBHCD.js";import{f as v,h as w,n as T}from"./chunk-FPMOV6V2.js";w();T();var t=v(P());var H=({description:r,rightNode:e,icon:i,title:n,secondaryTitle:s,type:l,onClick:a,testID:d,enabled:g=!0,stackTitleDescription:c,loading:x,...C})=>g?t.default.createElement(j,{onClick:a,"data-testid":d,style:c?{height:"unset"}:void 0,...C,...a&&{role:"button"}},D({type:l,title:n,secondaryTitle:s,icon:i,maxWidth:e===null?void 0:"260px",description:r,stackTitleDescription:c}),k(e,r,c,x)):t.default.createElement(t.default.Fragment,null),D=r=>{let{icon:e,type:i,maxWidth:n,title:s,secondaryTitle:l,stackTitleDescription:a,description:d}=r,g=a?L:m;return e?t.default.createElement(F,null,t.default.createElement(I,null,e),t.default.createElement(g,null,t.default.createElement(W,{color:i==="alert"?"#EB3742":"#FFFFFF",maxWidth:n},s),a&&d&&t.default.createElement(b,null,d)),l&&l!=="string"&&t.default.createElement(t.default.Fragment,null,l)):t.default.createElement(W,{color:i==="alert"?"#EB3742":"#FFFFFF",maxWidth:n},s)},k=(r,e,i,n)=>{if(r||r===null)return r;let s=n?t.default.createElement(R,{diameter:20}):t.default.createElement(y,{fill:"#777",height:12});return e&&!i?t.default.createElement(F,null,t.default.createElement(b,null,e),t.default.createElement(u,null,s)):t.default.createElement(u,null,s)},W=o(p).attrs({size:16,weight:500,lineHeight:19,noWrap:!0})``,b=o(p).attrs({size:14,weight:500,lineHeight:17,whiteSpace:"nowrap",color:"#777"})``,u=o.div`
  margin-left: 12px;
`,I=o.div`
  width: 24px;
  height: 24px;
  margin-right: 8px;
  display: flex;
  justify-content: center;
  align-items: center;
`,j=o.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #2a2a2a;
  border-radius: 12px;
  padding: 14px 15px;
  height: 47px;
  width: 100%;
  margin-bottom: 10px;

  &:last-of-type {
    margin-bottom: 0;
  }

  ${r=>r.onClick?`
  &:hover {
    background: #333;
    cursor: pointer;
    ${u} {
      path {
        fill: #fff;
      }
    }
  }`:""}
`,F=o(S)`
  flex-shrink: 1;
  width: auto;
  align-self: center;
`,L=o(m)`
  gap: 4px;
  margin-left: 4px;
`,ot=({groups:r})=>t.default.createElement($,null,r.map((e,i)=>t.default.createElement(t.Fragment,{key:`settings-group-${i}`},t.default.createElement(G,{...e})))),$=o.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,G=({title:r,rows:e})=>{let i=e.filter(n=>n.enabled===void 0||n.enabled);return t.default.createElement("div",null,i.map((n,s)=>t.default.createElement(t.Fragment,{key:`settings-${r}-row-${s}`},t.default.createElement(z,{isFirst:s===0,isLast:s===i.length-1,...n}))))},z=({enabled:r=!0,title:e,description:i,isFirst:n,isLast:s,rightNode:l,icon:a,type:d,opacity:g,onClick:c,testID:x})=>{if(!r)return t.default.createElement(t.default.Fragment,null);let C=typeof e=="string"?e:void 0,N=typeof i=="string"?i:void 0,f={onClick:c,rightNode:k(l,i),opacity:g,accessibilityLabel:C,accessibilityValue:N,type:d,title:e,icon:a,testID:x};return n&&s?t.default.createElement(h,{...f}):n?t.default.createElement(B,{...f}):s?t.default.createElement(M,{...f}):t.default.createElement(E,{...f})},h=o(H)`
  padding: 16px;
  height: unset;
  border-radius: 12px;
  margin: 0;
`,E=o(h)`
  border-radius: 0;
  border-top: 1px solid rgba(0, 0, 0, 0.25);
`,B=o(h)`
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
`,M=o(h)`
  border-top-right-radius: 0;
  border-top-left-radius: 0;
  border-top: 1px solid rgba(0, 0, 0, 0.25);
`,V=o.div`
  margin-bottom: 16px;
  width: 100%;
`,A=o(p).attrs({size:14,lineHeight:18,color:"#777"})`
  margin-top: 12px;
  text-align: left;
`,q=o(S).attrs({justify:"space-between"})`
  background: #2a2a2a;
  margin-bottom: 1px;
  padding: 14px 15px;

  ${r=>r.onClick?`
  &:hover {
    background: #333;
    cursor: pointer;
    ${u} {
      path {
        fill:#fff;
      }
    }
  }`:""};

  &:first-of-type {
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
  }
  &:last-of-type {
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    margin-bottom: 0;
  }
`,J=o.div`
  display: flex;
  align-items: center;
`,K=o(p).attrs({size:16,weight:500,lineHeight:19,noWrap:!0})``,O=o(p).attrs({size:16,weight:500,lineHeight:19,noWrap:!0,color:"#777"})``,Q=o(p).attrs({size:14,weight:400,lineHeight:17,color:"#777"})`
  margin-top: 10px;
  margin-right: 16px;
  text-align: left;
`,it=({rows:r})=>r.length===0?null:t.default.createElement(V,null,r.map((e,i)=>t.default.createElement(t.Fragment,{key:`card-row-${i}`},t.default.createElement(q,{disabled:e.disabled,onClick:e.onClick,align:"flex-start",...e.onClick&&{role:"button"}},t.default.createElement(m,null,t.default.createElement(J,null,t.default.createElement(K,{color:e.type==="alert"?"#EB3742":"#FFFFFF",maxWidth:e.description?"210px":"300px"},e.title),e.secondaryTitle&&t.default.createElement(O,null,"\xA0",e.secondaryTitle)),e.subtitle&&t.default.createElement(Q,null,e.subtitle)),e.rightNode!==void 0?e.rightNode:t.default.createElement(U,{...e})),e.helperText&&t.default.createElement(A,null,e.helperText)))),U=({description:r,onClick:e,type:i})=>e&&i!=="alert"?t.default.createElement(F,null,r?t.default.createElement(b,null,r):null,t.default.createElement(u,null,t.default.createElement(y,{fill:"#777",height:12}))):t.default.createElement(b,null,r);export{H as a,ot as b,it as c};
