import{b as R,c as Z,e as G}from"./chunk-JQQUUSH2.js";import{g as J,h as V,i as K}from"./chunk-ZHACRE4R.js";import{x as F}from"./chunk-PAHUG44L.js";import{F as q}from"./chunk-FJ67REU6.js";import{r as Y}from"./chunk-RO2HUFH7.js";import{a as E}from"./chunk-MVAHBHCD.js";import{f as C,h as u,n as p}from"./chunk-FPMOV6V2.js";u();p();var ct={data:""},dt=t=>typeof self=="object"?((t?t.querySelector("#_goober"):self._goober)||Object.assign((t||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:t||ct;var ut=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,pt=/\/\*[^]*?\*\/|  +/g,X=/\n+/g,w=(t,e)=>{let r="",a="",s="";for(let o in t){let n=t[o];o[0]=="@"?o[1]=="i"?r=o+" "+n+";":a+=o[1]=="f"?w(n,o):o+"{"+w(n,o[1]=="k"?"":e)+"}":typeof n=="object"?a+=w(n,e?e.replace(/([^,])+/g,i=>o.replace(/(^:.*)|([^,])+/g,l=>/&/.test(l)?l.replace(/&/g,i):i?i+" "+l:l)):o):n!=null&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=w.p?w.p(o,n):o+":"+n+";")}return r+(e&&s?e+"{"+s+"}":s)+a},x={},W=t=>{if(typeof t=="object"){let e="";for(let r in t)e+=r+W(t[r]);return e}return t},ft=(t,e,r,a,s)=>{let o=W(t),n=x[o]||(x[o]=(l=>{let c=0,d=11;for(;c<l.length;)d=101*d+l.charCodeAt(c++)>>>0;return"go"+d})(o));if(!x[n]){let l=o!==t?t:(c=>{let d,g,y=[{}];for(;d=ut.exec(c.replace(pt,""));)d[4]?y.shift():d[3]?(g=d[3].replace(X," ").trim(),y.unshift(y[0][g]=y[0][g]||{})):y[0][d[1]]=d[2].replace(X," ").trim();return y[0]})(t);x[n]=w(s?{["@keyframes "+n]:l}:l,r?"":"."+n)}let i=r&&x.g?x.g:null;return r&&(x.g=x[n]),((l,c,d,g)=>{g?c.data=c.data.replace(g,l):c.data.indexOf(l)===-1&&(c.data=d?l+c.data:c.data+l)})(x[n],e,a,i),n},mt=(t,e,r)=>t.reduce((a,s,o)=>{let n=e[o];if(n&&n.call){let i=n(r),l=i&&i.props&&i.props.className||/^go/.test(i)&&i;n=l?"."+l:i&&typeof i=="object"?i.props?"":w(i,""):i===!1?"":i}return a+s+(n??"")},"");function T(t){let e=this||{},r=t.call?t(e.p):t;return ft(r.unshift?r.raw?mt(r,[].slice.call(arguments,1),e.p):r.reduce((a,s)=>Object.assign(a,s&&s.call?s(e.p):s),{}):r,dt(e.target),e.g,e.o,e.k)}var tt,B,H,ae=T.bind({g:1}),f=T.bind({k:1});function et(t,e,r,a){w.p=e,tt=t,B=r,H=a}function m(t,e){let r=this||{};return function(){let a=arguments;function s(o,n){let i=Object.assign({},o),l=i.className||s.className;r.p=Object.assign({theme:B&&B()},i),r.o=/ *go\d+/.test(l),i.className=T.apply(r,a)+(l?" "+l:""),e&&(i.ref=n);let c=t;return t[0]&&(c=i.as||t,delete i.as),H&&c[0]&&H(i),tt(c,i)}return e?e(s):s}}u();p();var z=C(E(),1),A=C(E(),1),v=C(E(),1);var P=C(E(),1);var k=C(E(),1),ht=t=>typeof t=="function",L=(t,e)=>ht(t)?t(e):t,yt=(()=>{let t=0;return()=>(++t).toString()})(),ot=(()=>{let t;return()=>{if(t===void 0&&typeof self<"u"){let e=matchMedia("(prefers-reduced-motion: reduce)");t=!e||e.matches}return t}})(),gt=20,j=new Map,bt=1e3,rt=t=>{if(j.has(t))return;let e=setTimeout(()=>{j.delete(t),I({type:4,toastId:t})},bt);j.set(t,e)},xt=t=>{let e=j.get(t);e&&clearTimeout(e)},Q=(t,e)=>{switch(e.type){case 0:return{...t,toasts:[e.toast,...t.toasts].slice(0,gt)};case 1:return e.toast.id&&xt(e.toast.id),{...t,toasts:t.toasts.map(o=>o.id===e.toast.id?{...o,...e.toast}:o)};case 2:let{toast:r}=e;return t.toasts.find(o=>o.id===r.id)?Q(t,{type:1,toast:r}):Q(t,{type:0,toast:r});case 3:let{toastId:a}=e;return a?rt(a):t.toasts.forEach(o=>{rt(o.id)}),{...t,toasts:t.toasts.map(o=>o.id===a||a===void 0?{...o,visible:!1}:o)};case 4:return e.toastId===void 0?{...t,toasts:[]}:{...t,toasts:t.toasts.filter(o=>o.id!==e.toastId)};case 5:return{...t,pausedAt:e.time};case 6:let s=e.time-(t.pausedAt||0);return{...t,pausedAt:void 0,toasts:t.toasts.map(o=>({...o,pauseDuration:o.pauseDuration+s}))}}},N=[],U={toasts:[],pausedAt:void 0},I=t=>{U=Q(U,t),N.forEach(e=>{e(U)})},vt={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},wt=(t={})=>{let[e,r]=(0,z.useState)(U);(0,z.useEffect)(()=>(N.push(r),()=>{let s=N.indexOf(r);s>-1&&N.splice(s,1)}),[e]);let a=e.toasts.map(s=>{var o,n;return{...t,...t[s.type],...s,duration:s.duration||((o=t[s.type])==null?void 0:o.duration)||t?.duration||vt[s.type],style:{...t.style,...(n=t[s.type])==null?void 0:n.style,...s.style}}});return{...e,toasts:a}},St=(t,e="blank",r)=>({createdAt:Date.now(),visible:!0,type:e,ariaProps:{role:"status","aria-live":"polite"},message:t,pauseDuration:0,...r,id:r?.id||yt()}),M=t=>(e,r)=>{let a=St(e,t,r);return I({type:2,toast:a}),a.id},h=(t,e)=>M("blank")(t,e);h.error=M("error");h.success=M("success");h.loading=M("loading");h.custom=M("custom");h.dismiss=t=>{I({type:3,toastId:t})};h.remove=t=>I({type:4,toastId:t});h.promise=(t,e,r)=>{let a=h.loading(e.loading,{...r,...r?.loading});return t.then(s=>(h.success(L(e.success,s),{id:a,...r,...r?.success}),s)).catch(s=>{h.error(L(e.error,s),{id:a,...r,...r?.error})}),t};var kt=(t,e)=>{I({type:1,toast:{id:t,height:e}})},Ct=()=>{I({type:5,time:Date.now()})},Et=t=>{let{toasts:e,pausedAt:r}=wt(t);(0,A.useEffect)(()=>{if(r)return;let o=Date.now(),n=e.map(i=>{if(i.duration===1/0)return;let l=(i.duration||0)+i.pauseDuration-(o-i.createdAt);if(l<0){i.visible&&h.dismiss(i.id);return}return setTimeout(()=>h.dismiss(i.id),l)});return()=>{n.forEach(i=>i&&clearTimeout(i))}},[e,r]);let a=(0,A.useCallback)(()=>{r&&I({type:6,time:Date.now()})},[r]),s=(0,A.useCallback)((o,n)=>{let{reverseOrder:i=!1,gutter:l=8,defaultPosition:c}=n||{},d=e.filter(b=>(b.position||c)===(o.position||c)&&b.height),g=d.findIndex(b=>b.id===o.id),y=d.filter((b,_)=>_<g&&b.visible).length;return d.filter(b=>b.visible).slice(...i?[y+1]:[0,y]).reduce((b,_)=>b+(_.height||0)+l,0)},[e]);return{toasts:e,handlers:{updateHeight:kt,startPause:Ct,endPause:a,calculateOffset:s}}},Pt=f`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,It=f`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Tt=f`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,At=m("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Pt} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${It} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${t=>t.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Tt} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,Mt=f`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,$t=m("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${t=>t.secondary||"#e0e0e0"};
  border-right-color: ${t=>t.primary||"#616161"};
  animation: ${Mt} 1s linear infinite;
`,Dt=f`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,jt=f`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Nt=m("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Dt} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${jt} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${t=>t.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Ut=m("div")`
  position: absolute;
`,Lt=m("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,zt=f`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,_t=m("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${zt} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Rt=({toast:t})=>{let{icon:e,type:r,iconTheme:a}=t;return e!==void 0?typeof e=="string"?P.createElement(_t,null,e):e:r==="blank"?null:P.createElement(Lt,null,P.createElement($t,{...a}),r!=="loading"&&P.createElement(Ut,null,r==="error"?P.createElement(At,{...a}):P.createElement(Nt,{...a})))},Bt=t=>`
0% {transform: translate3d(0,${t*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Ht=t=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${t*-150}%,-1px) scale(.6); opacity:0;}
`,Qt="0%{opacity:0;} 100%{opacity:1;}",Ot="0%{opacity:1;} 100%{opacity:0;}",Ft=m("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Yt=m("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,qt=(t,e)=>{let r=t.includes("top")?1:-1,[a,s]=ot()?[Qt,Ot]:[Bt(r),Ht(r)];return{animation:e?`${f(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${f(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},Jt=v.memo(({toast:t,position:e,style:r,children:a})=>{let s=t.height?qt(t.position||e||"top-center",t.visible):{opacity:0},o=v.createElement(Rt,{toast:t}),n=v.createElement(Yt,{...t.ariaProps},L(t.message,t));return v.createElement(Ft,{className:t.className,style:{...s,...r,...t.style}},typeof a=="function"?a({icon:o,message:n}):v.createElement(v.Fragment,null,o,n))});et(k.createElement);var Vt=({id:t,className:e,style:r,onHeightUpdate:a,children:s})=>{let o=k.useCallback(n=>{if(n){let i=()=>{let l=n.getBoundingClientRect().height;a(t,l)};i(),new MutationObserver(i).observe(n,{subtree:!0,childList:!0,characterData:!0})}},[t,a]);return k.createElement("div",{ref:o,className:e,style:r},s)},Kt=(t,e)=>{let r=t.includes("top"),a=r?{top:0}:{bottom:0},s=t.includes("center")?{justifyContent:"center"}:t.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:ot()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${e*(r?1:-1)}px)`,...a,...s}},Zt=T`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,D=16,me=({reverseOrder:t,position:e="top-center",toastOptions:r,gutter:a,children:s,containerStyle:o,containerClassName:n})=>{let{toasts:i,handlers:l}=Et(r);return k.createElement("div",{style:{position:"fixed",zIndex:9999,top:D,left:D,right:D,bottom:D,pointerEvents:"none",...o},className:n,onMouseEnter:l.startPause,onMouseLeave:l.endPause},i.map(c=>{let d=c.position||e,g=l.calculateOffset(c,{reverseOrder:t,gutter:a,defaultPosition:e}),y=Kt(d,g);return k.createElement(Vt,{id:c.id,key:c.id,onHeightUpdate:l.updateHeight,className:c.visible?Zt:"",style:y},c.type==="custom"?L(c.message,c):s?s(c):k.createElement(Jt,{toast:c,position:d}))}))},he=h;u();p();u();p();var Gt=C(E());var at=F({minutes:5}),O=(t,e)=>q({enabled:t!==null&&e,cacheTime:at,staleTime:at,refetchInterval:!1,refetchOnMount:!1,...G(t)});u();p();var nt=C(E());u();p();function Xt(t,e){let r="type"in t&&t.type==="fungible"?t:null;if(!r)return!1;let a=r.platform==="all"||r.platform===e.platform,s=r.limitToTokenAddresses&&r.limitToTokenAddresses.length>0;return a&&!s?!0:a&&s?r.limitToTokenAddresses.some(o=>o===e.tokenAddress):!1}function Wt(t,e){let r=!("type"in t)||t.type==="collectible"?t:null;if(!r)return!1;let a=r.platform==="all"||r.platform===e.platform,s=r.limitToCollections&&r.limitToCollections.length>0;return a&&!s?!0:a&&s?r.limitToCollections.some(o=>o===e.collectionId):!1}var st=(t,e)=>t?t.filter(r=>e.type==="fungible"?Xt(r,e):Wt(r,e)).slice(0,20):[];u();p();var it=({input:t,shortcuts:e})=>{if(e.length===0)return[];let r=JSON.stringify(e);return t.collectionId&&(r=r.replaceAll("{{collectionId}}",t.collectionId)),t.tokenId&&(r=r.replaceAll("{{tokenId}}",t.tokenId)),t.ownerAddress&&(r=r.replaceAll("{{ownerAddress}}",t.ownerAddress)),JSON.parse(r)};var lt=(t,e,r)=>(0,nt.useMemo)(()=>{let a=it({input:e,shortcuts:t});return st(a,r)},[t,e,r]);function $(t){return!!(t&&typeof t=="object"&&"type"in t&&t.type==="fungible")}function te(t){return $(t)?R(t.externalUrl):R(t?.externalUrl)}function ee(t){return $(t)?!1:t?.collection.isSpam??!0}function re(t,e){let r=te(t),a=Z(r)&&!!r&&!ee(t)&&e,{data:s,isLoading:o}=O(a&&r?new URL(r):null,e),n=$(t)?"":oe(t)??"",i=$(t)?t.tokenAddress:t?.id??"",l=Y?"mobile":"desktop",c=$(t)?{platform:l,tokenAddress:i,type:"fungible"}:{platform:l,collectionId:n,type:"collectible"},d=lt(s??[],{collectionId:n,tokenId:i,ownerAddress:t?.owner},c);return{isLoading:!t||o&&a,shortcuts:a?d:[]}}var oe=t=>{if(t?.chainData){if(V(t.chainData))return t.chainData.contract;if(J(t.chainData))return t.collection.id;if(K(t.chainData))return t.chainData.firstCreatedInscriptionId}};u();p();u();p();export{f as a,L as b,h as c,me as d,he as e,re as f};
