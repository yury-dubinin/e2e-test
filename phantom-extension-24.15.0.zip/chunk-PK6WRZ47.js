import{d as h}from"./chunk-WK2JI25E.js";import{la as f}from"./chunk-KB2UMCDM.js";import{E as m,p as t}from"./chunk-OJG7N72N.js";import{a as S}from"./chunk-MVAHBHCD.js";import{f as A,h as a,n as p}from"./chunk-FPMOV6V2.js";a();p();var o=A(S());var P=t.div`
  display: flex;
  ${n=>n.isVisible?"cursor: pointer;":""}
  align-items: center;
  margin-right: ${n=>n.hasChildren?10:0}px;
  p {
    margin-right: 6px;
    white-space: nowrap;
  }
`,V=t.div`
  position: relative;
  top: 1px;
`,H=({children:n,fontWeight:c,fontSize:g=14,iconSize:I,info:r,lineHeight:b,tooltipAlignment:u,noWrap:d,textAlign:C="left",showInfoIcon:x=!0,textColor:T})=>{let[w,l]=(0,o.useState)(!1),i=!!r,e=i&&w,s=e?"#AB9FF2":"#777";return o.default.createElement(h,{label:i?r:o.default.createElement(o.default.Fragment,null),ariaLabel:"Info",color:"#000",alignment:u,isVisible:e,triggerParams:{onMouseEnter:()=>l(!0),onMouseLeave:()=>{l(!1)}}},o.default.createElement(P,{isVisible:e,hasChildren:!!n},o.default.createElement(m,{color:T??s,lineHeight:b,size:g,weight:c,noWrap:d,textAlign:C},n),i&&x?o.default.createElement(V,null,o.default.createElement(f,{fill:s,width:I})):null))};export{H as a};
