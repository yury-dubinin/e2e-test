import{a as l,b as x,c as m}from"./chunk-CZC7LOIE.js";import{Ta as p,Ua as b}from"./chunk-KB2UMCDM.js";import{E as u,p as r}from"./chunk-OJG7N72N.js";import{a as y}from"./chunk-MVAHBHCD.js";import{f as h,h as s,n as g}from"./chunk-FPMOV6V2.js";s();g();var n=h(y());var C=r.div`
  display: flex;
  flex-direction: column;
  background-color: ${o=>o.color};
  width: 100%;
  border-width: 1px;
  border-style: solid;
  border-color: ${o=>o.color};
  border-radius: 12px;
  gap: 8px;
`,k=r.div`
  display: flex;
  margin: 16px;
  gap: 8px;
`,A=r.div`
  display: flex;
  justify-content: ${o=>o.buttonCount===1?"center":"space-between"};
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  padding: 4px 8px;
`,w=r.div`
  padding: 3px;
`,W=r.button`
  border: none;
  background: transparent;
  color: #222222;
  cursor: pointer;
  padding: 8px;
  &:nth-child(1) {
    font-weight: 500;
  }
`,v=r(u).attrs({size:14,weight:400,lineHeight:17,textAlign:"left",wordBreak:"break-word"})``,E=({message:o,inverted:f=!1,variant:c="warning",actions:e,Icon:d})=>{let t="#2A2A2A",i="#222222";switch(d??=c==="warning"&&!f?b:p,c){case"warning":t=l;break;case"danger":t=x;break;case"error":i=m;break;default:t=l}return n.createElement(C,{color:t},n.createElement(k,null,n.createElement(w,null,n.createElement(d,{fill:i,width:18,height:18})),n.createElement(v,{color:i},o)),e.length===0?null:n.createElement(A,{buttonCount:e.length},e.map(a=>n.createElement(W,{key:a.label,onClick:a.onClick,type:"button"},a.label))))};export{E as a};
