import{E as d,l as n,p as m}from"./chunk-OJG7N72N.js";import{r as p}from"./chunk-OY2GAEXY.js";import{Ld as l}from"./chunk-Q5O4STUM.js";import{S as s}from"./chunk-PAHUG44L.js";import{a as h}from"./chunk-MVAHBHCD.js";import{f as T,h as a,n as c}from"./chunk-FPMOV6V2.js";a();c();var t=T(h());var v=o=>{let{txHash:e}=o,{data:i}=l("solana"),f=e&&i?{id:e,networkID:i}:void 0,{data:r}=p(f),x=(0,t.useCallback)(()=>{r&&self.open(r)},[r]);return t.default.createElement(w,{opacity:e?1:0,onClick:x},o.children)},w=m(d).attrs({size:16,weight:500,color:"#AB9FF2"})`
  margin-top: 18px;
  text-decoration: none;
  ${o=>o.opacity===0?n`
          pointer-events: none;
        `:n`
          &:hover {
            cursor: pointer;
            color: ${s("#e2dffe",.5)};
          }
        `}
  }
`;export{v as a};
