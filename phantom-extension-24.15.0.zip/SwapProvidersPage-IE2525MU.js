import{a as S}from"./chunk-4FHVYNCP.js";import{b as h,p as y}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import{a as x}from"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as u}from"./chunk-JQSMP2U7.js";import{a as c}from"./chunk-7ZDPJAUC.js";import{j as t}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import{O as g,R as b}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import{c as v}from"./chunk-Y6EZT3LZ.js";import"./chunk-JTW2FZNL.js";import"./chunk-B42X32Z2.js";import"./chunk-KB2UMCDM.js";import{p as m}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as P}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as $}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as A,h as w,n as f}from"./chunk-FPMOV6V2.js";w();f();var o=A($());var C=72,k=52,F=m.ul`
  margin: 0;
  padding: 0;
  height: ${e=>e.fullHeight?410:360}px;
  overflow: auto;
`,B=m.li`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  cursor: pointer;
  background: ${e=>e.isSelected?"#AB9FF2":"#2A2A2A"};
  border-radius: 6px;
  min-height: ${k}px;
  padding: 16px;
  margin-bottom: 10px;
  &:hover {
    background: ${e=>e.isSelected?"#e2dffe":"#333333"};
  }
`,I=m(B)`
  height: ${C}px;
  padding: 12px;
`,R=()=>{let{t:e}=P(),{handleHideModalVisibility:r}=y(),i=(0,o.useCallback)(()=>{r("swapProviders")},[r]),n=b(),p=(0,o.useCallback)(l=>{n.setSelectedProviderIndex(l),i()},[i,n]),d=n.rows.some(g),a=e(d?"swapProvidersTitle":"swapTopQuotesTitle");return{...n,hideSwapProvidersModal:i,onClick:p,isBridge:d,title:a}},T=({isBridge:e})=>o.default.createElement(o.default.Fragment,null,[...Array(5)].map((r,i)=>o.default.createElement(x,{key:`swap-provider-row-loader-${i}`,align:"center",width:"100%",height:`${e?C:k}px`,backgroundColor:"#2D2D2D",borderRadius:"8px",margin:"0 0 10px 0",padding:"10px"}))),V=o.default.memo(({rows:e,selectedProviderIndex:r,isLoadingProviders:i,title:n,isBridge:p,hideSwapProvidersModal:d,onClick:a})=>o.default.createElement(v,{onReset:d},o.default.createElement(h,{leftButton:{type:"close",onClick:d}},n),i?o.default.createElement(T,{isBridge:p}):o.default.createElement(F,{fullHeight:p},e.map((l,s)=>{let H=s===r;return g(l)?o.default.createElement(_,{key:`bridge-provider-row-${s}`,index:s,row:l,onClick:a}):o.default.createElement(W,{key:`provider-row-${s}`,index:s,row:l,onClick:a,isSelected:H})})))),E=()=>{let e=R();return o.default.createElement(V,{...e})},X=E,W=({index:e,row:r,isSelected:i,onClick:n})=>o.default.createElement(B,{isSelected:i,onClick:()=>n(e)},o.default.createElement(t,{font:"label",children:r.name,align:"left",color:i?"bgWallet":"white"}),o.default.createElement(t,{font:"label",children:r.amount,align:"right",color:i?"bgWallet":"textSecondary"})),_=({index:e,row:r,onClick:i})=>o.default.createElement(I,{onClick:()=>i(e)},r.logoURI?o.default.createElement(c,{flex:0,margin:"0 4px 0 0"},o.default.createElement(S,{src:r.logoURI,width:48,height:48})):null,o.default.createElement(c,{flex:1},o.default.createElement(u,{justify:"space-between"},o.default.createElement(t,{children:r.name,font:"labelSemibold",color:"white",align:"left"}),o.default.createElement(t,{children:r.amount,font:"labelSemibold",color:"white",align:"right"})),o.default.createElement(u,{justify:"space-between",padding:"8px 0 0 0"},o.default.createElement(t,{children:r.time.text,font:"label",color:r.time.isFast?"textSecondary":"accentAlert"}),o.default.createElement(t,{children:r.fee,font:"label",color:"textSecondary"}))));export{E as SwapProvidersPage,X as default};
