import{a as de}from"./chunk-2YSCGINX.js";import{a as ce}from"./chunk-6JTJBVH3.js";import{a as I}from"./chunk-OXEGUXTD.js";import"./chunk-A65D3ZQB.js";import"./chunk-D6G5BIYD.js";import{a as O}from"./chunk-73NY4HVH.js";import{a as ae,b as pe,c as me}from"./chunk-HLP5EEDN.js";import"./chunk-PK6WRZ47.js";import"./chunk-354SN5AZ.js";import{f as re,g as ie}from"./chunk-KLAGLWLU.js";import"./chunk-6LXDUOIB.js";import"./chunk-MDQQE27Q.js";import"./chunk-CZC7LOIE.js";import"./chunk-V5HJYMXJ.js";import{b as se,p as b}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import{z as v}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import{a as ne}from"./chunk-DDQ3VOL7.js";import"./chunk-QSY3A4J6.js";import{p as q}from"./chunk-U5GOBD2Y.js";import"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import{C as K,F as Y,r as L}from"./chunk-U2D7GPOT.js";import{t as G}from"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import{a as le}from"./chunk-U4OVRE4G.js";import"./chunk-Y6EZT3LZ.js";import"./chunk-JTW2FZNL.js";import"./chunk-B42X32Z2.js";import{Y as Z,da as R,ua as ee}from"./chunk-KB2UMCDM.js";import{A as F,B as te,E as y,c as J,l as X,p as s,q as E,r as V,y as oe}from"./chunk-OJG7N72N.js";import"./chunk-B3RYBV57.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Oa as B,yd as P}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{S as $}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as C}from"./chunk-IVQ3W7KJ.js";import{O as Q,ta as U,x as z}from"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import{j as _,k as j}from"./chunk-RO2HUFH7.js";import{a as k}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as h,h as S,n as g}from"./chunk-FPMOV6V2.js";S();g();var m=h(k());S();g();var u=h(k());S();g();var r=h(k());var we=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  width: 100%;
  padding: ${e=>e.addScreenPadding?"16px":"0"};
`,he=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex-grow: 1;
`,ke=s.div`
  width: 100%;
  > * {
    margin-top: 10px;
  }
  padding: 16px;
`,Pe=s.div`
  display: flex;
  justify-content: flex-end;
  position: absolute;
  width: 100%;
`,Fe=s.div`
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`,Ae=s.div`
  position: relative;
`,Be=s.div`
  position: absolute;
  top: 0;
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  svg {
    fill: #21e56f;
  }
`,Le=s(y).attrs({size:28,weight:500,color:"#FFFFFF"})`
  margin-top: 24px;
  margin-left: 12px;
  margin-right: 12px;
`,ue=s(y).attrs({size:16,weight:400,color:"#999999"})`
  margin-top: 9px;
  margin-left: 12px;
  margin-right: 12px;
  span {
    color: #999999;
    font-weight: bold;
  }
`,Ee=s(y).attrs({size:16,weight:500,color:"#AB9FF2"})`
  margin-top: 18px;
  text-decoration: none;
  ${e=>e.opacity!==0&&X`
      &:hover {
        cursor: pointer;
        color: #e2dffe;
      }
    `}
`,M=({description:e,header:t,icon:o,onClose:n,title:i,txLink:a,isClosable:p,disclaimer:d})=>{let{t:c}=C(),w=()=>{a&&self.open(a)};return r.default.createElement(we,null,t,r.default.createElement(he,null,r.default.createElement(V,{mode:"wait",initial:!0},r.default.createElement(E.div,{key:i,initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.2}},o)),r.default.createElement(Le,null,i),r.default.createElement(ue,null,e),a&&r.default.createElement(V,{mode:"wait",initial:!1},r.default.createElement(E.div,{key:a,initial:{opacity:0,y:16},animate:{opacity:1,y:0},exit:{opacity:0},transition:{duration:.2}},r.default.createElement(Ee,{opacity:1,onClick:w},c("swapTxConfirmationViewTransaction"))))),p&&n?r.default.createElement(ke,null,r.default.createElement(ue,null,d),p&&n?r.default.createElement(F,{onClick:n},c("commandClose")):null):null)},Ve=()=>r.default.createElement(Ae,null,r.default.createElement(oe,{diameter:94,color:"#21E56F",trackColor:$("#21E56F",.1)}),r.default.createElement(Be,null,r.default.createElement(Z,{width:38}))),fe=({ledgerAction:e,numberOfTransactions:t,cancel:o,ledgerApp:n})=>r.default.createElement(we,{addScreenPadding:!0},r.default.createElement(pe,{ledgerAction:e,numberOfTransactions:t,cancel:o,ledgerApp:n})),Se=({isBridge:e,estimatedTime:t,txLink:o,onClose:n})=>{let{t:i}=C(),a,p,d;return e?(a=i("swapTxBridgeSubmitted"),p=i("swapTxBridgeSubmittedDescription",{estimatedTime:t}),d=i("swapTxBridgeSubmittedDisclaimer")):(a=i("swapTxConfirmationTokensDepositedTitle"),p=i("swapTxConfirmationTokensDepositedBody")),r.default.createElement(M,{icon:r.default.createElement(O,{type:"success"}),description:p,title:a,disclaimer:d,txLink:o,onClose:n,isClosable:!0})},ge=({isBridge:e,sellAsset:t,buyAsset:o,txLink:n,isClosable:i,onClose:a})=>{let{t:p}=C(),d,c;if(e&&t){let w=`${t.amount} ${t.symbol}`,x=B.getNetworkName(t.networkID),f=`${o.amount} ${o.symbol}`,T=B.getNetworkName(o.networkID);d=p("swapTxBridgeSubmitting"),c=p("swapTxBridgeSubmittingDescription",{sellAmount:w,sellNetwork:x,buyAmount:f,buyNetwork:T})}else c=`${o.symbol||p("swapTxConfirmationTokens")} ${p("swapTxConfirmationTokensWillBeDeposited")} `,d=p("swapTxConfirmationSwappingTokens");return r.default.createElement(M,{icon:r.default.createElement(Ve,null),description:c,title:d,txLink:n,onClose:a,isClosable:i})},Oe=e=>self.open(e,"_blank"),H=({txErrorTitle:e,txErrorMessage:t,txErrorHelpButtonLink:o,txLink:n,onClose:i})=>r.default.createElement(M,{header:r.default.createElement(Pe,null,r.default.createElement(Fe,{onClick:()=>Oe(o)},r.default.createElement(R,{fill:"white"}))),icon:r.default.createElement(O,{type:"failure"}),description:t,onClose:i,title:e,txLink:n,isClosable:!0});var Ie=()=>{let{handleHideModalVisibility:e}=b(),t=J(),{popDetailView:o}=v(),{data:n}=P(),a=n?.type==="ledger",p=T=>Q.captureError(T,"swapper"),{data:[d]}=U(["kill-swapper-simulation"]),c=(0,u.useCallback)(()=>{e("swapReview")},[e]),w=(0,u.useCallback)(()=>{o()},[o]),x=(0,u.useCallback)(()=>{c(),t("/notifications")},[c,t]);return K({isSwapSimulationDisabled:d,isLedger:a,onError:p,goToSwapTab:c,goToSwapReview:w,goToActivityTab:x})},De=({txError:e,txErrorTitle:t,txErrorMessage:o,txErrorHelpButtonLink:n,txLink:i,executeSwap:a,numberOfTransactions:p,addressType:d,onClose:c})=>ae(e)?u.default.createElement(me,{ledgerActionError:e,onRetryClick:a,onCancelClick:c}):e?u.default.createElement(H,{txErrorTitle:t,txErrorMessage:o,txLink:i,onClose:c,txErrorHelpButtonLink:n}):u.default.createElement(fe,{ledgerAction:a,numberOfTransactions:p,cancel:c,ledgerApp:q(d)}),Me=u.default.memo(({isFailure:e,isLedger:t,isSuccess:o,isClosable:n,notEnoughSol:i,txError:a,txErrorTitle:p,txErrorMessage:d,txErrorHelpButtonLink:c,txLink:w,numberOfTransactions:x,addressType:f,isBridge:T,sellAsset:Te,buyAsset:ye,estimatedTime:ve,executeSwap:be,onClose:A,onSwapSuccess:W})=>t&&!w?u.default.createElement(De,{isBridge:T,txError:a,txErrorTitle:p,txErrorMessage:d,txErrorHelpButtonLink:c,txLink:w,numberOfTransactions:x,addressType:f,executeSwap:be,onClose:A}):i?u.default.createElement(de,{onCancelClick:A}):e?u.default.createElement(H,{txErrorTitle:p,txErrorMessage:d,txLink:w,txErrorHelpButtonLink:c,onClose:A}):o?u.default.createElement(Se,{isBridge:T,estimatedTime:ve,txLink:w,onClose:W}):u.default.createElement(ge,{isBridge:T,sellAsset:Te,buyAsset:ye,txLink:w,isClosable:!!n,onClose:W})),Ce=()=>{let e=Ie();return(0,u.useEffect)(()=>{!e.isReadyToExecute||e.isLedger||e.executeSwap()},[e.isReadyToExecute,e.isLedger]),u.default.createElement(Me,{...e})};S();g();var l=h(k());var He=s.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: 100%;
  width: 100%;
  overflow-y: scroll;
  padding: 16px;
`,Ne=s.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-top: -20px;
`,We=s(y).attrs({size:28,weight:500,color:"#FFFFFF"})`
  margin-top: 24px;
`,$e=s(y).attrs({size:16,weight:500,color:"#777777"})`
  padding: 0px 5px;
  margin-top: 9px;
  span {
    color: #ffffff;
  }
  label {
    color: #ab9ff2;
    cursor: pointer;
  }
`,_e=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: fit-content;
`,je=s.div`
  margin-top: auto;
  width: 100%;
`,ze=()=>{let{t:e}=C(),{mutateAsync:t}=re(),{pushDetailView:o}=v(),{handleHideModalVisibility:n}=b();return{onAgreeClick:(0,l.useCallback)(()=>{t(!0),o(l.default.createElement(N,null))},[t,o]),onCancelClick:()=>{n("swapReview")},t:e}},Qe=()=>{self.open(_,"_blank")},Ue=()=>{self.open(j,"_blank")},qe=l.default.memo(({onAgreeClick:e,onCancelClick:t,t:o})=>l.default.createElement(He,null,l.default.createElement(Ne,null,l.default.createElement(_e,null,l.default.createElement(ee,null),l.default.createElement(We,null,o("termsOfServicePrimaryText")),l.default.createElement($e,null,l.default.createElement(le,{i18nKey:"termsOfServiceDiscliamerFeesEnabledInterpolated"},"We have revised our Terms of Service. By clicking ",l.default.createElement("span",null,'"I Agree"')," you agree to our new",l.default.createElement("label",{onClick:Qe},"Terms of Service"),".",l.default.createElement("br",null),l.default.createElement("br",null),"Our new Terms of Service include a new ",l.default.createElement("label",{onClick:Ue},"fee structure")," for certain products.")))),l.default.createElement(je,null,l.default.createElement(te,{primaryText:o("termsOfServiceActionButtonAgree"),secondaryText:o("commandCancel"),onPrimaryClicked:e,onSecondaryClicked:t})))),xe=()=>{let e=ze();return l.default.createElement(qe,{...e})};var Ge=s.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  overflow-y: scroll;
  padding: 16px 16px ${78}px; // footer height + padding
`,Ke=s.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
`,Ye=s.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 16px;
  position: absolute;
  bottom: 0;
`,Je=s.div`
  background-color: #2a2a2a;
  border-radius: 6px;
  width: 100%;

  > *:first-child {
    border-bottom: 1px solid #222222;
  }
`,Xe=()=>{let{t:e}=C(),{handleHideModalVisibility:t}=b(),{pushDetailView:o}=v(),n=L(f=>f.setQuoteFetchIntervalToggle),i=L(f=>f.quoteResponse),{data:a}=P(),p=(0,m.useMemo)(()=>a?.addresses.find(f=>f.networkID===i?.sellToken.chainId),[a,i]);G(p,"SWAP_FUNGIBLE");let d=z.isFeatureEnabled("enable-swapper-v2"),c=(0,m.useCallback)(()=>o(m.default.createElement(Ce,null)),[o]),w=Y({enableSwapperV2:d,goToConfirmation:c}),x=(0,m.useCallback)(()=>{n(!0),t("swapReview")},[t,n]);return{...w,hideSwapReview:x,t:e}},Ze=m.default.memo(({buyToken:e,sellToken:t,hideSwapReview:o,onSwap:n,t:i})=>m.default.createElement(Ge,null,m.default.createElement(Ke,null,m.default.createElement(se,{leftButton:{type:"close",onClick:o}},i("swapReviewFlowPrimaryText")),m.default.createElement(Je,null,m.default.createElement(I,{...t,title:i("swapReviewFlowYouPay")}),m.default.createElement(I,{...e,title:i("swapReviewFlowYouReceive")})),m.default.createElement(ce,{isSwapReview:!0})),m.default.createElement(Ye,null,m.default.createElement(ne,{removeFooterExpansion:!0,removeShadowFooter:!0},m.default.createElement(F,{theme:"primary",onClick:n},i("swapReviewFlowActionButtonPrimary")))))),Re=()=>{let e=Xe();return m.default.createElement(Ze,{...e})},N=()=>{let{data:e}=ie();return e??!1?m.default.createElement(Re,null):m.default.createElement(xe,null)},wt=N;export{N as SwapReviewPage,wt as default};
