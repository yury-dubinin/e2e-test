import{a as r}from"./chunk-V5HJYMXJ.js";import{E as i,p as t}from"./chunk-OJG7N72N.js";import{h as o,n as e}from"./chunk-FPMOV6V2.js";o();e();var p=t.div`
  flex: 1;
  overflow: auto;
  padding: 20px 0;
`,a=t(p)`
  padding-top: 0;
  padding-bottom: 0;
`,s=t.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  flex: 1;
  padding: ${n=>n.size==="medium"?"20px":"30px"} 0 0;
`,g=t.section`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  > svg {
    margin-bottom: 16px;
  }
  > p {
    margin-bottom: 16px;
  }
`,f=t(i).attrs({size:16,lineHeight:22,weight:500,color:"#AB9FF2"})``,l=t.section`
  width: 100%;
  flex: 1;
  > * {
    margin-bottom: 10px;
  }
`,u=t(r).attrs({color:"#181818",diameter:94,includeDarkBoxShadow:!0})``,h=t.form`
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  ${l} {
    margin-top: 30px;
  }
`;export{p as a,a as b,s as c,g as d,f as e,l as f,u as g,h};
