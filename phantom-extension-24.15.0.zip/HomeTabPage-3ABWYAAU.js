import{a as Ye}from"./chunk-ESF6SLUG.js";import{b as Ge}from"./chunk-EPBOG6R3.js";import{a as We,b as ae,c as Ke,d as Qe,e as Xe,f as Je}from"./chunk-C3LFITEI.js";import"./chunk-HUNESHQZ.js";import"./chunk-DNB2Z6FU.js";import{a as je,b as Ze}from"./chunk-EIS4BUJH.js";import"./chunk-COXGWD2J.js";import"./chunk-DPCFVZS3.js";import{a as Ue}from"./chunk-7M2UDGHY.js";import"./chunk-5XCUMEAE.js";import"./chunk-4FHVYNCP.js";import"./chunk-PLKS6FEO.js";import{a as Oe,b as qe}from"./chunk-OR7WCMLA.js";import{a as $e}from"./chunk-3VB5AS4W.js";import"./chunk-YQDICQQM.js";import"./chunk-4FJRVTBJ.js";import"./chunk-EPFWUK4P.js";import"./chunk-246MQMRD.js";import{a as Pe}from"./chunk-ZGSW4SDC.js";import"./chunk-D6G5BIYD.js";import"./chunk-PK6WRZ47.js";import{a as Pn}from"./chunk-WZ7EKXIB.js";import"./chunk-4F52HJNC.js";import"./chunk-OILLFGJN.js";import"./chunk-UWQVMEE4.js";import"./chunk-PZLCHVHJ.js";import"./chunk-NRQGEP3J.js";import"./chunk-JQQUUSH2.js";import"./chunk-S366KFSE.js";import{a as ze,b as K,c as _e}from"./chunk-GTS5E7LO.js";import"./chunk-354SN5AZ.js";import"./chunk-UMXXII74.js";import"./chunk-IPG2S7ZF.js";import"./chunk-N5ZGUDXJ.js";import"./chunk-O6LPORXM.js";import"./chunk-TEDKHQ6I.js";import"./chunk-KLAGLWLU.js";import"./chunk-IB7UF4X6.js";import"./chunk-7HOFAWG5.js";import"./chunk-PLCKHDK3.js";import"./chunk-CZC7LOIE.js";import"./chunk-V5HJYMXJ.js";import{m as Le,n as Ve,o as He,p as W}from"./chunk-Y3KNGKBS.js";import{c as Ie,h as Me,k as De,l as Ne}from"./chunk-QVVAGMA5.js";import{a as Ee}from"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import{z as re}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as O}from"./chunk-JQSMP2U7.js";import{a as F}from"./chunk-7ZDPJAUC.js";import{j as G}from"./chunk-XBQBBV2G.js";import{b as Se,c as Fe}from"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-2OUSFATI.js";import"./chunk-QSY3A4J6.js";import"./chunk-U5GOBD2Y.js";import"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import"./chunk-OMHIKLMS.js";import"./chunk-MLAFUF6V.js";import"./chunk-CAX63KUB.js";import"./chunk-RZVI54SU.js";import"./chunk-BRQMZKX2.js";import"./chunk-ICR7ECHM.js";import"./chunk-SDQFBK4G.js";import"./chunk-AENF63HN.js";import{b as Y,c as Be}from"./chunk-ZJTWFWE3.js";import"./chunk-ZHACRE4R.js";import"./chunk-B3SQHPTA.js";import"./chunk-U2D7GPOT.js";import{e as he,o as ye}from"./chunk-FDMFY2TH.js";import{hc as be,i as fe}from"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{Ea as ke,U as xe,ca as Ce,ra as ve,sa as we,za as Ae}from"./chunk-KB2UMCDM.js";import{B as Te,E as k,p as r,q as ie}from"./chunk-OJG7N72N.js";import"./chunk-ZHWDN4FA.js";import"./chunk-7FZROKRY.js";import"./chunk-B3RYBV57.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import{d as ge,e as _}from"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Bd as de,Gd as pe,Id as J,Oa as ce,Wd as ue,yd as Z,zd as me}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{S as te,ha as oe,x as ne}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as V}from"./chunk-IVQ3W7KJ.js";import{ta as X}from"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as L}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as I,h as u,n as g}from"./chunk-FPMOV6V2.js";u();g();var i=I(L());u();g();var d=I(L()),on=I(Pn());u();g();var H=new ze(_);u();g();var R=I(L());u();g();var x=I(L());var Sn=r(ie.button)`
  background: none;
  background-color: rgba(60, 49, 91, 0.4);
  border: 1px solid rgb(60, 49, 91);
  border-radius: 8px;
  cursor: pointer;
  height: ${e=>e.isActive?74:.9*74}px; /* 0.9 is taken from parallaxAdjacentItemScale from the carousel on mobile */
  padding: 10px 12px;
  width: 100%;

  &:hover {
    background-color: rgba(60, 49, 91, 0.6);
  }
`,Fn=r(ie.div)`
  align-items: center;
  display: flex;
`,En=r.img`
  margin-right: 12px;
  width: 44px;
`,In=r(k).attrs({lineHeight:17,size:14})`
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  display: -webkit-box;
  flex: 1;
  overflow: hidden;
  text-align: left;
`,Mn=r.div`
  position: relative;
  top: -15px;
  right: -3px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  display: flex;
  height: 20px;
  justify-content: center;
  width: 20px;
`,Dn=({banner:e,isActive:n})=>{let{t}=V(),o=Ye(),{mutateAsync:a}=Be(),{handleShowModalVisibility:s,handleHideModalVisibility:m}=W(),h=(0,x.useCallback)(c=>{let f=K(e);switch(H.onBannerClick(f),e.bannerType){case"Deep Link":{let{destinationType:B,url:p}=e;o(c,{destinationType:B,url:p});break}case"Modal":{let{interstitial:B,destinationType:p,url:C}=e,{title:v,lineItems:A=[],imageUrl:w,primaryButtonText:T=t("commandContinue"),secondaryButtonText:P=t("commandDismiss")}=B,E=_e(e),D=A.map(S=>({icon:S.imageUrl,subtitle:S.description,title:S.title}));s("interstitial",{bodyTitle:v,details:D,icon:w,onDismiss:()=>{H.onInterstitialDismiss(E)},FooterComponent:()=>x.default.createElement(Te,{primaryText:T,secondaryText:P,onPrimaryClicked:()=>{o(c,{destinationType:p,url:C}),H.onInterstitialPrimaryClick(E),m("interstitial")},onSecondaryClicked:()=>{H.onInterstitialSecondaryClick(E),m("interstitial")}})}),H.onInterstitialSeen(E);break}}},[e,s,m,t,o]),y=(0,x.useCallback)(c=>{c.stopPropagation(),a({actionBannerId:e.id});let f=K(e);H.onBannerDismiss(f)},[e,a]);return(0,x.useMemo)(()=>({isActive:n,banner:e,onClickBanner:h,onCloseBanner:y}),[e,n,h,y])},Nn=x.default.memo(({banner:e,isActive:n,onClickBanner:t,onCloseBanner:o})=>x.default.createElement(Sn,{layout:!0,onClick:t,isActive:n},x.default.createElement(Fn,{layout:!0},x.default.createElement(En,{src:e.imageUrl}),x.default.createElement(In,{weight:600},e.description),x.default.createElement(Mn,{onClick:o},x.default.createElement(Ce,{fill:"#ffffff",width:8}))))),Re=e=>{let n=Dn(e);return x.default.createElement(Nn,{...n})};var Ln=r.ul`
  align-items: center;
  display: flex;
  margin-bottom: 8px;
  transition: transform 0.5s ease;
  transform: ${e=>`translateX(${e.currentIndex*-100}%)`};
`,Vn=r.li`
  align-items: center;
  display: flex;
  height: 74px;
  flex: 0 0 100%;
  padding: ${e=>e.isActive?"0":e.isNext||e.isPrevious?"0 6px":"0"};
`,en=({banners:e,currentIndex:n})=>R.default.createElement(Ln,{currentIndex:n},e.map((t,o)=>R.default.createElement(Vn,{key:t.id,isActive:n===o,isNext:n+1===o,isPrevious:n-1===o},R.default.createElement(Re,{banner:t,isActive:n===o}))));var Hn=r.div`
  height: 0;
  transition: height 0.2s ease-in-out;
  width: 100%;
  ${e=>e.animate?`height: ${e.shouldCollapse?"100px":"120px"}`:""}
`,zn=r.div`
  transition: transform 0.5s ease;
  width: 100%;
`,nn=r(Fe)``,tn=r.div`
  visibility: ${e=>e.isVisible?"visible":"hidden"};
`,_n=r.div`
  align-items: center;
  display: flex;
  justify-content: space-between;
`,On=()=>{let{data:e={banners:[]}}=Y(),{data:n}=me(),{banners:t}=e,o=(0,on.default)(n),[a,s]=(0,d.useState)(0),m=(0,d.useCallback)(()=>{s(y=>y+1)},[]),h=(0,d.useCallback)(()=>{s(y=>y-1)},[]);return(0,d.useEffect)(()=>{if(!(!t.length||!n))if(o!==n)s(0);else if(a>=t.length)s(t.length-1);else{let y=t[a],c=K(y);H.onBannerSeen(c)}},[a,t,n,o]),(0,d.useMemo)(()=>({banners:t,currentIndex:a,hasNextBanner:a<t.length-1,hasPrevBanner:a>0,onNextBannerClick:m,onPrevBannerClick:h}),[t,a,h,m])},qn=d.default.memo(({banners:e,currentIndex:n,hasNextBanner:t,hasPrevBanner:o,onNextBannerClick:a,onPrevBannerClick:s})=>{let m=e.length<=1;return d.default.createElement(Hn,{animate:e.length>0,shouldCollapse:m},d.default.createElement(zn,null,d.default.createElement(en,{banners:e,currentIndex:n}),!m&&d.default.createElement(_n,null,d.default.createElement(tn,{isVisible:o},d.default.createElement(nn,{onClick:s},d.default.createElement(ve,null))),d.default.createElement(Ge,{numOfItems:e.length,currentIndex:n,maxVisible:5}),d.default.createElement(tn,{isVisible:t},d.default.createElement(nn,{onClick:a},d.default.createElement(we,null))))))}),$n=()=>{let e=On();return d.default.createElement(qn,{...e})},rn=()=>{let{data:[e]}=X(["kill-action-banners"]);return e?null:d.default.createElement($n,null)};u();g();var l=I(L());var Un=r(F).attrs({align:"center"})`
  width: 100%;
  background: ${e=>e.background};
`,Gn=r(F).attrs({align:"center"})`
  margin-top: 2rem;
`,se=r(F).attrs({align:"center",justify:"center",width:"100%"})`
  height: 5.3rem;
`,an=r(Ee).attrs({height:"8px",borderRadius:"6px",backgroundColor:"#484848"})`
  opacity: 0.2;
`,sn=r(O)`
  height: 8px;
  border-radius: 6px;
  background-color: ${te("#999999",.5)};
  opacity: 0.5;
`,Wn=r(Ke)`
  margin-bottom: 11px;
`,jn=r.div`
  display: flex;
  flex-direction: row;
  padding: 16px 5px;
  justify-content: center;
  align-items: center;
  gap: 6px;
  flex: 1 0 0;
  border-radius: 62px;
  backdrop-filter: blur(2px);
  background: rgba(0, 0, 0, 0.2);
`,Zn=r(k).attrs({size:15,weight:"600",color:"#FFF",lineHeight:20})``,Kn=r(k).attrs({size:36,weight:"bold",color:"#777"})``,Qn=r(O).attrs({justify:"center"})``,Xn=r(k).attrs({weight:500,size:18})`
  margin-right: 6px;
`,Jn=r(k).attrs({weight:500,size:18})`
  border-radius: 6px;
  padding: 2px 5px;
`,Yn=r.div`
  display: flex;
  flex-direction: row;
  gap: 8px;
  width: 326px;
  margin-top: 2rem;
  margin-bottom: 22px;
  > * {
    box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.16);
  }
`,Rn=r.div`
  padding: 16px;
  padding-bottom: 0px;
`,et=r.div`
  padding: 32px 16px;
  width: 100%;
`,ln=l.default.memo(({hasFungibles:e,isErrorTokens:n,isLoading:t,isHidingAllFungibles:o,isReadOnlyAccount:a,value:s,earnings:m,showDollarValues:h,shouldShowPartialError:y,partialErrorMessage:c,ctaActions:f})=>{let{t:B}=V(),p=tt(m),C=nt({earnings:m,isNeutral:!h||t||o}),v=ot(s),A=it(m),w=rt(s,m),{buttonDisabled:T}=at({isLoading:t,isEnabled:e||o,isErrorTokens:n});return l.default.createElement(Un,{background:C},y?l.default.createElement(Rn,null,l.default.createElement(Qe,{partialErrorMessage:c})):null,l.default.createElement(Gn,null,h?t?l.default.createElement(se,null,l.default.createElement(an,{width:"184px",margin:"0 0 10px 0"}),l.default.createElement(an,{width:"112px"})):e||o?l.default.createElement(l.default.Fragment,null,l.default.createElement(Wn,{maxFontSize:38,fontWeight:600},v),l.default.createElement(Qn,null,l.default.createElement(Xn,{color:p},A),l.default.createElement(Jn,{color:p,backgroundColor:te(p,.1)},w))):n?l.default.createElement(se,null,l.default.createElement(sn,{width:"184px",margin:"0 0 10px 0"}),l.default.createElement(sn,{width:"112px"})):null:l.default.createElement(se,null,l.default.createElement(Kn,null,"\u2013"))),a?l.default.createElement(Yn,null,l.default.createElement(jn,null,l.default.createElement(xe,{width:20,height:20,fill:"#FFFFFF"}),l.default.createElement(Zn,null,B("readOnlyAccountBannerWarning")))):l.default.createElement(et,null,l.default.createElement(Ze,{disabled:T,actions:f,uiContextName:"home",maxButtons:4})))}),nt=({earnings:e,isNeutral:n})=>n||e===void 0||e===0?"linear-gradient(180deg, rgba(136, 136, 136, 0.05) 0%, rgba(136, 136, 136, 0) 100%)":e>0?"linear-gradient(180deg, rgba(33, 229, 111, 0.05) 0%, rgba(33, 229, 111, 0) 100%)":"linear-gradient(180deg, rgba(235, 55, 66, 0.05) 0%, rgba(235, 55, 66, 0) 100%)",tt=e=>e===void 0||e===0?"#777777":e>0?"#21E56F":"#EB3742",ot=e=>e===void 0?"-":e===0?"$0.00":oe(e),it=e=>e===void 0?"-":e===0?"+$0.00":oe(e,{includePlusPrefix:!0}),rt=(e,n)=>{let t=e===void 0,o=n===void 0,a=o||n>=0?"+":"-";return t||o?"-":`${a}${Math.abs(fe(e-n,e)).toFixed(2)}%`},at=({isLoading:e,isEnabled:n,isErrorTokens:t})=>{let o="primary",a=!1;switch(!0){case e:o="secondary",a=!0;break;case n:o="primary",a=!1;break;case t:o="secondary",a=!0}return{buttonTheme:o,buttonDisabled:a}};u();g();var z=I(L());var st=r(F).attrs({align:"center"})``,lt=r.div`
  width: 48px;
  height: 48px;
  position: relative;
  margin-bottom: 15px;
  border-radius: 100%;
  background: rgba(255, 220, 98, 0.2);
`,ct=r(O).attrs({align:"center",justify:"center"})`
  height: 100%;
`,mt=r(k).attrs({size:17,weight:500,lineHeight:22,margin:"0 0 10px 0"})``,dt=r(k).attrs({size:15,weight:500,lineHeight:21,margin:"0 0 15px 0",color:"#777777"})``,pt=r(k).attrs({size:16,weight:500,lineHeight:22,margin:"0",color:"#AB9FF2"})``,cn=z.default.memo(e=>z.default.createElement(st,null,z.default.createElement(lt,null,z.default.createElement(ct,null,z.default.createElement(ke,{width:22,exclamationFill:"transparent",circleFill:"#FFE920"}))),z.default.createElement(mt,null,e.title),z.default.createElement(dt,null,e.description),z.default.createElement(pt,{onClick:e.refetch},e.buttonText)));u();g();var j=I(L());var ut=r(O).attrs({justify:"center",margin:"0 auto",width:"auto"})`
  cursor: pointer;
  height: 48px;
  margin-bottom: 10px;
  p {
    font-weight: 500;
  }
  &:hover {
    p {
      color: #ab9ff2 !important;
    }
    svg {
      fill: #ab9ff2;
      path {
        stroke: #ab9ff2;
      }
      circle {
        stroke: #ab9ff2;
      }
    }
  }
`,gt=r(k).attrs({size:16,color:"#777777",weight:500,margin:"0 0 0 10px",lineHeight:19,noWrap:!0})``,mn=j.default.memo(e=>j.default.createElement(ut,{onClick:e.onClick},j.default.createElement(Se,null,j.default.createElement(Ae,null)),j.default.createElement(gt,null,e.buttonText)));u();g();var b=I(L());u();g();var dn={bannersStack:"_1qwevyc194 _1qwevyc16j _1qwevyczh _1qwevycf2 _1qwevycbl _1qwevyccx",bannersStackHeading:"_1qwevyce _1qwevyc2ta",banner:"_1lb45bv2",bannerTitle:"_1qwevycq _1qwevyc2tp _1qwevyc7",bannerDescription:"_1qwevych _1qwevyc2ta _1qwevycae _1qwevyczg",bannerImage:"_1qwevycyw _1qwevyc101"};var bn=()=>{let{data:[e]}=X(["enable-zero-balance-banners"]),{data:n}=Z(a=>a?.balance?.value===0),{data:t}=Y(),o=t&&t.banners.length>0;return!e||!n||o?null:b.default.createElement(ft,null)},ft=()=>{let{t:e}=V(),{handleShowModalVisibility:n,handleHideModalVisibility:t}=W(),{data:o}=Z(),a=(0,b.useCallback)(()=>{_.capture("zeroBalanceBannerBuyCryptoClickedByUser"),n("onramp")},[n]),s=(0,b.useCallback)(()=>{_.capture("zeroBalanceBannerDepositCryptoClickedByUser"),o&&n("receive",{account:o,onCloseClick:()=>t("receive")})},[t,n,o]);return b.default.createElement("div",{className:bt},b.default.createElement(G,{className:ht,children:e("zeroBalanceHeading")}),b.default.createElement("div",{className:pn,onClick:a},b.default.createElement(F,null,b.default.createElement(G,{className:un,color:"textSecondary",children:e("zeroBalanceBuyCryptoTitle")}),b.default.createElement(G,{className:gn,children:e("zeroBalanceBuyCryptoDescription")})),b.default.createElement("img",{className:fn,src:"/images/zero-balance/buy-crypto.svg"})),b.default.createElement("div",{className:pn,onClick:s},b.default.createElement(F,null,b.default.createElement(G,{className:un,color:"textSecondary",children:e("zeroBalanceDepositTitle")}),b.default.createElement(G,{className:gn,children:e("zeroBalanceDepositDescription")})),b.default.createElement("img",{className:fn,src:"/images/zero-balance/transfer-crypto.svg"})))},{bannersStack:bt,bannersStackHeading:ht,banner:pn,bannerTitle:un,bannerDescription:gn,bannerImage:fn}=dn;u();g();var Q=I(L());function hn(e,n,t){let o=J(),[a,s]=(0,Q.useState)(!1);(0,Q.useEffect)(()=>{o||s(!1)},[t,o]),(0,Q.useEffect)(()=>{a||!n.length||!e.length||o||(je.walletBalance(t,n,e),s(!0))},[t,n,e,a,o])}var yt=i.default.memo(({visibilityOverrides:e,fungibles:n,isMainnet:t,onMouseEnter:o})=>{let{t:a}=V(),{pushDetailView:s}=re(),m=(0,i.useRef)(document.getElementById("home-tab"));(0,i.useEffect)(()=>{let c=document.getElementById("home-tab");c&&(m.current=c)},[]);let h=(0,i.useCallback)(({networkID:c,chainName:f,fungibleKey:B,name:p,symbol:C,tokenAddress:v,type:A,walletAddress:w,spamStatus:T})=>{_.capture("assetDetailClick",{data:{address:v,chain:f,chainId:ce.getChainID(c),isNativeOfType:f,networkId:c,type:"fungible",spamStatus:T,name:p}}),s(i.default.createElement(Xe,{networkID:c,chainName:f,name:p,symbol:C,fungibleKey:B,tokenAddress:v,type:A,walletAddress:w}))},[s]),y=(0,i.useCallback)(({key:c,index:f,style:B})=>{let C=Math.min(f+1,n.length),v=[];for(let A=f;A<C;A++){let w=n[A],T=w.type,{chain:P,name:E,symbol:D,key:S,tokenAddress:N,walletAddress:q}=w.data,$=E??a("assetDetailUnknownToken");v.push(i.default.createElement(Ve,{...He(w,e),key:`${S}-${f}`,onClick:()=>h({networkID:P.id,chainName:P.name,fungibleKey:S,name:$,symbol:D,tokenAddress:N,type:T,walletAddress:q,spamStatus:w.data.spamStatus}),onMouseEnter:o,showBalance:!0,showCurrencyValues:t}))}return i.default.createElement("div",{key:c,style:B},v)},[n,t,h,o,a,e]);return i.default.createElement(Ne,{scrollElement:m.current??void 0},({height:c=0,isScrolling:f,registerChild:B,scrollTop:p})=>i.default.createElement(Me,{disableHeight:!0,style:{width:"100%"}},({width:C})=>i.default.createElement("div",{ref:B},i.default.createElement(De,{autoHeight:!0,width:C,height:c,scrollTop:p,isScrolling:f,rowCount:n.length,rowHeight:Le+10,rowRenderer:y}))))}),Bt=ne({seconds:5}),xt=ne({seconds:10}),Ct=()=>{let{data:e}=Z(),{shouldShowAdditionalPermissionsInterstitial:n}=qe(),{pushDetailView:t}=re(),o=ge("enable-base"),a=We(),{handleShowModalVisibility:s,handleHideModalVisibility:m,closeAllModals:h}=W(),y=(0,i.useCallback)(()=>{e&&s("onramp")},[s,e]),c=(0,i.useCallback)(()=>{e&&s("receive",{account:e,onCloseClick:()=>m("receive")})},[m,s,e]),f=(0,i.useCallback)(()=>{a({})},[a]),B=(0,i.useCallback)(()=>{s("sendFungibleSelect")},[s]),{t:p}=V(),C=(0,i.useMemo)(()=>({manageTokenList:p("homeManageTokenList"),errorTitle:p("homeErrorTitle"),errorDescription:p("homeErrorDescription"),errorButton:p("homeErrorButtonText")}),[p]),{ctaActions:v,shouldShowPartialError:A,partialErrorMessage:w}=ye({onTappingBuy:y,onTappingReceive:c,onTappingSend:B,onTappingSwap:f,account:e}),{accountBalance:T,accountId:P}=(0,i.useMemo)(()=>({accountBalance:e?.balance?.value,accountId:e?.identifier??""}),[e]),E=e?.isReadOnly,D=!J(),S=he(U=>U.resetSendSlice);(0,i.useEffect)(function(){P&&S()},[P,S]);let{fungibles:N,visibilityOverrides:q,portfolio:$,isHidingAllFungibles:yn,isLoadingVisibilityOverrides:Bn,isLoadingTokens:xn,isLoadingPrices:Cn,isErrorTokens:vn,refetch:wn}=be({useTokenQueryOptions:{staleTime:Bt,refetchInterval:xt}}),{mutate:An}=de();ue({accountBalance:T,accountId:P,enabled:D,value:$.value,setAccountBalance:An});let kn=pe();hn(N,kn,P);let Tn=(0,i.useMemo)(()=>({fungibles:N,earnings:$.earnings,value:$.value,isMainnet:D,translations:C,visibilityOverrides:q,ctaActions:v,showReceiveModal:c,handleShowModalVisibility:s,handleHideModalVisibility:m}),[q,N,$,C,D,c,s,m,v]),ee=ae(U=>U.publicFungibleDetailProps),le=ae(U=>U.clearNotifyHomeFungiblePush);return(0,i.useEffect)(()=>{ee&&(t(i.default.createElement(Je,{...ee})),le(),setTimeout(()=>h(),50))},[ee,t,le,h]),{data:Tn,isHidingAllFungibles:yn,isLoading:Bn||xn||Cn,isErrorTokens:vn,isReadOnlyAccount:E,refetch:wn,shouldShowPartialError:A,partialErrorMessage:w,shouldShowAdditionalPermissionsInterstitial:n,isBaseFeatureEnabled:o}},vt=()=>{let{data:e,isHidingAllFungibles:n,isLoading:t,isErrorTokens:o,isReadOnlyAccount:a,refetch:s,shouldShowPartialError:m,partialErrorMessage:h,shouldShowAdditionalPermissionsInterstitial:y,isBaseFeatureEnabled:c}=Ct(),{fungibles:f,translations:B,isMainnet:p,earnings:C,value:v,visibilityOverrides:A,ctaActions:w,handleShowModalVisibility:T}=e,{manageTokenList:P,errorTitle:E,errorDescription:D,errorButton:S}=B,N=f.length>0;return i.default.createElement("div",{id:"home-tab"},i.default.createElement(ln,{earnings:C,value:v,hasFungibles:N,isErrorTokens:o,isLoading:t,isHidingAllFungibles:n,isReadOnlyAccount:a,showDollarValues:p,shouldShowPartialError:m,partialErrorMessage:h,ctaActions:w}),i.default.createElement(F,{align:"center",padding:"0 16px 16px"},!a&&i.default.createElement(i.default.Fragment,null,i.default.createElement(bn,null),i.default.createElement(rn,null)),!Pe()&&i.default.createElement(i.default.Fragment,null,i.default.createElement($e,null)),y&&i.default.createElement(Oe,null),c&&i.default.createElement(Ue,null),t?[1,2,3].map(q=>i.default.createElement(Ie,{key:`fungible-token-row-loader-${q}`})):N?i.default.createElement(yt,{visibilityOverrides:A,fungibles:f,isMainnet:p}):n?null:i.default.createElement(cn,{title:E,description:D,buttonText:S,refetch:s}),t?null:N||n?i.default.createElement(mn,{buttonText:P,onClick:()=>T("fungibleVisibility")}):null))},Ji=vt;export{Ji as default};
