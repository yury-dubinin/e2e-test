import{A as r,E as o,p as e}from"./chunk-OJG7N72N.js";import{a as s}from"./chunk-MVAHBHCD.js";import{f as a,h as n,n as p}from"./chunk-FPMOV6V2.js";n();p();var t=a(s());var x=({tip:i,onClose:l})=>t.default.createElement(f,null,t.default.createElement(m,null,i.title),t.default.createElement(d,null,i.description),t.default.createElement(r,{onClick:l},"Close")),f=e.div`
  display: flex;
  flex-direction: column;
  padding: 16px;
  gap: 8px;
`,m=e(o)`
  text-align: left;
  font-size: 18px;
  font-style: normal;
  font-weight: 600;
  line-height: 26px;
  letter-spacing: 0.35px;
`,d=e(o)`
  text-align: left;
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 20px;
  letter-spacing: -0.24px;
  display: flex;
  align-items: center;
`,y=x;export{x as LearnTipModal,y as default};
