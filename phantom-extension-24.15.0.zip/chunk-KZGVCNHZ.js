import{a as O}from"./chunk-73NY4HVH.js";import{b as ue}from"./chunk-6TM7UJPN.js";import{a as se}from"./chunk-5CR56F4P.js";import{a as ot}from"./chunk-YO7AFFW5.js";import{b as rt,c as ct,d as Se}from"./chunk-6LXDUOIB.js";import{a as Y}from"./chunk-MDQQE27Q.js";import{c as nt}from"./chunk-JBRGGPW2.js";import{a as He}from"./chunk-2OUSFATI.js";import{a as Xe}from"./chunk-QSY3A4J6.js";import{a as Ze,l as Je}from"./chunk-U5GOBD2Y.js";import{m as Re,n as et}from"./chunk-Y44OMTJB.js";import{Pa as tt}from"./chunk-KB2UMCDM.js";import{A as N,E as j,p as i,z as ae}from"./chunk-OJG7N72N.js";import{Fb as qe,Gb as he,Gc as Ae,Jb as fe,Ma as G,Oa as q,Qd as Qe,W as Ke,X as Ue,Y as Ve,Zb as ge,cc as Ye}from"./chunk-Q5O4STUM.js";import{D as We,d as ve,ea as _e,ja as Ge}from"./chunk-PAHUG44L.js";import{b as je}from"./chunk-WGLF2QUC.js";import{r as H}from"./chunk-IVQ3W7KJ.js";import{ta as $e,va as ze}from"./chunk-FJ67REU6.js";import{a as te}from"./chunk-MVAHBHCD.js";import{f as ee,h as S,n as y}from"./chunk-FPMOV6V2.js";S();y();var bt={existingAccounts:{data:[],isFetched:!1,isError:!1},hardwareStepStack:[],hardwareStepSubStack:{},selectedChains:[],selectedChainsMap:new Map,chainImportStep:1,derivedAccountGroups:[],discoveredAccounts:[],activeAccountsFound:!1,selectedAccounts:{},onConnectHardwareAccounts:e=>Promise.resolve(),onConnectHardwareDone:()=>{}},k=Qe((e,o)=>({...bt,pushStep:t=>{let r=o().hardwareStepStack;e({hardwareStepStack:r.concat(t)})},popStep:()=>{let r=o().hardwareStepStack.length-1;if((o().hardwareStepSubStack[r]??[]).length)return e(Ae(s=>{s.hardwareStepSubStack[r]=s.hardwareStepSubStack[r].slice(0,-1)}));e(Ae(s=>{s.hardwareStepStack=s.hardwareStepStack.slice(0,-1)}))},pushSubStep:t=>{let c=o().hardwareStepStack.length-1,s=o().hardwareStepSubStack[c]??[];e(Ae(C=>{C.hardwareStepSubStack[c]=s.concat([t])}))},currentStep:()=>{let t=o().hardwareStepStack,r=o().hardwareStepSubStack,c=t.length>0?t.length-1:t.length;return r[c]?.length?ve(r[c]):ve(t)},setExistingAccounts:t=>{e({existingAccounts:t})},setSelectedChains:(t,r)=>{e({selectedChains:t,selectedChainsMap:r})},setDecrementChainImportStep:()=>{let t=o().chainImportStep;e({chainImportStep:t-1})},setIncrementChainImportStep:()=>{let t=o().chainImportStep;e({chainImportStep:t+1})},setDerivedAccountGroups:t=>{e({derivedAccountGroups:t})},setDiscoveredAccounts:(t,r)=>{e({discoveredAccounts:t,activeAccountsFound:r})},selectAccount:t=>{let c={...o().selectedAccounts};c[t]=!0,e({selectedAccounts:c})},deselectAccount:t=>{let c={...o().selectedAccounts};delete c[t],e({selectedAccounts:c})},setSelectedAccounts:t=>{e({selectedAccounts:t})},setOnConnectHardwareAccounts:t=>{e({onConnectHardwareAccounts:t})},setOnConnectHardwareDone:t=>{e({onConnectHardwareDone:t})}}));S();y();S();y();S();y();var at=i.main`
  width: ${420}px;
  min-height: ${480}px;
  position: relative;
  overflow: hidden;
  background-color: #222222;
  border: 1px solid #323232;
  border-radius: 16px;
  box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.4);
`;var uo=i(at)`
  display: flex;
  flex-direction: column;
`,mo=i.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  width: 100%;
  padding: 20px 20px;
`,X=i.div`
  padding-top: 44px;
`,M=i.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex: 1;
  width: 100%;
  overflow: auto;
`;S();y();var I=ee(te());S();y();var a=ee(te());S();y();var D=ee(te());S();y();var W=ee(te());var ye=()=>{let{t:e}=H(),{discoveredAccounts:o,selectedAccounts:t,onConnectHardwareAccounts:r,onConnectHardwareDone:c}=k(),{mutateAsync:s}=qe(),[C,b]=(0,W.useState)(!1),A=(0,W.useMemo)(()=>o.filter(n=>!!t[n.discoveryIdentifier]),[o,t]);return(0,W.useEffect)(()=>{if(A.length){let n=[],w=new Set;for(let h of A){let{accounts:x,seedIndex:P,accountIndex:v}=h,_=[],E=[];for(let m of x)Ke(m.derivationPathType)?(E.push({pathType:m.derivationPathType,value:m.publicKey}),(!("amount"in m)||parseFloat(m.amount)!==0)&&w.add(m.chainType)):(Ue(m.derivationPathType)||Ve(m.derivationPathType))&&_.push({pathType:m.derivationPathType,value:m.address});n.push({derivationIndex:P,addresses:_,publicKeys:E,accountIndex:v})}r({accounts:n}).then(()=>{w.size>0&&s({addressTypes:Array.from(w)})}).finally(()=>b(!0))}else b(!0)},[A,r,s]),W.default.createElement(M,null,W.default.createElement(X,null,W.default.createElement(Y,{icon:W.default.createElement(O,{type:"success"}),primaryText:e("connectHardwareAccountsAddedInterpolated",{numOfAccounts:A.length}),headerStyle:"large",secondaryText:e("connectHardwareFinishSecondaryText")})),W.default.createElement(N,{onClick:c,theme:"primary",disabled:!C},e("pastParticipleDone")))};S();y();var L=ee(te());S();y();var l=ee(te());var vt=(e,o,t)=>{switch(o){case"seed":return e("onboardingImportAccountsAccountName",{walletIndex:t});case"ledger":return e("onboardingImportAccountsLedgerAccountName",{walletIndex:t})}},Ht=({account:e})=>{let{t:o}=H();return l.default.createElement(Nt,null,l.default.createElement(It,null,l.default.createElement(se,{networkID:e.chain.id,size:40,borderColor:"bgRow"})),l.default.createElement(kt,null,l.default.createElement(Dt,null,l.default.createElement(nt,{networkID:e.chain.id,walletAddress:e.address},l.default.createElement(Ce,null,e.chain.name)),l.default.createElement(Ce,null,Ye(e.address,4))),l.default.createElement(we,null,"amount"in e&&"chain"in e?l.default.createElement(st,null,_e(e.amount)," ",e.chain.symbol):null,"amount"in e?l.default.createElement(st,null,e.lastActivityTimestamp?o("onboardingImportAccountsLastActive",{formattedTimestamp:We(e.lastActivityTimestamp*1e3,!0)}):o("onboardingImportAccountsCreateNew")):null)))},it=l.default.memo(({accountType:e,accounts:o,checked:t,accountIndex:r,onPress:c})=>{let{t:s}=H(),C=r+1;return l.default.createElement(dt,null,l.default.createElement(Ot,null,l.default.createElement(Ce,null,vt(s,e,C)),l.default.createElement(ue,{checked:t,onChange:c,"data-testid":"account-select-address-row-checkbox"})),o.map((b,A)=>l.default.createElement(Ht,{key:`${b.address}-${A}`,account:b})))}),Eo=l.default.memo(({totalAccounts:e,selectedAccounts:o,onPress:t})=>{let{t:r}=H();return l.default.createElement(dt,null,l.default.createElement(Pt,null,l.default.createElement(Ce,null,r("onboardingSelectAccountsNoOfAccountsSelected",{numOfAccounts:o}))," ",l.default.createElement(Bt,null,r("onboardingSelectAccountSelectAllText")," ",l.default.createElement(ue,{checked:o===e,onChange:t,"data-testid":"account-select-all-checkbox"}))))}),dt=i.div`
  margin-bottom: 24px;
  width: 100%;
`,It=i.div`
  flex-shrink: 0;
  margin-right: 10px;
`,kt=i.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`,we=i.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`,Dt=i(we)`
  margin-bottom: 2px;
`,Pt=i(we)`
  background: #2a2a2a;
  margin-bottom: 1px;
  padding: 12px 10px 12px 14px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,Bt=i.div`
  display: flex;
  align-items: center;
  gap: 10px;
`,Ot=i(we)`
  background: #2a2a2a;
  margin-bottom: 1px;
  padding: 12px 16px 12px 14px;
  border-top-left-radius: 6px;
  border-top-right-radius: 6px;

  & > span {
    margin-right: 0;
  }
`,Nt=i.div`
  background: #2a2a2a;
  margin-top: 1px;
  padding: 17px 16px 17px 14px;
  width: 100%;
  display: flex;
  align-items: center;

  &:last-of-type {
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
  }
`,Ce=i(j).attrs({size:16,lineHeight:19,weight:600})``,st=i(j).attrs({size:14,lineHeight:17,weight:400,color:"#777777"})``;var pt=({activeAccounts:e})=>{let{t:o}=H(),{selectedAccounts:t,selectAccount:r,deselectAccount:c,pushSubStep:s}=k(),C=(0,L.useMemo)(()=>Object.values(t).filter(n=>!!n).length===0,[t]),b=(0,L.useCallback)(()=>{s(L.default.createElement(ye,{preventBack:!0}))},[s]);return L.default.createElement(M,null,L.default.createElement("div",{style:{marginBottom:15}},L.default.createElement("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:30}},L.default.createElement(j,{weight:500,size:30,lineHeight:34,maxWidth:"320px"},o("connectHardwareSelectAccounts")),L.default.createElement(Lt,{wordBreak:"break-word",size:18,lineHeight:22,color:"#777777"},o("connectHardwareChooseAccountsToConnect"))),L.default.createElement("div",{style:{maxHeight:420,overflowY:"scroll"}},e.map(({accounts:A,discoveryIdentifier:n,accountIndex:w})=>{let u=!!t[n];return L.default.createElement(it,{key:n,accountType:"ledger",accounts:A,accountIndex:w,checked:u,onPress:()=>{u?c(n):r(n)}})}))),L.default.createElement(N,{onClick:b,theme:"primary",disabled:C},o("commandContinue")))},Lt=i(j)`
  margin-top: 15px;
`;var ut=()=>{let{t:e}=H(),{discoveredAccounts:o,activeAccountsFound:t,setSelectedAccounts:r,pushSubStep:c}=k(),s=(0,D.useMemo)(()=>{let A;if(t){let n=o.filter(w=>w.status==="undiscovered"||w.isSelectedByDefault);A=e(n.length===1?"connectHardwareFoundAccountsWithActivitySingular":"connectHardwareFoundAccountsWithActivity",{numOfAccounts:n.length})}else A=e("connectHardwareFoundSomeAccounts");return A},[t,e,o]),C=(0,D.useCallback)(()=>{c(D.default.createElement(pt,{activeAccounts:o}))},[c,o]),b=(0,D.useCallback)(()=>{c(D.default.createElement(ye,{preventBack:!0}))},[c]);return(0,D.useEffect)(()=>{let A=o.reduce((n,w,u)=>((w.status==="discovered"&&w.isSelectedByDefault||u===0)&&(n[w.discoveryIdentifier]=!0),n),{});r(A)},[o,r,t,e]),D.default.createElement(M,null,D.default.createElement(Et,null,D.default.createElement(Y,{icon:D.default.createElement(O,{type:"success"}),primaryText:e("connectHardwareConnectAccounts"),headerStyle:"large",secondaryText:s})),D.default.createElement(Mt,{onClick:C,theme:"default"},e("connectHardwareSelectAccounts")),D.default.createElement(N,{onClick:b,theme:"primary"},e("commandContinue")))},Et=i(X)`
  margin-bottom: 35px;
`,Mt=i(N)`
  margin-bottom: 10px;
`;var Ft=19,Wt=e=>{let o=new Set;for(let t of e)for(let{address:r}of t.addresses)o.add(r);return o},me=()=>{let{chainImportStep:e,setIncrementChainImportStep:o,selectedChains:t,selectedChainsMap:r,pushStep:c,pushSubStep:s,setDiscoveredAccounts:C,setDerivedAccountGroups:b}=k(),A=(0,a.useRef)(k.getState().derivedAccountGroups),{t:n,i18n:w}=H(),u=e-1,h=t[u],{data:x=[],isFetched:P,isError:v}=k(p=>p.existingAccounts),[_,E]=(0,a.useState)(!1),m=(0,a.useMemo)(()=>{let p=[],f=r.get(h)||{};for(let[g,R]of Object.entries(f))R&&p.push(g);return p},[h,r]),{chainNameTextOr:V,chainNameTextAnd:oe}=(0,a.useMemo)(()=>{let p=m.map(R=>q.getChainName(R)),f=new Intl.ListFormat(w.resolvedLanguage,{style:"long",type:"disjunction"}),g=new Intl.ListFormat(w.resolvedLanguage,{style:"long",type:"conjunction"});return{chainNameTextOr:f.format(p),chainNameTextAnd:g.format(p)}},[m,w]),ne=(0,a.useMemo)(()=>m.map(p=>a.default.createElement(se,{key:p,networkID:p,size:72,borderColor:"bgWallet"})),[m]);(0,a.useEffect)(()=>{let p=k.subscribe(f=>A.current=f.derivedAccountGroups);return()=>p()},[]);let F=(0,a.useMemo)(()=>{let p=[];switch(h){case"solana":{p.push({pathType:"bip44Root"});break}case"eip155":{p.push({pathType:"bip44RootEthereum"});break}case"bip122_p2tr":case"bip122_p2wpkh":case"bip122_p2sh":case"bip122_p2pkh":break}for(let f=0;f<Ft;++f)switch(h){case"solana":{p.push({index:f,pathType:"bip44Change"}),p.push({index:f,pathType:"bip44"});break}case"eip155":{p.push({index:f,pathType:"bip44Ethereum"}),p.push({index:f,pathType:"bip44EthereumSecondary"});break}case"bip122_p2tr":case"bip122_p2wpkh":case"bip122_p2sh":case"bip122_p2pkh":{p.push({index:f,pathType:"bitcoinTaproot"},{index:f,pathType:"bitcoinNativeSegwit"});break}}return p},[h]),[ie,de]=(0,a.useState)(!0),{data:re=Ze}=ct(ie,!0),{data:[be]}=$e(["kill-ledger-xpub-derivation"]),{data:J,error:De,fetchStatus:lt,refetch:Pe}=rt(re,F,!0,!be),ht=lt==="fetching",xe=!re.isConnected&&re.status!=="reconnecting",[ft,gt]=(0,a.useState)(!1),{data:le,refetch:Be}=Se(ft,!0);(0,a.useEffect)(()=>{xe&&de(!1)},[xe]),(0,a.useEffect)(()=>{le?.type==="granted"&&(de(!0),gt(!1))},[le]);let Oe=(0,a.useCallback)(async()=>{if(J&&Object.keys(J).length){let p=[...A.current],f=0;for(let g of Object.values(J)){let Z={accounts:{...(p[f]??{accounts:{}}).accounts},derivationIndex:F[f].index};switch(g.addressType){case"eip155":{m.includes(G.Polygon.Mainnet)&&(Z.accounts[`${G.Polygon.Mainnet}-${g.address}`]={chainType:g.addressType,chainId:G.Polygon.Mainnet,address:g.address,publicKey:g.publicKey,pathParams:F[f]}),m.includes(G.Ethereum.Mainnet)&&(Z.accounts[`${G.Ethereum.Mainnet}-${g.address}`]={chainType:g.addressType,chainId:G.Ethereum.Mainnet,address:g.address,publicKey:g.publicKey,pathParams:F[f]});break}case"solana":{Z.accounts[`${G.Solana.Mainnet}-${g.address}`]={chainType:g.addressType,address:g.address,publicKey:g.publicKey,chainId:G.Solana.Mainnet,pathParams:F[f]};break}case"bip122_p2tr":case"bip122_p2wpkh":case"bip122_p2sh":case"bip122_p2pkh":{Z.accounts[`${G.Bitcoin.Mainnet}-${g.address}`]={chainType:g.addressType,address:g.address,publicKey:g.publicKey,chainId:G.Bitcoin.Mainnet,pathParams:F[f]};break}}p[f]=Z,f++}if(b(p),P&&t.length===e){E(!0);let g=Wt(x),R=p.reduce((d,B)=>{let pe=!1;for(let{address:Me}of Object.values(B.accounts))pe=pe||g.has(Me);return pe||d.push(B),d},[]),Z=[],Ne=[];for(let d=0;d<R.length;d+=He.extension){let B=R.slice(d,d+He.extension).map(pe=>Object.entries(pe.accounts).reduce((Fe,[Ct,wt])=>(Fe[Ct]={account:wt},Fe),{}));Ne.push(B)}for(let d of Ne)Z.push(Xe(d));let Te=(await Promise.all(Z)).flat().map(d=>{switch(d.status){case"discovered":return{...d,accounts:d.accounts.filter(B=>B.hasAccountActivity||ge(B.derivationPathType))};case"undiscovered":return{...d,accounts:d.accounts.filter(B=>ge(B.derivationPathType))}}}).filter(d=>d.accounts.length>0).map(d=>{let B=je();return{...d,discoveryIdentifier:B}}),Le=Te.filter(d=>d.status==="undiscovered"||d.isSelectedByDefault),At=Te.filter(d=>!(d.status==="undiscovered"||d.isSelectedByDefault)).slice(0,2),Ee=Le.length>0,St=x.filter(d=>d.type==="ledger").length,yt=(Ee?[...Le,...At]:Te.filter(d=>!d.accounts.some(B=>!ge(B.derivationPathType))).slice(0,3)).map((d,B)=>({...d,accountIndex:St+B}));C(yt,Ee),c(a.default.createElement(ut,{preventBack:!0}))}}},[J,b,P,t.length,e,F,m,x,C,c]);(0,a.useEffect)(()=>{J&&Object.keys(J).length===F.length&&(Oe(),t.length!==e&&(o(),s(a.default.createElement(me,{preventBack:!0}))))},[J,F,c,s,e,t,Oe,o]);let $,z,K,Q,ce=()=>{};return v?($=a.default.createElement(O,{type:"failure"}),z=n("connectHardwareErrorLedgerGeneric"),K=n("connectHardwareErrorLedgerPhantomLocked"),ce=async()=>{let p=await Re();p.id!==void 0&&et(p.id)},Q=n("commandClose")):le&&le.type!=="granted"?($=a.default.createElement(O,{type:"warning"}),z=n("connectHardwarePermissionDeniedPrimary"),K=n("connectHardwarePermissionDeniedSecondary"),Q=n("homeErrorButtonText"),ce=Be):xe?($=a.default.createElement(O,{type:"warning"}),z=n("connectHardwarePermissionUnableToConnect"),K=n("connectHardwarePermissionUnableToConnectDescription"),Q=n("commandConnect"),ce=Be):De instanceof Je?($=a.default.createElement(O,{type:"failure"}),z=n("connectHardwareErrorLedgerLocked"),K=n("connectHardwareErrorLedgerLockedDescription"),Q=n("homeErrorButtonText"),ce=Pe):De?($=a.default.createElement(O,{type:"failure"}),z=n("connectHardwareErrorLedgerGeneric"),K=n("connectHardwareErrorLedgerGenericDescription"),Q=n("homeErrorButtonText"),ce=Pe):re.status=="reconnecting"?($=a.default.createElement(O,{defaultIcon:a.default.createElement(ae,null),type:"default"}),z=n("connectHardwareConnecting"),K=n("connectHardwareConnectingDescription")):_?($=a.default.createElement(O,{defaultIcon:a.default.createElement(ae,null),type:"default"}),z=n("connectHardwareDiscoveringAccounts"),K=n("connectHardwareDiscoveringAccountsDescription")):ht?($=a.default.createElement(O,{defaultIcon:a.default.createElement(ae,null),type:"default"}),z=n("connectHardwareConnectingAccounts"),K=n("connectHardwareFindingAccountsWithActivity",{chainName:oe})):($=a.default.createElement(Gt,null,ne),z=n("connectHardwareOpenAppInterpolated",{app:V}),K=n("connectHardwareOpenAppDescription")),a.default.createElement(M,null,a.default.createElement(X,null,a.default.createElement(Y,{icon:$,primaryText:z,headerStyle:"large",secondaryText:K})),Q?a.default.createElement(N,{onClick:ce,theme:"primary"},Q):a.default.createElement(_t,null,a.default.createElement(j,{color:"#999999",size:14},n("connectHardwareAccountsStepOfSteps",{stepNum:e,totalSteps:t.length}))))},_t=i.div`
  align-self: center;
  background-color: rgba(255, 255, 255, 0.03);
  border-radius: 80px;
  padding: 8px 16px;
  max-width: 150px;
`,Gt=i.div`
  display: flex;
  align-items: center;

  & > *:not(:last-child) {
    margin-right: -12.5px;
  }
`;S();y();var T=ee(te());var mt=()=>{let{t:e}=H(),{pushSubStep:o,selectedChains:t,setSelectedChains:r,selectedChainsMap:c}=k(),s=fe(),C=he(),b=(0,T.useCallback)(u=>{let h=new Map(c),x=q.getAddressTypes(u);for(let v of x){let _=c.get(v),E=_?.[u];h.set(v,{..._,[u]:!E})}let P=C.filter(v=>{let _=h.get(v)||{};return Object.values(_).reduce((m,V)=>V?++m:m,0)>0});r(P,h)},[C,r,c]),A=()=>{o(T.default.createElement(me,{preventBack:!0}))};ot(()=>{let u=new Map;for(let h of C)u.set(h,{});for(let h of s){let x=q.getAddressTypes(h);for(let P of x){let v=u.get(P);u.set(P,{...v,[h]:!1})}}r(t,u)},C.length>0&&s.length>0);let n=(0,T.useMemo)(()=>s.map(u=>{let h=q.getAddressTypes(u),x=!1;for(let P of h)x=c.get(P)?.[u]||x;return T.default.createElement(jt,{key:u,icon:T.default.createElement(se,{networkID:u,size:40}),networkID:u,onPressChain:b,isChecked:x})}),[s,c,b]),w=(0,T.useMemo)(()=>{let u=0;for(let h of c.values())u+=Object.values(h).reduce((x,P)=>P?++x:x,0);return u===0},[c]);return T.default.createElement(M,null,T.default.createElement(j,{weight:500,size:28,lineHeight:34},e("connectHardwareSelectChains")),T.default.createElement(Kt,null,n),T.default.createElement(N,{onClick:A,theme:"primary",disabled:w},e("commandContinue")))},jt=({networkID:e,icon:o,onPressChain:t,isChecked:r})=>T.default.createElement($t,{onClick:()=>{t(e)}},T.default.createElement(Ut,null,T.default.createElement(zt,null,o),T.default.createElement(j,{size:16,weight:600},q.getNetworkName(e))),T.default.createElement(ue,{checked:r})),$t=i.div`
  align-items: center;
  background-color: #2a2a2a;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  margin-bottom: 12px;
  padding: 16px 24px 16px 12px;

  :last-child {
    margin-bottom: 28px;
  }

  > span {
    margin-right: 0px;
  }
`,zt=i.div`
  margin-right: 12px;
`,Kt=i.div`
  margin-top: 20px;
`,Ut=i.div`
  display: flex;
  align-items: center;
`;var Vt=()=>{ze();let{t:e}=H(),{pushStep:o,setSelectedChains:t}=k(),r=fe(),c=he(),{data:s,isFetching:C,refetch:b}=Se(!0,!0),{buttonDisabled:A,defaultIcon:n,primaryText:w,secondaryText:u,buttonText:h,iconType:x,onClick:P}=(0,I.useMemo)(()=>{let v=!1,_=I.default.createElement(ae,null),E,m,V,oe="default",ne=Ge;if(C)E=e("connectHardwareSearching"),m=e("connectHardwareMakeSureConnected"),V=e("commandContinue"),v=!0;else if(s?.type==="granted"){let F=s.transport.deviceModel?.productName??"Ledger";oe="success",E=e("connectHardwarePairSuccessPrimary",{productName:F}),m=e("connectHardwarePairSuccessSecondary",{productName:F}),V=e("commandContinue"),v=!1,ne=()=>{if(c.length===1){let ie=new Map;ie.set(c[0],{});for(let de of r){let re=q.getAddressTypes(de);for(let be of re)ie.set(be,{[de]:!0})}t(c,ie),o(I.default.createElement(me,{preventBack:!0}))}else o(I.default.createElement(mt,{onBackCallback:()=>{t([],new Map)}}))}}else s?.type==="denied"?(oe="failure",E=e("connectHardwarePermissionDeniedPrimary"),m=e("connectHardwarePermissionDeniedSecondary"),V=e("commandTryAgain"),v=!1,ne=b):(!s||s.type==="unable-to-connect")&&(oe="failure",E=e("connectHardwarePermissionUnableToConnect"),m=e("connectHardwareWaitingForApplicationSecondaryText"),V=e("commandTryAgain"),v=!1,ne=b);return{buttonDisabled:v,defaultIcon:_,primaryText:E,secondaryText:m,buttonText:V,iconType:oe,onClick:ne}},[r,c,s,o,b,C,t,e]);return I.default.createElement(M,null,I.default.createElement(X,null,I.default.createElement(Y,{icon:I.default.createElement(O,{defaultIcon:n,type:x}),primaryText:w,headerStyle:"large",secondaryText:u})),I.default.createElement(N,{onClick:P,theme:"primary",disabled:A},h))},mr=()=>{let{t:e}=H(),{pushSubStep:o}=k(),t=()=>o(I.default.createElement(Vt,null));return I.default.createElement(M,null,I.default.createElement(X,null,I.default.createElement(Y,{icon:I.default.createElement(tt,null),primaryText:e("connectHardwareLedger"),headerStyle:"large",secondaryText:e("connectHardwareStartConnection"),animateText:!0})),I.default.createElement(N,{onClick:t,theme:"primary"},e("commandConnect")))};export{k as a,at as b,uo as c,mo as d,it as e,Eo as f,mr as g};
