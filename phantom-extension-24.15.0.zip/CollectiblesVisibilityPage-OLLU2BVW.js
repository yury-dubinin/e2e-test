import{a as Z}from"./chunk-RMMNWLLC.js";import{a as $}from"./chunk-H2CM5FKR.js";import{a as B}from"./chunk-ZTOKCQHE.js";import{a as U}from"./chunk-354SN5AZ.js";import{b as G}from"./chunk-UMXXII74.js";import"./chunk-IPG2S7ZF.js";import{b as F}from"./chunk-N5ZGUDXJ.js";import{p as j}from"./chunk-Y3KNGKBS.js";import{h as z,k as V,s as Q}from"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import{g as O}from"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as x}from"./chunk-JQSMP2U7.js";import{a as _}from"./chunk-7ZDPJAUC.js";import{a as P,b as D}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import{a as N}from"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import{$ as v,T as W,ba as L,ca as k,j as M}from"./chunk-ZHACRE4R.js";import"./chunk-B3SQHPTA.js";import"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{y as A}from"./chunk-KB2UMCDM.js";import{A as E,E as w,p as s}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{yd as H}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as p}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as T}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as y,h as S,n as I}from"./chunk-FPMOV6V2.js";S();I();var t=y(T());S();I();var o=y(T());var K=P({marginLeft:4}),X=s(x).attrs({align:"center",padding:"10px"})`
  background-color: #2a2a2a;
  border-radius: 6px;
  height: 74px;
  margin: 4px 0;
`,Y=s.div`
  display: flex;
  align-items: center;
`,R=s(_)`
  flex: 1;
  min-width: 0;
  text-align: left;
  align-items: normal;
`,tt=s(w).attrs({size:16,weight:600,lineHeight:19,noWrap:!0,maxWidth:"175px",textAlign:"left"})``,et=s(w).attrs({color:"#777777",size:14,lineHeight:17,noWrap:!0})`
  text-align: left;
  margin-top: 5px;
`,ot=s.div`
  width: 55px;
  min-width: 55px;
  max-width: 55px;
  height: 55px;
  min-height: 55px;
  max-height: 55px;
  aspect-ratio: 1;
  margin-right: 10px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
`,q=o.default.memo(e=>{let{t:n}=p(),{collection:i,unknownItem:m,isHidden:r,isSpam:a,onToggleHidden:d}=e,{name:c,id:h}=i,l=L(i),g=l?.chainData,f=k(i),u=v(l?.media,"image",!1,"small"),C=c||l?.name||m;return o.default.createElement(X,null,o.default.createElement(ot,null,a&&r?o.default.createElement(Z,{width:32}):u?o.default.createElement(G,{uri:u}):M(g)?o.default.createElement($,{...g.utxoDetails}):o.default.createElement(F,{type:"image",width:42})),o.default.createElement(x,null,o.default.createElement(R,null,o.default.createElement(Y,null,o.default.createElement(tt,null,C),a?o.default.createElement(A,{className:K,fill:D.colors.legacy.accentWarning,height:16,width:16}):null),o.default.createElement(et,null,n("collectiblesSearchNrOfItems",{nrOfItems:f})))),o.default.createElement(U,{id:h,label:`${c} visible`,checked:!r,onChange:b=>{d(b.target.checked?"show":"hide")}}))});var it=74,nt=10,lt=it+nt,st=20,rt=s.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
`,at=s.div`
  position: relative;
  width: 100%;
`,mt=()=>{let{handleHideModalVisibility:e}=j(),{data:n,isLoading:i}=H(),{viewState:m,viewStateLoading:r}=W({account:n}),a=(0,t.useCallback)(()=>e("collectiblesVisibility"),[e]),d=(0,t.useMemo)(()=>({...m,handleCloseModal:a}),[a,m]),c=(0,t.useMemo)(()=>i||r,[i,r]);return{data:d,loading:c}},ct=t.default.memo(e=>{let{t:n}=p(),i=(0,t.useRef)(null);return(0,t.useEffect)(()=>{setTimeout(()=>i.current?.focus(),200)},[]),t.default.createElement(t.default.Fragment,null,t.default.createElement(at,null,t.default.createElement(O,{ref:i,tabIndex:0,placeholder:n("assetListSearch"),maxLength:50,onChange:e.handleSearch,value:e.searchQuery,name:"Search collectibles"})),t.default.createElement(Q,null,t.default.createElement(z,null,({height:m,width:r})=>t.default.createElement(V,{style:{padding:`${st}px 0`},scrollToIndex:e.searchQuery!==e.debouncedSearchQuery?0:void 0,height:m,width:r,rowCount:e.listItems.length,rowHeight:lt,rowRenderer:a=>t.default.createElement(dt,{...a,data:e.listItems,unknownItem:n("assetListUnknownToken"),getIsHidden:e.getIsHidden,getIsSpam:e.getIsSpam,getSpamStatus:e.getSpamStatus,onToggleHidden:e.onToggleHidden})}))))}),dt=e=>{let{index:n,data:i,style:m,unknownItem:r,getIsHidden:a,getIsSpam:d,getSpamStatus:c,onToggleHidden:h}=e,l=i[n],g=a(l),f=d(l),u=c(l),C=(0,t.useCallback)(b=>h({item:l,status:b}),[h,l]);return t.default.createElement("div",{style:m},t.default.createElement(q,{collection:l,unknownItem:r,isHidden:g,isSpam:f,spamStatus:u,onToggleHidden:C}))},pt=()=>{let{data:e,loading:n}=mt(),{t:i}=p();return t.default.createElement(rt,null,n?t.default.createElement(B,null):t.default.createElement(ct,{...e}),t.default.createElement(N,null,t.default.createElement(E,{onClick:e.handleCloseModal},i("commandClose"))))},Ut=pt;export{pt as CollectiblesVisibilityPage,Ut as default};
