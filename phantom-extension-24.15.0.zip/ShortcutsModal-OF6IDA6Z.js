import{a as O,c as V}from"./chunk-UNNPDOYJ.js";import{a as G}from"./chunk-JQQUUSH2.js";import{$a as S,Xa as I,Ya as d,Za as p,_a as g,ab as f,bb as x,cb as k,db as y,eb as w,fb as L,gb as T,hb as v,ib as C,jb as P,kb as M,lb as b,mb as a,nb as D}from"./chunk-KB2UMCDM.js";import{A as W,E as F,p as o}from"./chunk-OJG7N72N.js";import{e as l}from"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-WGLF2QUC.js";import{b as u}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as h}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as m,h as i,n as c}from"./chunk-FPMOV6V2.js";i();c();var t=m(h());i();c();var A=m(h());var z={[G]:a,vote:y,"vote-2":w,stake:L,"stake-2":T,view:v,chat:C,tip:P,mint:M,"mint-2":b,"generic-link":a,"generic-add":D,discord:I,twitter:d,"twitter-2":p,x:p,instagram:g,telegram:S,leaderboard:k,gaming:f,"gaming-2":x};function B({icon:s,...n}){let r=z[s];return A.default.createElement(r,{...n})}var E=o.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-top: -16px; // compensate for generic screen margins
`,H=o.footer`
  margin-top: auto;
  flex-shrink: 0;
  min-height: 16px;
`,Y=o.div`
  overflow: scroll;
`,_=o.ul`
  flex: 1;
  max-height: 350px;
  padding-top: 16px; // compensate for the override of the generic screen margins
`,j=o.li``,q=o.div`
  display: flex;
  align-items: center;
  padding: 6px 12px;
`,N=o(F)`
  text-align: left;
`;N.defaultProps={margin:"12px 0px"};function J({shortcuts:s,...n}){let r=(0,t.useMemo)(()=>n.hostname.includes("//")?new URL(n.hostname).hostname:n.hostname,[n.hostname]);return t.default.createElement(E,null,t.default.createElement(Y,null,t.default.createElement(_,null,s.map(e=>t.default.createElement(j,{key:e.uri},t.default.createElement(W,{type:"button",onClick:()=>{l.capture("walletShortcutsLinkOpenClick",O(n,e)),self.open(e.uri)},theme:"text",paddingY:6},t.default.createElement(q,null,t.default.createElement(B,{icon:V(e.uri,e.icon)})),e.label))))),t.default.createElement(H,null,r&&t.default.createElement(N,{color:"#777777",size:14,lineHeight:17},u("shortcutsWarningDescription",{url:r}))))}var ct=J;export{J as ShortcutsModal,ct as default};
