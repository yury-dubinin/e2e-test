import{c as w}from"./chunk-VPXMNJOS.js";import{c as h,d as g,e as k}from"./chunk-2H36JXZX.js";import{b as f}from"./chunk-6TM7UJPN.js";import"./chunk-PLCKHDK3.js";import{a as x}from"./chunk-MDQQE27Q.js";import"./chunk-CZC7LOIE.js";import"./chunk-YCWBTNP5.js";import"./chunk-JQSMP2U7.js";import"./chunk-J23X3622.js";import"./chunk-Y44OMTJB.js";import{Ia as c,j as m}from"./chunk-KB2UMCDM.js";import{A as l,E as u,p as e}from"./chunk-OJG7N72N.js";import"./chunk-7FZROKRY.js";import"./chunk-RSNIE4RH.js";import{G as r}from"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import{r as d}from"./chunk-IVQ3W7KJ.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import{a as E}from"./chunk-MVAHBHCD.js";import{f as M,h as p,n as a}from"./chunk-FPMOV6V2.js";p();a();var t=M(E());var T=e.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`,A=e.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`,S=e.div`
  background: #2a2a2a;
  border-radius: 6px;
  padding: 12px 16px;
`,W=e.div`
  display: flex;
  flex-direction: row;
  color: #fff;
  cursor: pointer;
  font-size: 14px;
  width: fit-content;
  margin-bottom: 8px;

  > span {
    min-height: 14px !important;
    height: 14px !important;
    min-width: 14px !important;
    width: 14px !important;
    border-radius: 3px !important;
  }
`,I=e.div`
  display: flex;
  gap: 16px;
`,G=e.div`
  padding: 27px 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
`,b=t.default.memo(({requestId:i})=>{let{t:n}=d(),s=w(),[o,_]=(0,t.useState)(!1),y=(0,t.useCallback)(()=>{s({jsonrpc:"2.0",id:i??void 0,result:o?r.user_selectEthWallet.result.enum.ALWAYS_USE_PHANTOM:r.user_selectEthWallet.result.enum.CONTINUE_WITH_PHANTOM})},[i,s,o]),C=(0,t.useCallback)(()=>{s({jsonrpc:"2.0",id:i??void 0,result:o?r.user_selectEthWallet.result.enum.ALWAYS_USE_METAMASK:r.user_selectEthWallet.result.enum.CONTINUE_WITH_METAMASK})},[i,s,o]);return t.default.createElement(g,null,t.default.createElement(h,{style:{display:"flex",alignItems:"center"}},t.default.createElement(G,null,t.default.createElement(x,{icon:t.default.createElement(I,null,t.default.createElement(m,{width:64}),t.default.createElement(c,{width:64,height:64})),primaryText:n("whichExtensionToConnectWith"),headerStyle:"small"}))),t.default.createElement(k,{style:{padding:"0px 16px 16px"}},t.default.createElement(T,null,t.default.createElement(A,null,t.default.createElement(l,{onClick:C,"data-testid":"select_wallet--metamask"},n("useMetaMask"))),t.default.createElement(A,null,t.default.createElement(l,{theme:"primary",onClick:y,"data-testid":"select_wallet--phantom"},n("usePhantom"))),t.default.createElement(S,{"data-testid":"select_wallet--dont_ask_me_again",onClick:()=>_(!o)},t.default.createElement(W,null,t.default.createElement(f,{checked:o})," ",n("dontAskMeAgain")),t.default.createElement(u,{color:"#777777",size:13,weight:500,lineHeight:16,textAlign:"left"},n("configureInSettings"))))))}),K=b;export{b as EthSelectWallet,K as default};
