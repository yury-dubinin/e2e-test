import{a as Pj}from"./chunk-ZGSW4SDC.js";import"./chunk-D6G5BIYD.js";import{a as oj,b as qj,c as ij,d as Kj,e as fj,f as hj,g as lA,l as Sj,m as Xj,n as Rj,o as Vj,p as Jj}from"./chunk-K44DQOSB.js";import{a as Cj}from"./chunk-2H36JXZX.js";import"./chunk-VETEAMTK.js";import"./chunk-WZ7EKXIB.js";import"./chunk-4F52HJNC.js";import"./chunk-OILLFGJN.js";import"./chunk-UWQVMEE4.js";import"./chunk-UG36FTUI.js";import"./chunk-PZLCHVHJ.js";import"./chunk-NRQGEP3J.js";import"./chunk-4S56I3J4.js";import"./chunk-CYZ74O6J.js";import"./chunk-JQQUUSH2.js";import"./chunk-S366KFSE.js";import"./chunk-GTS5E7LO.js";import"./chunk-SYMRC4AP.js";import"./chunk-354SN5AZ.js";import"./chunk-UMXXII74.js";import"./chunk-IPG2S7ZF.js";import"./chunk-N5ZGUDXJ.js";import"./chunk-IE2CINMV.js";import"./chunk-O6LPORXM.js";import"./chunk-FQEO53Q7.js";import"./chunk-YML3RMB7.js";import"./chunk-C6XKDXF4.js";import"./chunk-6TM7UJPN.js";import"./chunk-TEDKHQ6I.js";import{h as FA,i as _j}from"./chunk-KLAGLWLU.js";import"./chunk-5CR56F4P.js";import"./chunk-IB7UF4X6.js";import{a as GA}from"./chunk-YO7AFFW5.js";import"./chunk-3S6ORMD7.js";import"./chunk-7HOFAWG5.js";import"./chunk-PLCKHDK3.js";import"./chunk-6LXDUOIB.js";import"./chunk-MDQQE27Q.js";import"./chunk-CZC7LOIE.js";import"./chunk-V5HJYMXJ.js";import{p as Dj,q as Tj}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import{b as bj}from"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import{b as xj,v as Hj,y as yj}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import{D as Fj}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import{a as zA}from"./chunk-JHJLW3YA.js";import"./chunk-2OUSFATI.js";import"./chunk-QSY3A4J6.js";import"./chunk-U5GOBD2Y.js";import{b as UA}from"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import{a as Nj,b as Lj,c as zj}from"./chunk-YMXCED7D.js";import{b as Uj}from"./chunk-JOOIVSPU.js";import{b as BA}from"./chunk-OMHIKLMS.js";import{e as lj,f as cj}from"./chunk-MLAFUF6V.js";import{c as ej}from"./chunk-CAX63KUB.js";import"./chunk-RZVI54SU.js";import"./chunk-BRQMZKX2.js";import"./chunk-ICR7ECHM.js";import"./chunk-SDQFBK4G.js";import"./chunk-AENF63HN.js";import"./chunk-ZJTWFWE3.js";import"./chunk-ZHACRE4R.js";import"./chunk-B3SQHPTA.js";import{b as kj}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import{Bb as Bj,ca as WA,da as QA,fa as ZA,la as Aj,ma as jj,wb as rj,yb as tj}from"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-U4OVRE4G.js";import{a as Yj}from"./chunk-QK4PPFHG.js";import{c as mj}from"./chunk-Y6EZT3LZ.js";import"./chunk-JTW2FZNL.js";import{a as wj}from"./chunk-B42X32Z2.js";import{Ea as Mj,Y as pj,ca as vj,ia as uj,ma as Oj,r as dj,u as Ij}from"./chunk-KB2UMCDM.js";import{A as gj,E as J,a as Ej,b as V,c as rA,d as $j,e as sj,f as iA,g as nj,i as aj,m as Gj,p as c,q as N,r as tA}from"./chunk-OJG7N72N.js";import{a as d6,b as YA}from"./chunk-AJXONBM4.js";import{a as I6}from"./chunk-LR3UNZEP.js";import"./chunk-ZHWDN4FA.js";import"./chunk-7FZROKRY.js";import"./chunk-B3RYBV57.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import{e as jA}from"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import{b as VA,c as JA,e as x}from"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import{f as DA}from"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Fd as SA,Gd as XA,Id as CA,Jd as RA,Oa as xA,P as gA,S as mA,md as TA,nc as wA,sc as HA,wc as yA,yd as NA,zd as LA}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{S as M}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import{b as KA}from"./chunk-WGLF2QUC.js";import{r as T}from"./chunk-IVQ3W7KJ.js";import{F as fA,L as _A,O as bA,ka as hA,ta as PA,x as AA}from"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import{g as MA}from"./chunk-RO2HUFH7.js";import{a as D}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{d as c6,f as _,h as F,n as G}from"./chunk-FPMOV6V2.js";F();G();var i=_(D()),l6=_(d6());F();G();var a=_(D());F();G();F();G();F();G();F();G();F();G();async function Wj(A){let j=await gA.api().headers({Accept:"application/json"}).get(`/solana/health/v1?locale=${A}`);if(!mA(j))throw new Error("Failed to retrieve Solana network health");return j.data}function Qj(A,j){return fA({queryKey:["solana","health",{locale:A}],refetchInterval:60*2500,enabled:j,async queryFn(){return await Wj(A)}})}function cA(A,j){let{data:r}=Qj(A,j);return j?r:void 0}var I=_(D());F();G();var w=_(D());var Zj=(0,w.createContext)(null),A6=()=>{let A=(0,w.useContext)(Zj);if(!A)throw new Error("Missing banner context. Make sure you're wrapping your component in a <BannerProvider />");return A},j6=({children:A})=>{let j=[],r=(l,d)=>{switch(d.type){case"create":return l.concat(d.payload);case"delete":return l.filter(({id:v})=>v!==d.payload.id);case"reset":return j;default:throw new Error("There was an error dispatching a banner action.")}},[t,k]=(0,w.useReducer)(r,j),$=l=>{let{type:d,variant:v,message:o,dismissable:P=!0,icon:S,autohide:H=!0,delay:C=5e3,onClick:Z}=l;(!d||!v||!o)&&console.error("You must supply a type, variant and message when creating a Banner.");let R=KA();return k({type:"create",payload:{id:R,type:d,variant:v,message:o,dismissable:P,icon:S,autohide:H,delay:C,onClick:Z}}),H&&setTimeout(()=>{s({id:R})},C),R},s=l=>k({type:"delete",payload:{id:l.id}}),n=()=>k({type:"reset"});return w.default.createElement(Zj.Provider,{value:{banners:t,createBanner:$,deleteBanner:s,resetBanners:n}},A)};var r6=c.button`
  cursor: ${A=>A.onClick?"pointer":"default"};
  display: flex;
  align-items: center;
  vertical-align: middle;
  overflow: visible;
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  border-width: 1px;
  border-style: solid;
  border-color: transparent;
  background-color: transparent;
  width: 100%;
  padding: 10px 16px;

  svg {
    fill: #fff;
    margin-right: 8px;
  }
`,p6=c(N.div)`
  position: relative;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${A=>{switch(A.variant){case"primary":return M("#AB9FF2",.7);case"success":return M("#21E56F",.7);case"warning":return M("#E5A221",.7);case"danger":return M("#EB3742",.7);default:return M("#E5A221",.7)}}};

  ${r6} {
    &:focus-visible {
      border-color: ${A=>{switch(A.variant){case"primary":return M("#AB9FF2",.7);case"success":return M("#21E56F",.7);case"warning":return M("#E5A221",.7);case"danger":return M("#EB3742",.7);default:return M("#E5A221",.7)}}};
    }
  }
`,v6=c.p`
  color: #ffffff;
  font-size: 14px;
  font-weight: 500;
  line-height: 19px;
  text-align: left;

  svg {
    margin-right: 10px;
  }
`,u6=c.button`
  cursor: pointer;
  position: absolute;
  right: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  vertical-align: middle;
  margin: 0;
  padding: 0;
  overflow: visible;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  border-width: 1px;
  border-style: solid;
  border-color: transparent;
  background-color: transparent;

  &:focus,
  &:focus-visible {
    border-color: ${M("#FFFFFF",.3)};
  }

  svg {
    fill: #ffffff;
    margin: 0;
  }
`,O6=(A,j,r)=>{let{banners:t,createBanner:k,deleteBanner:$}=A6(),s=t[t.length-1],{handleShowModalVisibility:n}=Dj(),{showSettingsMenu:l}=xj(),{t:d,i18n:v}=T(),{cluster:o}=A(),S=XA().some(K=>xA.isSolanaNetworkID(K)),H=cA(v.language,S),C=j(),Z=r();(0,I.useEffect)(()=>{let K=t.find(y=>y.type==="testnet-mode");K&&$({id:K.id}),Z?k({type:"testnet-mode",variant:"warning",message:d("featureNotSupportedOnLocalNet"),dismissable:!1,autohide:!1,onClick:()=>l(void 0,I.default.createElement(lA,null))}):C&&k({type:"testnet-mode",variant:"warning",message:d("connectionClusterTestnetMode"),dismissable:!1,autohide:!1,onClick:()=>l(void 0,I.default.createElement(lA,null))})},[Z,C,d]),(0,I.useEffect)(()=>{if(!o)return;let K=t.find(y=>y.type==="network-health");if(o==="mainnet-beta"){if(H){let{bannerVariant:y,bannerMessage:qA,notificationMessageTitle:uA,notificationMessage:OA}=H;!!y&&!!qA?qA!==K?.message&&k({type:"network-health",variant:y,message:qA,dismissable:!1,icon:I.default.createElement(Mj,{width:14,height:14,circleFill:"#FFFFFF",exclamationFill:"transparent"}),autohide:!1,onClick:OA&&uA?()=>n("networkHealth",{variant:y,title:uA,message:OA}):void 0}):K&&$({id:K.id})}}else K&&$({id:K.id})},[o,H]);let R=(0,I.useCallback)(()=>{s&&$({id:s.id})},[$,s]);return{banner:s,dismissBanner:R}},M6=I.default.memo(A=>{let{banner:j,dismissBanner:r}=A;return I.default.createElement(tA,null,j&&I.default.createElement(p6,{key:"banner",role:"banner","aria-live":j?.autohide?"assertive":"polite","aria-atomic":"true",variant:j.variant,initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},transition:{ease:"easeOut",duration:.2}},I.default.createElement(r6,{tabIndex:j.onClick?1:-1,onClick:j.onClick},j.icon,I.default.createElement(v6,null,j.message)),j.dismissable&&I.default.createElement(u6,{onClick:r},I.default.createElement(vj,{width:14,fill:"#FFFFFF"}))))}),g6=()=>{let A=O6(Bj,CA,RA);return I.default.createElement(M6,{...A})},t6=()=>I.default.createElement(g6,null);F();G();var q=_(D());F();G();var B6=_(I6()),b=_(D());var m6=c(N.div)`
  position: absolute;
  top: 0px;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #ab9ff2;
`,k6=({refs:A,activeRoute:j,onFinishedAnimating:r,isAnimating:t})=>{let[{x:k,width:$},s]=(0,b.useState)({x:0,width:0}),n=(0,b.useCallback)(()=>{A&&A[j]&&A[j].current&&s({x:A[j].current.offsetLeft,width:A[j].current.getBoundingClientRect().width})},[j,A]);return(0,b.useEffect)(()=>{n()},[j,A,n]),(0,b.useEffect)(()=>{let l=(0,B6.default)(()=>{n()},500);return self.addEventListener("resize",l),()=>{self.removeEventListener("resize",l)}}),b.default.createElement(m6,{animate:{x:k,width:$},style:{opacity:t?1:0},onAnimationComplete:r,transition:{duration:.4,type:"spring"}})};var e6=.1,E6=10,K6=60,f6=c.div`
  position: relative;
  height: ${K6}px;
  display: flex;
`,_6=c(N.div)`
  flex: 1;
  overflow-x: hidden;
  padding: ${({padding:A})=>typeof A=="number"?A:16}px;
`,b6=c(Cj)`
  flex: 1;
  display: flex;
  justify-content: space-around;
  padding: 0px 10px;
`,s6=q.default.memo(({items:A})=>{let j=V(),r=Hj(j),[t,k]=(0,q.useState)(!1),$=(0,q.useMemo)(()=>A.find(o=>Ej({path:`/${o.route}`,end:!0},j.pathname)),[A,j.pathname]),s=$&&$.route,n=(0,q.useMemo)(()=>A.reduce((o,P)=>(o[P.route]=(0,q.createRef)(),o),{}),[A]),l=j.pathname!=r?.pathname&&r?.pathname!=null,d=(0,q.useMemo)(()=>A.map(o=>{let P=q.default.memo(()=>{let S=0;return l&&(S=h6(A,j.pathname,r?.pathname??"")?E6:-E6),q.default.createElement(_6,{id:"tab-content","data-testid":`tab-content-${o.route}`,initial:{x:S,opacity:0},animate:{x:0,opacity:1},exit:{opacity:0},transition:{duration:e6},padding:o.padding},q.default.createElement(yj,{shouldResetOnAccountChange:!0},o.renderContent()))});return q.default.createElement(iA,{key:o.route,path:`/${o.route}`,element:q.default.createElement(P,null)})}),[A,j]),v=(0,q.useCallback)(o=>{k(!0),x.capture("tabPress",{data:{target:o}}),bA.addBreadcrumb("generic",`Tab changed to ${o}`,"info")},[]);return q.default.createElement(q.default.Fragment,null,q.default.createElement(tA,{mode:"wait",initial:!1},q.default.createElement(nj,{location:j,key:j.pathname},d,q.default.createElement(iA,{key:"redirection",element:q.default.createElement(N.div,{exit:{opacity:0},transition:{duration:e6}},q.default.createElement(sj,{to:A[0]?A[0].route:"/"}))}))),q.default.createElement(f6,null,q.default.createElement(k6,{refs:n,activeRoute:s,onFinishedAnimating:()=>k(!1),isAnimating:t}),q.default.createElement(b6,{role:"tablist","aria-orientation":"horizontal"},A.map(o=>q.default.createElement(x6,{isActive:s===o.route,key:o.route,item:o,ref:n[o.route],isAnimating:t,onClick:()=>v(o.route)})))),q.default.createElement("div",{"aria-hidden":!0,"data-testid":"current-route","data-location":j.pathname}))},(A,j)=>tj(A.items.map(r=>r.route),j.items.map(r=>r.route))),h6=(A,j,r)=>{let t=A.findIndex($=>$.route===$6(j)),k=A.findIndex($=>$.route===$6(r));return t>k},$6=A=>A==="/"?A:A.replace(/^\/+/g,""),P6=c(aj)`
  display: block;
  padding: 15px 0px;
  margin: 0px 12px;
  position: relative;
  width: 100%;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  :hover {
    color: white;
    svg {
      fill: white;

      path {
        fill: white;
      }
    }
  }
  :after {
    content: "";
    position: absolute;
    top: -1px;
    left: 0;
    height: 2px;
    width: 100%;
    border-radius: 2px;
    ${A=>A.$isActive&&!A.$isAnimating&&"background-color: #AB9FF2;"}
    ${A=>A.$isAnimating&&"background-color: transparent;"}
  }
  svg {
    fill: #666;
    transition: fill 200ms ease;
    ${A=>A.$isActive&&"fill: white;"}

    path {
      ${A=>A.$isActive?"fill: white;":"fill: #666;"}
    }
  }
`,x6=(0,q.forwardRef)(({isActive:A,item:j,isAnimating:r,onClick:t},k)=>q.default.createElement(P6,{"aria-label":j.label,"data-testid":`bottom-tab-nav-button-${j.route}`,$isActive:A,$isAnimating:r,to:j.route,ref:k,onClick:t},j.renderButton()));F();G();var g=_(D());var n6=({onClose:A})=>{let{t:j}=T(),r=rA();return g.default.createElement(H6,null,g.default.createElement(D6,null,g.default.createElement(J,{color:"#e2dffe",size:16,weight:600},j("whatsNewOverlayNew"))),g.default.createElement(T6,null,j("whatsNewOverlayv3ActionBurnSpam")),g.default.createElement(N6,null,j("whatsNewOverlayv3SecondaryText")),g.default.createElement(L6,{color:"#e2dffe",size:16,weight:500,onClick:async()=>{A(),r("/collectibles")}},j("whatsNewOverlayv2ActionTryItNow")),g.default.createElement(y6,null),g.default.createElement(S6,null,g.default.createElement(X6,{onClick:A})))},H6=c.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  height: 100%;
  width: 100%;
  padding: 20px;
`,y6=c.div`
  flex: 1;
`,D6=c.div`
  margin-top: 40px;
  align-self: center;
  width: 76px;
  height: 35px;
  background-color: rgba(138, 129, 248, 0.1);
  border-radius: 100px;
  display: flex;
  justify-content: center;
  align-items: center;
`,T6=c(J).attrs({size:28,weight:500})`
  align-self: center;
  margin-top: 22px;
  line-height: 34px;
  max-width: 275px;
  text-align: center;
`,N6=c(J).attrs({size:16,color:"#777"})`
  align-self: center;
  margin-top: 22px;
  max-width: 275px;
  text-align: center;
  span {
    color: white;
  }
`,L6=c(J).attrs({color:"#e2dffe",size:16,weight:500})`
  cursor: pointer;
  margin-top: 22px;
`,S6=c.div``,X6=A=>{let{t:j}=T();return g.default.createElement(gj,{type:"button",theme:"default",...A},j("commandClose"))};var C6=a.default.lazy(()=>import("./HomeTabPage-3ABWYAAU.js")),R6=a.default.lazy(()=>import("./CollectionsPage-XW5PWZ2H.js")),V6=a.default.lazy(()=>import("./SwapTabPage-BTND4RHE.js")),J6=a.default.lazy(()=>import("./RecentActivity-PGSTZ4MD.js")),U6=a.default.lazy(()=>import("./ExplorePage-7TZVCGJN.js")),Y6=a.default.lazy(()=>import("./HomeHeaderRightButtons-KUMNMGYO.js")),z6=a.default.lazy(()=>import("./SwapSettingsButton-AZ7L3SCY.js")),o6=()=>{let{data:A}=FA(),{mutateAsync:j}=_j(),{data:r=[]}=TA();SA();let{data:[t]}=PA(["frontend-enable-session-start"]),{mutateAsync:k}=DA();return GA(()=>{hj.onAppSessionStart(r)},r.length>0&&t),GA(()=>{k()},MA),(0,a.useEffect)(()=>{x.captureOptOutStatus()},[]),!Pj()&&A?a.default.createElement(a.default.Fragment,null,a.default.createElement(a6,null),a.default.createElement(n6,{onClose:()=>{j()}})):a.default.createElement(a.default.Fragment,null,a.default.createElement(a6,null),a.default.createElement(t6,null),a.default.createElement(W6,null),a.default.createElement("div",{id:jA}))},a6=()=>{let{pathname:A}=V(),j=(0,a.useMemo)(()=>A==="/swap"?a.default.createElement(z6,null):A==="/"?a.default.createElement(Y6,null):null,[A]);return a.default.createElement(Xj,{rightMenuButton:j,"data-testid":"multichain-account-header"})},W6=()=>{let{data:A}=FA(),{data:j}=LA(),{data:r}=NA(),t=r?.isReadOnly,k=AA.isFeatureEnabled("kill-swapper")||t,$=AA.isFeatureEnabled("kill-explore"),s=AA.isFeatureEnabled("kill-collectibles"),{t:n}=T(),{pathname:l}=V(),d=rA(),{closeAllModals:v}=bj();rj(),(0,a.useEffect)(()=>{A||(v(),l!=="/"&&d("/"))},[j,A]);let o=(0,a.useMemo)(()=>[{label:n("homeTab"),route:"/",renderButton:()=>a.default.createElement(dj,null),renderContent:()=>a.default.createElement(C6,null),padding:0},s?null:{label:n("collectiblesTab"),route:"/collectibles",renderButton:()=>a.default.createElement(Oj,{width:22}),renderContent:()=>a.default.createElement(R6,null)},k?null:{label:n("swapTab"),route:"/swap",renderButton:()=>a.default.createElement(pj,{width:24,height:24}),renderContent:()=>a.default.createElement(V6,null)},{label:n("activityTab"),route:"/notifications",renderButton:()=>a.default.createElement(Ij,null),renderContent:()=>a.default.createElement(J6,null)},$?null:{label:n("exploreTab"),route:"/explore",renderButton:()=>a.default.createElement(uj,{width:34}),renderContent:()=>a.default.createElement(U6,null),padding:0}].filter(P=>P!==null),[s,$,k,n]);return a.default.createElement(a.Suspense,null,a.default.createElement(s6,{items:o}))};F();G();F();G();F();G();var vA={};c6(vA,{AuthTokenGenerator:()=>IA,Client:()=>Q,Configuration:()=>X,DeleteError:()=>E7,RecoverError:()=>nA,RecoverErrorReason:()=>s7,RegisterError:()=>$7,__wbg_JuiceboxGetAuthToken_06fb1d3c42d3a182:()=>G7,__wbg_arrayBuffer_a9d862b05aaee2f9:()=>L7,__wbg_blob_c6537f3e31e66dad:()=>R7,__wbg_buffer_a448f833075b71ba:()=>Mr,__wbg_call_5da1969d7cd31ccd:()=>cr,__wbg_call_90c26b09837aba1c:()=>sr,__wbg_crypto_58f13aa23ffcb166:()=>V7,__wbg_done_5fe336b092d60cf2:()=>kr,__wbg_entries_9e2e2aa45aa5094a:()=>Ir,__wbg_error_f851667af71bcfc6:()=>O7,__wbg_fetch_0c82eef617317d0a:()=>i7,__wbg_from_71add2e723d1f1b2:()=>Fr,__wbg_getRandomValues_504510b5564925af:()=>Z7,__wbg_get_7b48513de5dc5ea4:()=>$r,__wbg_get_f01601b5a68d10e3:()=>Ar,__wbg_getwithrefkey_4a92a5eca60879b9:()=>w7,__wbg_globalThis_9caa27ff917c6860:()=>qr,__wbg_global_35dfdd59a4da3e74:()=>ir,__wbg_headers_24def508a7518df9:()=>C7,__wbg_headers_d135d2bb8cc60413:()=>D7,__wbg_instanceof_ArrayBuffer_e7d53d51371448e2:()=>lr,__wbg_instanceof_Response_4c3b1446206114d1:()=>S7,__wbg_instanceof_Uint8Array_bced6f43aed8c1aa:()=>_r,__wbg_isArray_74fb723e24f76012:()=>Gr,__wbg_isSafeInteger_f93fde0dca9820f8:()=>dr,__wbg_iterator_db7ca081358d4fb2:()=>Er,__wbg_length_1009b1af0c481d7b:()=>jr,__wbg_length_1d25fa9e4ac21ce7:()=>fr,__wbg_msCrypto_abcb1295e768d1f2:()=>z7,__wbg_new_60f57089c7563e81:()=>pr,__wbg_new_8f67e318f15d7254:()=>mr,__wbg_new_9fb8d994e1c0aaac:()=>nr,__wbg_new_abda76e883ba8a5f:()=>v7,__wbg_newnoargs_c62ea9419c21fbac:()=>rr,__wbg_newwithbyteoffsetandlength_d0482f893617af71:()=>gr,__wbg_newwithlength_6c2df9e2f3028c43:()=>br,__wbg_newwithstrandinit_f581dff0d19a8b03:()=>T7,__wbg_next_6529ee0cca8d57ed:()=>Br,__wbg_next_9b877f231f476d01:()=>tr,__wbg_node_523d7bd03ef69fba:()=>Y7,__wbg_now_0343d9c3e0e8eedc:()=>H7,__wbg_now_b724952e890dc703:()=>y7,__wbg_process_5b786e71d465a513:()=>J7,__wbg_queueMicrotask_4d890031a6a5a50c:()=>M7,__wbg_queueMicrotask_adae4bc085237231:()=>g7,__wbg_randomFillSync_a0d98aa11c81fe89:()=>Q7,__wbg_recovererror_new:()=>a7,__wbg_require_2784e593a4674877:()=>W7,__wbg_resolve_6e1c6553a82f85b7:()=>vr,__wbg_self_f0e34d89f33b99fd:()=>ar,__wbg_setTimeout_7864ca813139bafe:()=>F7,__wbg_set_2357bf09366ee480:()=>Kr,__wbg_set_27f236f6d7a28c29:()=>N7,__wbg_set_759f75cd92b612d2:()=>xr,__wbg_set_wasm:()=>pA,__wbg_stack_658279fe44541cf6:()=>u7,__wbg_status_d6d47ad2837621eb:()=>X7,__wbg_stringify_e1b19966d964d242:()=>Pr,__wbg_subarray_2e940e41c0f5a1d9:()=>hr,__wbg_then_3ab08cd4fbb91ae9:()=>ur,__wbg_then_8371cc12cfedc5a2:()=>Or,__wbg_value_0c248a78fdc8e19f:()=>er,__wbg_versions_c2ab80650590b6a2:()=>U7,__wbg_window_d3b084224f4774d7:()=>or,__wbindgen_as_number:()=>h7,__wbindgen_boolean_get:()=>_7,__wbindgen_cb_drop:()=>o7,__wbindgen_closure_wrapper853:()=>Dr,__wbindgen_closure_wrapper903:()=>Tr,__wbindgen_debug_string:()=>wr,__wbindgen_error_new:()=>p7,__wbindgen_in:()=>I7,__wbindgen_is_function:()=>m7,__wbindgen_is_object:()=>c7,__wbindgen_is_string:()=>l7,__wbindgen_is_undefined:()=>d7,__wbindgen_jsval_loose_eq:()=>f7,__wbindgen_memory:()=>yr,__wbindgen_number_get:()=>b7,__wbindgen_number_new:()=>P7,__wbindgen_object_clone_ref:()=>K7,__wbindgen_object_drop_ref:()=>n7,__wbindgen_string_get:()=>q7,__wbindgen_string_new:()=>x7,__wbindgen_throw:()=>Hr});F();G();var E;function pA(A){E=A}var h=new Array(128).fill(void 0);h.push(void 0,null,!0,!1);function B(A){return h[A]}var Y=h.length;function Q6(A){A<132||(h[A]=Y,Y=A)}function L(A){let j=B(A);return Q6(A),j}var O=0,kA=null;function z(){return(kA===null||kA.byteLength===0)&&(kA=new Uint8Array(E.memory.buffer)),kA}var Z6=typeof TextEncoder>"u"?(0,module.require)("util").TextEncoder:TextEncoder,$A=new Z6("utf-8"),A7=typeof $A.encodeInto=="function"?function(A,j){return $A.encodeInto(A,j)}:function(A,j){let r=$A.encode(A);return j.set(r),{read:A.length,written:r.length}};function W(A,j,r){if(r===void 0){let n=$A.encode(A),l=j(n.length,1)>>>0;return z().subarray(l,l+n.length).set(n),O=n.length,l}let t=A.length,k=j(t,1)>>>0,$=z(),s=0;for(;s<t;s++){let n=A.charCodeAt(s);if(n>127)break;$[k+s]=n}if(s!==t){s!==0&&(A=A.slice(s)),k=r(k,t,t=s+A.length*3,1)>>>0;let n=z().subarray(k+s,k+t),l=A7(A,n);s+=l.written}return O=s,k}function sA(A){return A==null}var eA=null;function m(){return(eA===null||eA.byteLength===0)&&(eA=new Int32Array(E.memory.buffer)),eA}var j7=typeof TextDecoder>"u"?(0,module.require)("util").TextDecoder:TextDecoder,q6=new j7("utf-8",{ignoreBOM:!0,fatal:!0});q6.decode();function f(A,j){return A=A>>>0,q6.decode(z().subarray(A,A+j))}function e(A){Y===h.length&&h.push(h.length+1);let j=Y;return Y=h[j],h[j]=A,j}var EA=null;function r7(){return(EA===null||EA.byteLength===0)&&(EA=new Float64Array(E.memory.buffer)),EA}function dA(A){let j=typeof A;if(j=="number"||j=="boolean"||A==null)return`${A}`;if(j=="string")return`"${A}"`;if(j=="symbol"){let k=A.description;return k==null?"Symbol":`Symbol(${k})`}if(j=="function"){let k=A.name;return typeof k=="string"&&k.length>0?`Function(${k})`:"Function"}if(Array.isArray(A)){let k=A.length,$="[";k>0&&($+=dA(A[0]));for(let s=1;s<k;s++)$+=", "+dA(A[s]);return $+="]",$}let r=/\[object ([^\]]+)\]/.exec(toString.call(A)),t;if(r.length>1)t=r[1];else return toString.call(A);if(t=="Object")try{return"Object("+JSON.stringify(A)+")"}catch{return"Object"}return A instanceof Error?`${A.name}: ${A.message}
${A.stack}`:t}function i6(A,j,r,t){let k={a:A,b:j,cnt:1,dtor:r},$=(...s)=>{k.cnt++;let n=k.a;k.a=0;try{return t(n,k.b,...s)}finally{--k.cnt===0?E.__wbindgen_export_2.get(k.dtor)(n,k.b):k.a=n}};return $.original=k,$}function t7(A,j){E.wasm_bindgen__convert__closures__invoke0_mut__haa5973ef449a5fac(A,j)}function B7(A,j,r){E._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h664375554e075ae3(A,j,e(r))}function k7(A,j){if(!(A instanceof j))throw new Error(`expected instance of ${j.name}`);return A.ptr}function U(A,j){let r=j(A.length*1,1)>>>0;return z().set(A,r/1),O=A.length,r}function p(A,j){try{return A.apply(this,j)}catch(r){E.__wbindgen_exn_store(e(r))}}function e7(A,j,r,t){E.wasm_bindgen__convert__closures__invoke2_mut__h35a3737c9c8313d7(A,j,e(r),e(t))}var E7=Object.freeze({InvalidAuth:0,0:"InvalidAuth",UpgradeRequired:1,1:"UpgradeRequired",Assertion:2,2:"Assertion",Transient:3,3:"Transient"}),$7=Object.freeze({InvalidAuth:0,0:"InvalidAuth",UpgradeRequired:1,1:"UpgradeRequired",Assertion:2,2:"Assertion",Transient:3,3:"Transient"}),s7=Object.freeze({InvalidPin:0,0:"InvalidPin",NotRegistered:1,1:"NotRegistered",InvalidAuth:2,2:"InvalidAuth",UpgradeRequired:3,3:"UpgradeRequired",Assertion:4,4:"Assertion",Transient:5,5:"Transient"}),IA=class{__destroy_into_raw(){let j=this.__wbg_ptr;return this.__wbg_ptr=0,j}free(){let j=this.__destroy_into_raw();E.__wbg_authtokengenerator_free(j)}constructor(j){let r=E.authtokengenerator_new(e(j));return this.__wbg_ptr=r>>>0,this}vend(j,r){let t,k;try{let n=E.__wbindgen_add_to_stack_pointer(-16),l=W(j,E.__wbindgen_malloc,E.__wbindgen_realloc),d=O,v=W(r,E.__wbindgen_malloc,E.__wbindgen_realloc),o=O;E.authtokengenerator_vend(n,this.__wbg_ptr,l,d,v,o);var $=m()[n/4+0],s=m()[n/4+1];return t=$,k=s,f($,s)}finally{E.__wbindgen_add_to_stack_pointer(16),E.__wbindgen_free(t,k,1)}}static random_secret_id(){let j,r;try{let $=E.__wbindgen_add_to_stack_pointer(-16);E.authtokengenerator_random_secret_id($);var t=m()[$/4+0],k=m()[$/4+1];return j=t,r=k,f(t,k)}finally{E.__wbindgen_add_to_stack_pointer(16),E.__wbindgen_free(j,r,1)}}},Q=class{__destroy_into_raw(){let j=this.__wbg_ptr;return this.__wbg_ptr=0,j}free(){let j=this.__destroy_into_raw();E.__wbg_client_free(j)}constructor(j,r){k7(j,X);var t=j.__destroy_into_raw();let k=E.client_new(t,e(r));return this.__wbg_ptr=k>>>0,this}register(j,r,t,k){let $=U(j,E.__wbindgen_malloc),s=O,n=U(r,E.__wbindgen_malloc),l=O,d=U(t,E.__wbindgen_malloc),v=O,o=E.client_register(this.__wbg_ptr,$,s,n,l,d,v,k);return L(o)}recover(j,r){let t=U(j,E.__wbindgen_malloc),k=O,$=U(r,E.__wbindgen_malloc),s=O,n=E.client_recover(this.__wbg_ptr,t,k,$,s);return L(n)}delete(){let j=E.client_delete(this.__wbg_ptr);return L(j)}},X=class{__destroy_into_raw(){let j=this.__wbg_ptr;return this.__wbg_ptr=0,j}free(){let j=this.__destroy_into_raw();E.__wbg_configuration_free(j)}constructor(j){let r=E.configuration_new(e(j));return this.__wbg_ptr=r>>>0,this}},nA=class A{static __wrap(j){j=j>>>0;let r=Object.create(A.prototype);return r.__wbg_ptr=j,r}__destroy_into_raw(){let j=this.__wbg_ptr;return this.__wbg_ptr=0,j}free(){let j=this.__destroy_into_raw();E.__wbg_recovererror_free(j)}get reason(){return E.__wbg_get_recovererror_reason(this.__wbg_ptr)}set reason(j){E.__wbg_set_recovererror_reason(this.__wbg_ptr,j)}get guesses_remaining(){let j=E.__wbg_get_recovererror_guesses_remaining(this.__wbg_ptr);return j===16777215?void 0:j}set guesses_remaining(j){E.__wbg_set_recovererror_guesses_remaining(this.__wbg_ptr,sA(j)?16777215:j)}};function n7(A){L(A)}function a7(A){let j=nA.__wrap(A);return e(j)}function o7(A){let j=L(A).original;return j.cnt--==1?(j.a=0,!0):!1}function q7(A,j){let r=B(j),t=typeof r=="string"?r:void 0;var k=sA(t)?0:W(t,E.__wbindgen_malloc,E.__wbindgen_realloc),$=O;m()[A/4+1]=$,m()[A/4+0]=k}function i7(A){let j=fetch(B(A));return e(j)}function F7(){return p(function(A,j){let r=setTimeout(B(A),j);return e(r)},arguments)}function G7(){return p(function(A){let j=JuiceboxGetAuthToken(L(A));return e(j)},arguments)}function l7(A){return typeof B(A)=="string"}function c7(A){let j=B(A);return typeof j=="object"&&j!==null}function d7(A){return B(A)===void 0}function I7(A,j){return B(A)in B(j)}function p7(A,j){let r=new Error(f(A,j));return e(r)}function v7(){let A=new Error;return e(A)}function u7(A,j){let r=B(j).stack,t=W(r,E.__wbindgen_malloc,E.__wbindgen_realloc),k=O;m()[A/4+1]=k,m()[A/4+0]=t}function O7(A,j){let r,t;try{r=A,t=j,console.error(f(A,j))}finally{E.__wbindgen_free(r,t,1)}}function M7(A){queueMicrotask(B(A))}function g7(A){let j=B(A).queueMicrotask;return e(j)}function m7(A){return typeof B(A)=="function"}function K7(A){let j=B(A);return e(j)}function f7(A,j){return B(A)==B(j)}function _7(A){let j=B(A);return typeof j=="boolean"?j?1:0:2}function b7(A,j){let r=B(j),t=typeof r=="number"?r:void 0;r7()[A/8+1]=sA(t)?0:t,m()[A/4+0]=!sA(t)}function h7(A){return+B(A)}function P7(A){return e(A)}function x7(A,j){let r=f(A,j);return e(r)}function w7(A,j){let r=B(A)[B(j)];return e(r)}function H7(){return Date.now()}function y7(A){return B(A).now()}function D7(A){let j=B(A).headers;return e(j)}function T7(){return p(function(A,j,r){let t=new Request(f(A,j),B(r));return e(t)},arguments)}function N7(){return p(function(A,j,r,t,k){B(A).set(f(j,r),f(t,k))},arguments)}function L7(A){let j=B(A).arrayBuffer();return e(j)}function S7(A){let j;try{j=B(A)instanceof Response}catch{j=!1}return j}function X7(A){return B(A).status}function C7(A){let j=B(A).headers;return e(j)}function R7(){return p(function(A){let j=B(A).blob();return e(j)},arguments)}function V7(A){let j=B(A).crypto;return e(j)}function J7(A){let j=B(A).process;return e(j)}function U7(A){let j=B(A).versions;return e(j)}function Y7(A){let j=B(A).node;return e(j)}function z7(A){let j=B(A).msCrypto;return e(j)}function W7(){return p(function(){let A=module.require;return e(A)},arguments)}function Q7(){return p(function(A,j){B(A).randomFillSync(L(j))},arguments)}function Z7(){return p(function(A,j){B(A).getRandomValues(B(j))},arguments)}function Ar(A,j){let r=B(A)[j>>>0];return e(r)}function jr(A){return B(A).length}function rr(A,j){let r=new Function(f(A,j));return e(r)}function tr(A){let j=B(A).next;return e(j)}function Br(){return p(function(A){let j=B(A).next();return e(j)},arguments)}function kr(A){return B(A).done}function er(A){let j=B(A).value;return e(j)}function Er(){return e(Symbol.iterator)}function $r(){return p(function(A,j){let r=Reflect.get(B(A),B(j));return e(r)},arguments)}function sr(){return p(function(A,j){let r=B(A).call(B(j));return e(r)},arguments)}function nr(){let A=new Object;return e(A)}function ar(){return p(function(){let A=self.self;return e(A)},arguments)}function or(){return p(function(){let A=self.window;return e(A)},arguments)}function qr(){return p(function(){let A=globalThis.globalThis;return e(A)},arguments)}function ir(){return p(function(){let A=self.global;return e(A)},arguments)}function Fr(A){let j=Array.from(B(A));return e(j)}function Gr(A){return Array.isArray(B(A))}function lr(A){let j;try{j=B(A)instanceof ArrayBuffer}catch{j=!1}return j}function cr(){return p(function(A,j,r){let t=B(A).call(B(j),B(r));return e(t)},arguments)}function dr(A){return Number.isSafeInteger(B(A))}function Ir(A){let j=Object.entries(B(A));return e(j)}function pr(A,j){try{var r={a:A,b:j},t=($,s)=>{let n=r.a;r.a=0;try{return e7(n,r.b,$,s)}finally{r.a=n}};let k=new Promise(t);return e(k)}finally{r.a=r.b=0}}function vr(A){let j=Promise.resolve(B(A));return e(j)}function ur(A,j){let r=B(A).then(B(j));return e(r)}function Or(A,j,r){let t=B(A).then(B(j),B(r));return e(t)}function Mr(A){let j=B(A).buffer;return e(j)}function gr(A,j,r){let t=new Uint8Array(B(A),j>>>0,r>>>0);return e(t)}function mr(A){let j=new Uint8Array(B(A));return e(j)}function Kr(A,j,r){B(A).set(B(j),r>>>0)}function fr(A){return B(A).length}function _r(A){let j;try{j=B(A)instanceof Uint8Array}catch{j=!1}return j}function br(A){let j=new Uint8Array(A>>>0);return e(j)}function hr(A,j,r){let t=B(A).subarray(j>>>0,r>>>0);return e(t)}function Pr(){return p(function(A){let j=JSON.stringify(B(A));return e(j)},arguments)}function xr(){return p(function(A,j,r){return Reflect.set(B(A),B(j),B(r))},arguments)}function wr(A,j){let r=dA(B(j)),t=W(r,E.__wbindgen_malloc,E.__wbindgen_realloc),k=O;m()[A/4+1]=k,m()[A/4+0]=t}function Hr(A,j){throw new Error(f(A,j))}function yr(){let A=E.memory;return e(A)}function Dr(A,j,r){let t=i6(A,j,196,t7);return e(t)}function Tr(A,j,r){let t=i6(A,j,219,B7);return e(t)}var F6="./juicebox-sdk_bg-LUYFYBUJ.wasm";var Lr=async()=>{let A=await WebAssembly.instantiateStreaming(fetch(F6),{"./juicebox-sdk_bg.js":vA});pA(A.instance.exports)};Lr();globalThis.JuiceboxTokens={};var aA=class{constructor(){this.client=Sr()}async setJuiceboxTokens(j){globalThis.JuiceboxTokens=j}async backupShare(j,r,t,k){await this.client.register(r,j,t,k)}async recoverShare(j,r){return await this.client.recover(j,r)}},Sr=()=>new Q(new X({realms:[{id:"497efc0c17f850465b9387a549affb2b",address:"https://development-juicebox.phantom.dev/"},{id:"7dd7ac88b0584725a2db014818631f8c",address:"https://juicebox.rpcpool.com"}],register_threshold:2,recover_threshold:2,pin_hashing_mode:"Standard2019"}),[]);var oA,Xr=async()=>oA||(oA=new oj(new aA),oA),Cr={authRepository:BA,vault:lj(),juiceboxClient:Xr,mnemonicProvider:async()=>hA.from((await zA()).fromSentenceLength(12).getEntropy())},G6=ij(Cr);JA();_A.init({provider:Yj});YA();ZA(new VA);WA((A,j)=>Aj(A,j,x));QA(jj);var Rr=()=>{(0,i.useEffect)(()=>{x.capture("popupOpen")},[]);let A=(0,i.useCallback)(()=>{UA({url:"onboarding.html"}),self.close()},[]);return i.default.createElement(i.default.Fragment,null,i.default.createElement($j,{future:{v7_startTransition:!0}},i.default.createElement(Gj,{theme:wj},i.default.createElement(Fj,null,i.default.createElement(zj,{backgroundColor:"#222222"}),i.default.createElement(mj,null,i.default.createElement(Kj,{withBorder:!0},i.default.createElement(Uj,null,i.default.createElement(cj,null,i.default.createElement(wA,{analytics:x},i.default.createElement(j6,null,i.default.createElement(ej,null,i.default.createElement(HA,{authRepository:BA},i.default.createElement(yA,{userRepository:Lj,claimUsernameSigner:Nj},i.default.createElement(qj,{seedlessRepository:G6},i.default.createElement(Jj,{openOnboarding:A},i.default.createElement(Rj,null,i.default.createElement(Tj,null,i.default.createElement(Vj,null,i.default.createElement(Sj,null,i.default.createElement(kj,null,i.default.createElement(o6,null)))))))))))),i.default.createElement("div",{id:jA}),i.default.createElement(fj,null))))))))))},Vr=document.getElementById("root"),Jr=(0,l6.createRoot)(Vr);Jr.render(i.default.createElement(Rr,null));
