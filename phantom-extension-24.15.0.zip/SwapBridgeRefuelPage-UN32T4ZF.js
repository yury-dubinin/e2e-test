import{a as h,b as s,c as f,d as R}from"./chunk-A65D3ZQB.js";import"./chunk-PK6WRZ47.js";import{b as w,p as P}from"./chunk-Y3KNGKBS.js";import"./chunk-QVVAGMA5.js";import"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import"./chunk-W5GLT6IB.js";import"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import"./chunk-JQSMP2U7.js";import"./chunk-7ZDPJAUC.js";import"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-VHWNQPFU.js";import{E as x}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import"./chunk-B42X32Z2.js";import{Ja as C}from"./chunk-KB2UMCDM.js";import{A as a,E as u,p as r}from"./chunk-OJG7N72N.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as c}from"./chunk-IVQ3W7KJ.js";import"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as I}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as v,h as b,n as B}from"./chunk-FPMOV6V2.js";b();B();var e=v(I());var V=r.div`
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 10px;
`,H=r.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 16px;
`,T=r(u).attrs({size:28,lineHeight:32,weight:600,color:"#fff"})`
  margin: 12px 0 4px;
`,k=r(u).attrs({size:16,lineHeight:18,weight:400,color:"#999"})`
  padding: 0 20px;
`,L=r.div`
  margin-bottom: 10px;
`,D=()=>{let{handleHideModalVisibility:i}=P(),{setRefuelEnabled:d,...n}=x(),t=(0,e.useCallback)(()=>{i("bridgeRefuel")},[i]),p=(0,e.useCallback)(l=>{d(l),t()},[t,d]);return{...n,enableRefuel:p,hideBridgeRefuel:t}},E=e.default.memo(({symbol:i,balance:d,refuelAmount:n,uiRefuelAmount:t,estimatedCost:p,refuelEnabled:l,enableRefuel:m,hideBridgeRefuel:y,isFetchingQuote:g})=>{let{t:o}=c();return e.default.createElement(V,null,e.default.createElement(L,null,e.default.createElement(H,null,e.default.createElement(w,{leftButton:{type:"close",onClick:y}},o("bridgeRefuelTitle")),e.default.createElement(C,null),e.default.createElement(T,null,o("bridgeRefuelEnable")),e.default.createElement(k,null,o("bridgeRefuelDescription"))),e.default.createElement(h,{roundedTop:!0,roundedBottom:!0},e.default.createElement(s,{label:o("bridgeRefuelLabelBalance",{symbol:i})},e.default.createElement(f,{color:"#EB3742"},d)),e.default.createElement(s,{label:o("bridgeRefuelLabelReceive"),isLoading:g},e.default.createElement(f,{color:l&&n?"#21E56F":void 0},l&&n?t:"-")),e.default.createElement(s,{label:o("bridgeRefuelLabelFee"),isLoading:g},e.default.createElement(f,null,l&&n?p:"")))),e.default.createElement("div",null,e.default.createElement(a,{theme:"default",onClick:()=>m(!1)},o("bridgeRefuelDismiss")),e.default.createElement(R,{gap:10}),e.default.createElement(a,{theme:"primary",onClick:()=>m(!0)},o("bridgeRefuelEnable"))))}),S=()=>{let i=D();return e.default.createElement(E,{...i})},U=S;export{S as SwapBridgeRefuelPage,U as default};
