import{a as p}from"./chunk-V5HJYMXJ.js";import{a}from"./chunk-DDQ3VOL7.js";import{a as i}from"./chunk-B42X32Z2.js";import{Ea as m}from"./chunk-KB2UMCDM.js";import{A as c,D as e,p as o}from"./chunk-OJG7N72N.js";import{S as l}from"./chunk-PAHUG44L.js";import"./chunk-B4J5FBN2.js";import{a as h}from"./chunk-MVAHBHCD.js";import{f as x,h as r,n}from"./chunk-FPMOV6V2.js";r();n();var t=x(h());var y=o.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100vh;
`,C=o.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex-grow: 1;
`,u=o(e).attrs({size:22,color:i.white,weight:"bold"})`
  margin-top: 16px;
  margin-left: 16px;
  margin-right: 16px;
`,v=o(e).attrs({size:16,color:i.grayLight})`
  margin-top: 8px;
  margin-left: 16px;
  margin-right: 16px;
`,w=({title:s,description:f,buttonText:g,onButtonClick:d})=>t.createElement(y,null,t.createElement(C,null,t.createElement(p,{color:l(i.warning,.1),diameter:94},t.createElement(m,{width:54,height:54,circleFill:i.warning})),t.createElement(u,null,s),t.createElement(v,null,f)),t.createElement(a,{removeFooterExpansion:!0},t.createElement(c,{theme:"primary",onClick:d},g))),E=w;export{w as WarningInfoModal,E as default};
