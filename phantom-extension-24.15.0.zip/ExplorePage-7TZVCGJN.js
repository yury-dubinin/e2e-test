import{a as k,b as Co}from"./chunk-SSGQZUJT.js";import{a as xt}from"./chunk-ESF6SLUG.js";import{a as ut,f as ft}from"./chunk-C3LFITEI.js";import"./chunk-HUNESHQZ.js";import"./chunk-DNB2Z6FU.js";import"./chunk-EIS4BUJH.js";import"./chunk-COXGWD2J.js";import"./chunk-DPCFVZS3.js";import"./chunk-5XCUMEAE.js";import{a as z}from"./chunk-4FHVYNCP.js";import"./chunk-PLKS6FEO.js";import"./chunk-YQDICQQM.js";import"./chunk-4FJRVTBJ.js";import"./chunk-EPFWUK4P.js";import"./chunk-246MQMRD.js";import"./chunk-D6G5BIYD.js";import"./chunk-PK6WRZ47.js";import"./chunk-4F52HJNC.js";import"./chunk-OILLFGJN.js";import"./chunk-UWQVMEE4.js";import"./chunk-PZLCHVHJ.js";import"./chunk-JQQUUSH2.js";import"./chunk-S366KFSE.js";import"./chunk-GTS5E7LO.js";import"./chunk-354SN5AZ.js";import"./chunk-UMXXII74.js";import"./chunk-IPG2S7ZF.js";import"./chunk-N5ZGUDXJ.js";import"./chunk-O6LPORXM.js";import"./chunk-TEDKHQ6I.js";import"./chunk-KLAGLWLU.js";import{a as ho}from"./chunk-5CR56F4P.js";import"./chunk-IB7UF4X6.js";import"./chunk-7HOFAWG5.js";import"./chunk-PLCKHDK3.js";import"./chunk-CZC7LOIE.js";import{a as go}from"./chunk-V5HJYMXJ.js";import{l as xo,p as yo}from"./chunk-Y3KNGKBS.js";import{b as uo}from"./chunk-QVVAGMA5.js";import{a as g}from"./chunk-OIUFF6CQ.js";import"./chunk-WK2JI25E.js";import"./chunk-BFWITKCK.js";import"./chunk-JBRGGPW2.js";import"./chunk-P3IBEZ5F.js";import{g as fo}from"./chunk-W5GLT6IB.js";import{r as At,v as co,z as mt}from"./chunk-FGDP4DIS.js";import"./chunk-YCWBTNP5.js";import"./chunk-CGUJJQD6.js";import{a as ct}from"./chunk-JQSMP2U7.js";import{a as Le}from"./chunk-7ZDPJAUC.js";import{a as to,t as oo}from"./chunk-XBQBBV2G.js";import"./chunk-FWOM453C.js";import"./chunk-J23X3622.js";import"./chunk-DDQ3VOL7.js";import"./chunk-2OUSFATI.js";import"./chunk-QSY3A4J6.js";import"./chunk-U5GOBD2Y.js";import"./chunk-Y44OMTJB.js";import"./chunk-VHWNQPFU.js";import"./chunk-OMHIKLMS.js";import"./chunk-MLAFUF6V.js";import"./chunk-CAX63KUB.js";import{b as ke,c as Je,d as Re,e as et,f as ve,g as tt,h as ot,i as Se,j as rt,k as it,l as Te,m as nt,p as Jt}from"./chunk-RZVI54SU.js";import"./chunk-BRQMZKX2.js";import"./chunk-ICR7ECHM.js";import"./chunk-SDQFBK4G.js";import{c as st,d as at}from"./chunk-AENF63HN.js";import"./chunk-ZJTWFWE3.js";import"./chunk-ZHACRE4R.js";import"./chunk-B3SQHPTA.js";import{a as ae,c as Ke}from"./chunk-U2D7GPOT.js";import"./chunk-FDMFY2TH.js";import{gc as Ye}from"./chunk-NAMHSCI2.js";import"./chunk-T4UFPV5S.js";import"./chunk-SVCEVKLL.js";import{a as Ue}from"./chunk-B42X32Z2.js";import{$ as io,Bb as lo,Ea as so,Wa as ao,_ as ro,la as no,n as Bt}from"./chunk-KB2UMCDM.js";import{A as dt,C as mo,E as P,b as eo,o as He,p as t,q as H,r as ze,s as lt,u as po,w as pt}from"./chunk-OJG7N72N.js";import{a as Tr}from"./chunk-LR3UNZEP.js";import"./chunk-ZHWDN4FA.js";import"./chunk-7FZROKRY.js";import"./chunk-B3RYBV57.js";import"./chunk-IYAJSDV2.js";import"./chunk-D4RRFCE6.js";import"./chunk-UQJK7LJ6.js";import{b as Rt}from"./chunk-LZSLSY3Q.js";import"./chunk-4ZRBCX2C.js";import{e as Kt}from"./chunk-D3AP5534.js";import"./chunk-RSNIE4RH.js";import"./chunk-ET4WBMMI.js";import{k as Yt}from"./chunk-OY2GAEXY.js";import"./chunk-T2EVB3DU.js";import{Hb as Gt,Jb as Zt,Oa as Ge,Ua as Ze,yd as we}from"./chunk-Q5O4STUM.js";import"./chunk-OA2I74DP.js";import{Q as Xe,V as Xt,b as ee,ga as W,ha as ye,i as Vt,w as X}from"./chunk-PAHUG44L.js";import"./chunk-GQMHZGE2.js";import"./chunk-WGLF2QUC.js";import{r as v}from"./chunk-IVQ3W7KJ.js";import{ta as be}from"./chunk-FJ67REU6.js";import"./chunk-MJ6GPHPN.js";import"./chunk-B4J5FBN2.js";import"./chunk-RO2HUFH7.js";import{a as c}from"./chunk-MVAHBHCD.js";import"./chunk-MEN4M6VU.js";import{f as m,h as i,n}from"./chunk-FPMOV6V2.js";i();n();var kr=m(Tr()),D=m(c());i();n();var K=m(c());var Lr=t(Le).attrs({align:"center"})``,Er=t.div`
  width: 48px;
  height: 48px;
  position: relative;
  margin-bottom: 15px;
  border-radius: 100%;
  background: rgba(255, 220, 98, 0.2);
`,Pr=t(ct).attrs({align:"center",justify:"center"})`
  height: 100%;
`,Ir=t(P).attrs({size:17,weight:500,lineHeight:22,margin:"0 0 10px 0"})``,Br=t(P).attrs({size:15,weight:500,lineHeight:21,margin:"0 0 15px 0",color:"#777777"})``,Ar=t(P).attrs({size:16,weight:500,lineHeight:22,margin:"0",color:"#AB9FF2"})``,bo=K.default.memo(e=>K.default.createElement(Lr,null,K.default.createElement(Er,null,K.default.createElement(Pr,null,K.default.createElement(so,{width:22,exclamationFill:"transparent",circleFill:"#FFE920"}))),K.default.createElement(Ir,null,e.title),K.default.createElement(Br,null,e.description),K.default.createElement(Ar,{onClick:e.refetch},e.buttonText)));i();n();var Qt=m(c());var wo=({value:e,isLoading:o,onChange:r})=>{let{t:s}=v();return Qt.default.createElement(Qr,null,Qt.default.createElement(fo,{placeholder:s("dappBrowserExtSearchPlaceholder"),value:e,onChange:a=>{"value"in a.target&&typeof a.target.value=="string"&&r(a.target.value)},showClearIcon:!!e,showLoadingIcon:o,onClear:()=>{r("")}}))},Qr=t.div`
  padding: 16px;
  padding-bottom: 0;
`;i();n();var R=m(c());i();n();var U=m(c());i();n();var F=m(c());var gt="14px",te="8px",je="#484848",Dr=t(g)`
  width: 100%;
  height: 144px;
  border-top-left-radius: ${te};
  border-top-right-radius: ${te};
`,Nr=t(g).attrs({backgroundColor:"#484848",borderRadius:"8px"})``,ht=t.div`
  background: #474747;
  height: 1px;
  opacity: 0.6;
  width: 100%;
`,ko=()=>F.default.createElement(g,{align:"center",width:"150px",height:"30px",backgroundColor:"#2D2D2D",borderRadius:te,margin:"0 auto 17px auto"}),Dt=()=>F.default.createElement(F.default.Fragment,null,F.default.createElement(g,{width:"100%",height:"308px",backgroundColor:"#2D2D2D",borderRadius:te,margin:"0 0 10px 0"},F.default.createElement(Le,null,F.default.createElement(Dr,{align:"flex-start",justify:"flex-end",margin:"0 0 10px"},F.default.createElement(Nr,{align:"flex-start",justify:"flex-end",width:"65px",height:"20px",margin:"10px 10px 0 0",borderRadius:"32px"})),F.default.createElement(Le,{padding:"16px"},F.default.createElement(g,{justify:"flex-start",width:"60px",height:gt,backgroundColor:je,borderRadius:"8px",margin:"0 0 17px 0"}),F.default.createElement(g,{justify:"flex-start",width:"125px",height:gt,backgroundColor:je,borderRadius:te})),F.default.createElement(ht,null),F.default.createElement(ct,{padding:"16px"},F.default.createElement(g,{width:"40px",height:"40px",backgroundColor:je,borderRadius:te}),F.default.createElement(Le,{width:"auto",margin:"0 0 0 10px"},F.default.createElement(g,{justify:"flex-start",width:"60px",height:gt,backgroundColor:je,borderRadius:te,margin:"0 0 5px 0"}),F.default.createElement(g,{justify:"flex-start",width:"125px",height:gt,backgroundColor:je,borderRadius:te}))))));i();n();var yt=m(c());i();n();var w=m(c());i();n();var vo=m(c()),oe=({hideAnimation:e,...o})=>vo.default.createElement(H.div,{whileHover:e?void 0:{scale:.97},transition:{ease:[.16,1,.3,1],duration:.4},...o});i();n();i();n();i();n();var We=class{constructor(o){this.onQuestSelected=o=>{this.#e.capture("questSelectedByUser",{data:{quest:o}})};this.onQuestCollectibleMinted=o=>{this.#e.capture("questCollectibleMinted",{data:{quest:o}})};this.onQuestRewardClaimed=o=>{this.#e.capture("questRewardClaimedByUser",{data:{quest:o}})};this.onQuestInterstitialPrimaryClick=o=>{this.#e.capture("questInterstitialPrimaryButtonClickedByUser",{data:{quest:o}})};this.onQuestInterstitialSecondaryClick=o=>{this.#e.capture("questInterstitialSecondaryButtonClickedByUser",{data:{quest:o}})};this.onQuestInterstitialDismiss=o=>{this.#e.capture("questInterstitialDismissedByUser",{data:{quest:o}})};this.onQuestPreviewUrlClick=(o,r)=>{this.#e.capture("questPreviewUrlClickedByUser",{data:{quest:o,url:r}})};this.#e=o}#e};i();n();var le=new We(Kt);i();n();var q=m(c());var Fr=t.div`
  padding: 16px;
`,$r=t.div`
  align-self: center;
  margin-right: 8px;
`,_r=t(dt).attrs({theme:"primary"})`
  align-self: center;
  height: 32px;
  max-width: 80px;
  padding: 8px 14px;
  width: auto;
`,So=({isQuestCompleted:e,questState:o,reward:r,onClickQuestRewardPreview:s,onClaimQuestReward:a})=>{let{t:l}=v(),p=o==="completed"||o==="claimed",x=l(o==="claimed"?"pastParticipleClaimed":"commandClaim");return q.default.createElement(Fr,null,q.default.createElement("div",{style:{display:"flex"}},q.default.createElement("div",{onClick:s,style:{cursor:e?"auto":"pointer",display:"flex",flexGrow:1,marginRight:16}},q.default.createElement($r,null,q.default.createElement(ao,null)),q.default.createElement("div",null,q.default.createElement(P,{color:"#999",textAlign:"left",size:13,lineHeight:16},l("reward")),q.default.createElement(P,{textAlign:"left",size:14,weight:600,lineHeight:16},r.title))),p&&q.default.createElement(_r,{onClick:a,disabled:o==="claimed"},q.default.createElement(P,{color:"#222",weight:600,lineHeight:16,size:13},x))))};i();n();var J=m(c());i();n();var qe=m(c());var Lo=({children:e,lineOne:o,lineTwo:r})=>qe.createElement(xo,{content:qe.createElement(Mr,{onClick:a=>{a.stopPropagation()}},qe.createElement(To,null,o),r&&qe.createElement(To,null,r)),alignment:"bottomRightDirect",index:0},e),Mr=t.div`
  display: flex;
  cursor: default;
  flex-direction: column;
  gap: 6px;
  margin-top: 8px;
  padding: 12px 16px;
  max-width: 226px;
`,To=t(P).attrs({lineHeight:17,size:14,textAlign:"start"})``;var Bo=({text:e,color:o,tooltip:r})=>r?J.default.createElement(Eo,null,J.default.createElement(Lo,{...r},J.default.createElement(Po,null,J.default.createElement(Io,{color:o},e),J.default.createElement(no,{width:16,fill:o,"data-testid":"quest-status-badge-info-icon"})))):J.default.createElement(Eo,null,J.default.createElement(Po,null,J.default.createElement(Io,{color:o},e))),Eo=t.div`
  position: absolute;
  top: 8px;
  right: 8px;
`,Po=t.div`
  display: flex;
  flex-direction: row;
  gap: 4px;
  background: rgba(34, 34, 34, 0.8);
  backdrop-filter: blur(2px);
  border-radius: 32px;
  padding: 4px 8px;
`,Io=t(P)`
  color: ${e=>e.color};
  font-size: 13px;
  font-weight: 600;
  line-height: normal;
`;var Ct=16,Ao=19,Or=t(oe)`
  border-radius: ${Ct}px;
  cursor: ${e=>e.isDisabled||e.isPreview?"auto":"pointer"};
  margin-bottom: 24px;
  position: relative;
  background: #2a2a2a;
`,Hr=t.div`
  background-color: rgba(44, 45, 48, 0.5);
  border-radius: ${Ct}px;
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
`,zr=t.div`
  align-items: center;
  border-top-left-radius: ${Ct}px;
  border-top-right-radius: ${Ct}px;
  display: flex;
  height: 144px;
  justify-content: center;
  overflow: hidden;
`,Ur=t.img`
  max-width: 100%;
`,jr=t.div`
  padding: 16px;
`,Wr=t(P)`
  margin-bottom: 8px;
`,qr=t(P)``,Vr=t(go).attrs({diameter:32})`
  background-color: transparent;
  border: 1px solid #333333;
`,Xr=e=>{let{t:o}=v(),{id:r,titleShort:s,networkIds:a,interstitial:l,reward:p,isPreview:x,previewUrl:f,questState:u}=e,{handleShowModalVisibility:L,handleHideModalVisibility:h}=yo(),C=xt(),E=w.useMemo(()=>["claimed","completed_unclaimable","completed"].includes(u),[u]),I=w.useCallback(N=>{if(x&&f!=null){le.onQuestPreviewUrlClick({questId:r,shortName:s},f),C(N,{destinationType:"External Link",url:f});return}if(E||l==null)return;let{destinationType:j,url:_e,lineItems:se,primaryButtonText:Me,secondaryButtonText:Ce,title:Pt}=l,Oe=Me.length>Ao||Ce.length>Ao;le.onQuestSelected({questId:r,shortName:s}),L("interstitial",{bodyTitle:Pt,details:se.map((It,Sr)=>({icon:w.createElement(Vr,null,w.createElement(P,{size:14},Sr+1)),title:It.title,subtitle:It.description})),icon:l.imageUrl,onDismiss:()=>{le.onQuestInterstitialDismiss({questId:r,shortName:s})},FooterComponent:()=>w.createElement(mo,{vertical:Oe,buttons:[{text:Ce,onClick:()=>{le.onQuestInterstitialSecondaryClick({questId:r,shortName:s,buttonText:Ce}),h("interstitial")}},{text:Me,theme:"primary",onClick:()=>{le.onQuestInterstitialPrimaryClick({questId:r,shortName:s,buttonText:Me}),C(N,{destinationType:j,url:_e}),h("interstitial")}}]})})},[L,h,l,C,r,E,x,f,s]),y=w.useCallback(N=>{if(E||p==null||p.hasClaimed)return;N.stopPropagation();let{title:j,description:_e,imageUrl:se}=p;L("interstitial",{bodyTitle:j,bodyDescription:_e,icon:se,FooterComponent:()=>w.createElement(dt,{onClick:()=>h("interstitial")},o("commandDismiss"))})},[E,L,h,p,o]),A=w.useCallback(()=>{p==null||p.hasClaimed||(le.onQuestRewardClaimed({questId:r,shortName:s}),L("claimReward",{questId:r,networkIds:a,onPressDismiss:()=>h("claimReward")}))},[p,r,a,L,h,s]);return w.useMemo(()=>({...e,isCompleted:E,onClickQuestRewardPreview:y,onClaimQuestReward:A,onClickQuest:I}),[E,e,I,y,A])},Gr=w.memo(e=>{let{titleLong:o,imageUrl:r,description:s,isCompleted:a,reward:l,badge:p,isPreview:x,questState:f,onClickQuest:u,onClickQuestRewardPreview:L,onClaimQuestReward:h}=e;return w.createElement(Or,{onClick:u,isDisabled:a,isPreview:x,"data-testid":"quest-list-item"},w.createElement(zr,null,w.createElement(Ur,{src:r}),p&&w.createElement(Bo,{...p}),x&&w.createElement(Hr,null)),w.createElement(ht,null),w.createElement(jr,null,w.createElement(Wr,{textAlign:"left",size:16,weight:500,lineHeight:19},o),w.createElement(qr,{color:"#999",textAlign:"left",weight:400,lineHeight:17,size:14},s)),l&&w.createElement(w.Fragment,null,w.createElement(ht,null),w.createElement(So,{isQuestCompleted:a,questState:f,reward:l,onClickQuestRewardPreview:L,onClaimQuestReward:h})))}),Qo=e=>{let o=Xr(e);return w.createElement(Gr,{...o})};var Do=({quests:e})=>yt.default.createElement(yt.default.Fragment,null,e.map(o=>yt.default.createElement(Qo,{key:o.id,...o})));var Zr=()=>{let{data:e=[],isLoading:o,error:r}=st(),{data:s}=we(),{data:a}=Yt();return(0,U.useMemo)(()=>({shouldShowQuests:!a&&s?.type!=="readOnly"&&!r,quests:e,isLoading:o}),[s,e,a,o,r])},Yr=U.default.memo(({quests:e,isLoading:o})=>o?U.default.createElement("div",null,U.default.createElement(ko,null),U.default.createElement(Dt,null),U.default.createElement(Dt,null)):U.default.createElement("div",null,U.default.createElement(Do,{quests:e}))),No=()=>{let{shouldShowQuests:e,...o}=Zr();return e?U.default.createElement(Kr,{"data-testid":"quests"},U.default.createElement(Yr,{...o})):null},Kr=t.div`
  padding: 16px;
  padding-top: 0;
`;i();n();var Nt=m(c()),bt=()=>{let{data:e}=at(),{activeSection:o,sections:r}=ae(),s=(0,Nt.useMemo)(()=>r.filter(l=>!(l==="quests"&&!e)),[r,e]),a=(0,Nt.useMemo)(()=>s.indexOf(o),[o,s]);return{sections:s,activeSection:o,activeSectionIdx:a}};i();n();var pe=m(c());function Ft({activeIndex:e,activeSection:o,items:r,animateFirstTime:s=!1}){let[a,l]=pe.default.useState(!0),p=co(e),x=e-(p||0)>0;return(0,pe.useEffect)(()=>{e!==p&&l(!1)},[e,p,l]),pe.default.createElement(Rr,null,r.map((f,u)=>pe.default.createElement(Jr,{key:f.section,testID:`animation-item-${u}`,active:o===f.section,isLeft:x,shouldAnimate:s?!0:!a,inView:!x&&e===u-1||x&&e===u+1||e===u},typeof f.render=="function"?f.render():f.render)))}var Jr=({active:e,children:o,testID:r,isLeft:s,shouldAnimate:a,inView:l})=>pe.default.createElement(ei,{active:e,"data-testid":r,shouldAnimate:a,isLeft:s,inView:l},l&&o),Rr=t.div`
  position: relative;
  width: 100%;
  height: ${e=>e.height?`${e.height}px`:"auto"};
  padding-top: 16px;
`,ei=t.div`
  display: ${e=>e.active?"block":"none"};
  visibility: ${e=>e.inView?"visible":"hidden"};
  animation-name: ${e=>e.isLeft?e.active?ti:ii:e.active?ri:oi};
  animation-duration: ${e=>e.shouldAnimate?"0.5s":"0s"};
  animation-fill-mode: forwards;
  animation-timing-function: ease-in-out;
  transition: opacity 0.5s ease-in-out;
`,ti=He`
  0% {
    left: 300px;
    opacity: 0;
  };
  100%  {
    left: 0px;
    opacity: 1
  };
`,oi=He`
  0% {
    left: 0px;
    opacity: 1;
  };
  90% {
    left: 300px;
    opacity: 0;
  };
  100%  {
    left: 600px;
    opacity: 0;
  };
`,ri=He`
  0% {
    left: -300px;
    opacity: 0;
  };
  100%  {
    left: 0px;
    opacity: 1
  };
`,ii=He`
  0% {
    left: 0px;
    opacity: 1;
  };
  90% {
    left: -300px;
    opacity: 0;
  };
  100%  {
    left: -600px;
    opacity: 0;
  };
`;i();n();var Pe=m(c());i();n();var b=m(c());i();n();var wt=(Rt-40)/2,$=`${wt}px`;var ni=({item:e,position:o})=>{let r=xt();return b.default.createElement($t,{hidePointer:!e.page,hideAnimation:!e.page,halfWidth:e.layout==="half-width","data-testid":"learn-card-tip",onClick:s=>{k.onExploreLearnItemClickedByUser({itemDetails:{position:o,id:e.id,title:e.title,type:"tip"}}),e.page&&r(s,{destinationType:e.page,url:e.url})}},b.default.createElement(kt,{background:e.backgroundColor},b.default.createElement(Mo,null,b.default.createElement(vt,null,b.default.createElement(Oo,{color:"black",opacity:.5},b.default.createElement(di,{"data-testid":"learn-card-tip-icon"},b.default.createElement("img",{width:"16px",height:"16px",src:e.icon})),e.title)),b.default.createElement(vt,null,b.default.createElement(_t,{opacity:.7},e.description)))))},si=({item:e,position:o})=>{let r=(0,b.useCallback)(()=>{k.onExploreLearnItemClickedByUser({itemDetails:{position:o,id:e.id,title:e.title,type:"article"}})},[e.id,e.title,o]);return e.layout==="half-width"?b.default.createElement(Fo,{href:e.url,onClick:r},b.default.createElement($t,{halfWidth:!0,"data-testid":"learn-card-article-half"},b.default.createElement(kt,null,b.default.createElement(pi,{style:{height:"50%"}},b.default.createElement($o,{src:e.backgroundImageUrl})),b.default.createElement(li,{background:e.backgroundColor},b.default.createElement(_t,null,e.title))))):b.default.createElement(Fo,{href:e.url,onClick:r},b.default.createElement($t,{"data-testid":"learn-card-article-full"},b.default.createElement(kt,{background:e.backgroundColor},b.default.createElement(Mo,null,b.default.createElement(_t,null,e.title),b.default.createElement(Oo,{color:"#474747"},e.description))),b.default.createElement(kt,null,b.default.createElement($o,{src:e.backgroundImageUrl}))))},_o=({items:e})=>b.default.createElement(ai,{"data-testid":"learn-cards"},e.map((o,r)=>o.type==="learnArticle"?b.default.createElement(si,{item:o,key:o.title,position:r}):b.default.createElement(ni,{item:o,key:o.title,position:r}))),ai=t.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  gap: 8px;
`,$t=t(oe)`
  border-radius: 16px;
  height: ${$};
  display: flex;
  overflow: hidden;
  cursor: ${e=>e.hidePointer?"auto":"pointer"};
  width: ${e=>e.halfWidth?"calc(50% - 4px)":"auto"};
`,Fo=t.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  display: contents;
`,kt=t.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  width: 100%;
  background: ${e=>e.background||"auto"};
`,Mo=t.div`
  padding: 12px 16px;
  display: flex;
  height: 100%;
  flex-direction: column;
  justify-content: space-between;
`,vt=t.div`
  display: flex;
`,li=t(vt)`
  padding: 16px;
  background: ${e=>e.background||"auto"};
`,pi=t(vt)`
  flex: 1;
`,_t=t(P)`
  text-align: left;
  color: black;
  font-size: 18px;
  font-style: normal;
  font-weight: 600;
  line-height: 24px;
  letter-spacing: -0.36px;
`,Oo=t(P)`
  text-align: left;
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
  display: flex;
  align-items: center;
`,$o=t.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,di=t.span`
  display: flex;
  margin-right: 4px;
`;i();n();var Q=m(c());var Ho=()=>Q.default.createElement(jo,null,Q.default.createElement(Wo,null,Q.default.createElement(Ee,{width:"110px"}),Q.default.createElement(Ee,{width:"90px"}),Q.default.createElement(Ee,{width:"105px"})),Q.default.createElement(ci,null,Q.default.createElement(Ee,{width:"64px"}))),zo=()=>Q.default.createElement(jo,null,Q.default.createElement(Wo,null,Q.default.createElement(Ee,{width:"110px"}),Q.default.createElement(Ee,{width:"90px"}))),Uo=()=>Q.default.createElement(mi,{"data-testid":"learn-skeleton"},Q.default.createElement(Ho,null),Q.default.createElement(ui,null,Q.default.createElement(zo,null),Q.default.createElement(zo,null)),Q.default.createElement(Ho,null)),mi=t.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-bottom: 10px;
`,jo=t(g)`
  background: #323232;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: ${$};
  border-radius: 14px;
  padding: 16px;
  justify-content: flex-end;
`,ci=t.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: flex-end;
`,Wo=t.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,ui=t.div`
  display: flex;
  gap: 8px;
`,Ee=t(g)`
  height: 16px;
  border-radius: 16px;
`;var qo=()=>{let{isLoading:e,data:o,error:r,refetch:s}=nt(),{t:a}=v();return r&&!e&&!o||o?.data.length===0?Pe.default.createElement(xi,null,Pe.default.createElement(uo,{title:a("exploreLearnErrorTitle"),description:a("exploreLearnErrorDescription"),refetch:s})):Pe.default.createElement(fi,{"data-testid":"learn-container"},e?Pe.default.createElement(Uo,null):Pe.default.createElement(_o,{items:o?.data||[]}))},fi=t.div`
  padding: 0 16px 16px 16px;
`,xi=t.div`
  padding: 16px;
`;i();n();var De=m(c());i();n();var me=m(c());i();n();var B=m(c());i();n();var V=m(c());function Vo({items:e=10}){let o=(0,V.useMemo)(()=>{let r=[];for(let s=0;s<e;s++)r.push(s);return r},[e]);return V.default.createElement(hi,null,o.map(r=>V.default.createElement(gi,{key:r})))}function gi(){return V.default.createElement(Ci,null,V.default.createElement(bi,null,V.default.createElement(wi,null,V.default.createElement(g,{width:"90px",height:"16px",marginBottom:"4px",borderRadius:"16px"}),V.default.createElement(g,{width:"64px",height:"16px",borderRadius:"16px"})),V.default.createElement(yi,null)))}var hi=t.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding-left: 16px;
  margin-bottom: 24px;
`,Ci=t(g)`
  background: #323232;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  padding: 6px 8px 8px 12px;

  margin-right: 8px;
  border-radius: 16px;
  height: ${$};
  width: ${$};
  min-width: ${$};
`,yi=t(g)`
  background: ${e=>e.theme.skeletonLight};
  border-radius: 14px;
  height: 48px;
  width: 48px;
  margin-bottom: 8px;
`,bi=t.div`
  display: flex;
  width: 100%;
  flex-direction: row;
  justify-content: space-between;
`,wi=t.div`
  display: flex;

  flex-direction: column;
  justify-content: flex-end;
`;var Go=8,Mt=-1*(wt+Go),ki={type:"spring",stiffness:256.1,damping:24,mass:1},Ot=2;function de({items:e,renderCard:o,isLoading:r,isEmpty:s,name:a}){let[l,p]=(0,B.useState)(0),[x,f]=(0,B.useState)(!1),u=lt(0),L=(0,B.useMemo)(()=>Mt*(e.length-Ot),[e]),h=(0,B.useCallback)(y=>y<0?0:y>e.length-1?e.length-1:y,[e]),C=(0,B.useCallback)(()=>h(Math.round(u.get()/Mt)),[u,h]);po(u,"change",()=>{p(C())});let E=(0,B.useCallback)(y=>{let N=h(y)*Mt;pt(u,N,ki),k.onExploreCarouselDragged({listName:a})},[h,u,a]),I={fill:"#222",width:16,height:16};return r?B.default.createElement(Vo,null):s?null:B.default.createElement(vi,{"data-testid":`explore-carousel-${a}`},B.default.createElement(ze,{initial:!1},l>=1&&B.default.createElement(Xo,{onClick:()=>E(l-1)},B.default.createElement(ro,{...I}))),B.default.createElement(ze,{initial:!1},l<=e.length-Ot-1&&B.default.createElement(Xo,{isRight:!0,onClick:()=>E(l+1)},B.default.createElement(io,{...I}))),B.default.createElement(Si,{style:{x:u},drag:e.length>Ot?"x":void 0,dragConstraints:{left:L,right:0},onDragStart:()=>f(!0),onDragEnd:()=>{f(!1),E(C()),k.onExploreCarouselDragged({listName:a})},onWheel:y=>{if(y.deltaX===0)return;let A=u.get()-y.deltaX;return A>0?u.set(0):A<L?u.set(L):u.set(A)}},e.map((y,A)=>B.default.createElement(Ti,{key:`carousel-item-${A}`,isLast:A===e.length-1,onClick:N=>{x&&(N.stopPropagation(),N.preventDefault())}},o(y,A)))))}var vi=t.div`
  width: 100vw;
  margin-bottom: 24px;
`,Si=t(H.div)`
  display: flex;
  flex-direction: row;
  padding: 0 16px;
`,Ti=t(oe)`
  position: relative;
  margin-right: ${e=>e.isLast?0:Go}px;
`,Xo=t(H.div).attrs({transition:{ease:[.16,1,.3,1],duration:.5},initial:{opacity:0,translateY:8},animate:{opacity:1,translateY:0},exit:{opacity:0,translateY:8}})`
  background: #ab9ff2;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  position: absolute;
  z-index: 1;
  left: ${e=>e.isRight?"auto":"4px"};
  right: ${e=>e.isRight?"4px":"auto"};
  top: ${wt/2}px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  box-shadow:
    0px 1px 2px 0px rgba(0, 0, 0, 0.19),
    0px 3px 3px 0px rgba(0, 0, 0, 0.17),
    0px 7px 4px 0px rgba(0, 0, 0, 0.1),
    0px 12px 5px 0px rgba(0, 0, 0, 0.03),
    0px 18px 5px 0px rgba(0, 0, 0, 0);
`;i();n();var re=m(c());i();n();var Ve=m(c());var St=({src:e,children:o})=>Ve.default.createElement(Ve.default.Fragment,null,Ve.default.createElement(Li,{src:e}),Ve.default.createElement(Ei,null,o)),Li=t(z)`
  width: ${$};
  height: ${$};
  border-radius: 16px;
`,Ei=t.div`
  position: absolute;
  left: 0;
  background: rgba(24, 24, 24, 0.8);
  backdrop-filter: blur(24px);
  width: 100%;
  height: 54px;

  /* reduce by 1 pixel to prevent border-radius clipping issue */
  bottom: -1px;
  border-bottom-left-radius: 15px;
  border-bottom-right-radius: 15px;
`;var Zo=({collection:e})=>{let o=(0,re.useMemo)(()=>{let r=new ee(e.floorPrices[0].value,10).dividedBy(new ee(10).pow(e.floorPrices[0].paymentToken.decimals)).toNumber();return`${W(r)} ${e.floorPrices[0].paymentToken.symbol} `},[e.floorPrices]);return re.default.createElement(St,{src:e.imageUrl},re.default.createElement(Pi,null,re.default.createElement("div",null,re.default.createElement(Ii,null,X(e.name,9)),re.default.createElement(Bi,null,o))))},Pi=t.div`
  width: 100%;
  padding: 8px 12px;
`,Ii=t.div`
  font-size: 18px;
  font-weight: 600;
  line-height: 22px;
`,Bi=t.div`
  font-weight: 600;
  color: ${e=>e.theme.grayLight};
  font-size: 14px;
  line-height: 18px;
`;i();n();var Ht=m(c());function Ie({children:e,onPress:o}){return Ht.default.createElement(Ai,{onClick:o},e,Ht.default.createElement(Qi,null))}var Ai=t.div`
  width: ${$};
  height: ${$};
  position: relative;
  cursor: pointer;
  overflow: hidden;
`,Qi=t.div`
  background: transparent;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  cursor: pointer;
`;function Yo(){let{isExploreCollectionsLoading:e}=ve(),{error:o,data:r}=et(),s=(0,me.useCallback)((a,l)=>me.default.createElement(Di,{href:a.marketplacePages[0].collectionUrl},me.default.createElement(Ie,{key:`carousel-card-collections-${l}`,onPress:()=>{k.onExploreCarouselItemClickedByUser({datasourceId:r?.uuid||"",carouselName:"collections",itemDetails:{position:l,title:a.name,id:a.id}})}},me.default.createElement(Zo,{collection:a}))),[r?.uuid]);return me.default.createElement(de,{name:"collections",items:r?r.data:[],renderCard:s,isLoading:e,isEmpty:!!o&&(!r?.data||r?.data?.length===0)})}var Di=t.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  display: contents;
`;i();n();var T=m(c());var Jo="200px";function ce({tab:e}){let{data:o,mutate:r}=ke(),{currentSortOption:s,getSortOptions:a,setSortOption:l}=Je(),p=a(e),x=u=>{l(e,u)},f=s(e);return T.default.createElement($i,{"data-testid":`explore-filters-${e}`},T.default.createElement(Fi,{value:f,options:p,onChange:u=>{x(u),k.onExploreFilterChangedByUser({filterType:"sort",filterValue:u,listName:e})}}),T.default.createElement(Ni,{value:o,onChange:u=>{r(u),k.onExploreFilterChangedByUser({filterType:"network",filterValue:u,listName:e})}}))}var Ko=({filter:e})=>{let[o,r]=T.default.useState(!1),{t:s}=v(),a=()=>r(!0),l=()=>r(!1),p,x;return e==="all_networks"?(p=s("exploreFilterByall_networks"),x=T.default.createElement(lo,{fill:o?Ue.purple:Ue.white})):(p=Ge.getChainName(e),x=T.default.createElement(ho,{size:20,backgroundColor:o?"accentPrimary":"white",networkID:e})),T.default.createElement(_i,{onMouseEnter:a,onMouseLeave:l},T.default.createElement("span",{style:{color:o?Ue.purple:Ue.white}},p),x)};function Ni({value:e,onChange:o}){let{t:r}=v(),{data:[s]}=be(["enable-bitcoin-explore"]),a=Gt(),l=(0,T.useMemo)(()=>{let x=[];return a.filter(f=>f!=="bitcoin"||s).forEach(f=>{let u=Ge.getMainnetNetworkID(f);x.push({label:T.default.createElement(Ko,{filter:u}),key:u,onClick:()=>o(u)})}),x.length>1&&x.push({label:T.default.createElement(Ko,{filter:"all_networks"}),key:"all_networks",onClick:()=>o("all_networks")}),x},[a,s,o]),p=x=>x==="all_networks"?r("exploreFilterByall_networks"):Ge.getNetworkName(x);return l.length>1?T.default.createElement(Ro,null,T.default.createElement(At,{items:l,dropdownWidth:Jo,noDropdownItemPadding:!0},T.default.createElement(er,null,T.default.createElement(tr,null,p(e)),T.default.createElement(Bt,{width:12,height:12,fill:"#999999"})))):null}function Fi({options:e,value:o,onChange:r}){let{t:s}=v(),a=(0,T.useMemo)(()=>e.map(p=>({label:s(`exploreSortBy${p}`),key:p,onClick:()=>{r(p)}})),[r,e,s]);return T.default.createElement(Ro,null,T.default.createElement(At,{items:a,dropdownWidth:Jo},T.default.createElement(er,{"data-testid":"exploreSortBy-button"},T.default.createElement(tr,null,s(`exploreSortBy${o}`)),T.default.createElement(Bt,{width:12,height:12,fill:"#999999"}))))}var $i=t.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  padding: 8px 16px 4px 16px;
`,Ro=t.div`
  margin-right: 4px;
`,_i=t.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 100%;
  justify-content: space-between;
  padding: 7px 0;
`,er=t(H.div).attrs({activeOpacity:.6,whileHover:{background:"#3B3C40"},transition:{ease:[.5,1,.89,1],duration:.1},style:{background:"#2a2a2a"}})`
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  border-radius: 48px;
  display: flex;
  height: 32px;
  cursor: pointer;
`,tr=t.div`
  margin-right: 6px;
  color: ${e=>e.theme.white};
  font-size: 15px;
  font-weight: 600;
`;i();n();var Tt=m(c());function Be(){return Tt.default.createElement(Mi,null,Tt.default.createElement(or,{width:"99px",height:"26px"}),Tt.default.createElement(or,{width:"124px",height:"26px"}))}var Mi=t.div`
  display: flex;
  flex-direction: row;
  padding: 8px 16px 16px 16px;
`,or=t(g)`
  background: ${e=>e.theme.skeletonLight};
  border-radius: 48px;
  margin-right: 4px;
`;i();n();var xe=m(c());i();n();var zt=m(c());var Ae=()=>{let{t:e}=v();return zt.default.createElement("div",{"data-testid":"explore-network-error",className:Oi.wrapper},zt.default.createElement(oo,{children:e("exploreNetworkError"),level:"3-critical-error"}))},Oi={wrapper:to({padding:16,backgroundColor:"bgWallet",height:"100%"})};i();n();var ue=m(c());i();n();var M=m(c());function rr({items:e=10}){let o=(0,M.useMemo)(()=>{let r=[];for(let s=0;s<e;s++)r.push(s);return r},[e]);return M.default.createElement(zi,{"data-testid":"explore-list-skeleton"},o.map((r,s)=>M.default.createElement(Hi,{key:r,index:s+1})))}function Hi({index:e}){return M.default.createElement(Ui,null,M.default.createElement(ji,null,M.default.createElement(qi,null,M.default.createElement(Vi,null,e)),M.default.createElement(Xi,null),M.default.createElement("div",null,M.default.createElement(g,{width:"95px",height:"20px",marginBottom:"4px",borderRadius:"16px"}),M.default.createElement(g,{width:"69px",height:"20px",borderRadius:"16px"}))),M.default.createElement(Wi,null,M.default.createElement(g,{width:"69px",height:"20px",marginBottom:"4px",borderRadius:"16px"}),M.default.createElement(g,{width:"38px",height:"20px",borderRadius:"16px"})))}var zi=t.div`
  padding: 0 16px;
  flex-direction: column;
  width: 100%;
`,Ui=t.div`
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  gap: 10px;
  display: flex;
  padding: 12px 0;
`,ji=t.div`
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  display: flex;
`,Wi=t.div`
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  text-align: right;
`,qi=t.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
`,Vi=t.div`
  font-size: 14px;
  line-height: 18px;
  color: #777777;
`,Xi=t(g)`
  background: ${e=>e.theme.skeletonLight};
  border-radius: 14px;
  height: 48px;
  width: 48px;
`;function fe({items:e,listName:o,renderItem:r,header:s,isLoading:a}){return ue.default.createElement(Gi,{"data-testid":`explore-list-${o}`},s,ue.default.createElement(ze,null,a&&ue.default.createElement(Yi,null,ue.default.createElement(rr,null))),!a&&e.map((l,p)=>ue.default.createElement(Zi,{key:`list-item-${o}-${p}`,"data-testid":`list-item-${o}-${p}`,whileHover:{background:"#333"},style:{background:"#222"},transition:{ease:[.5,1,.89,1],duration:.1}},ue.default.createElement(oe,null,r(l,p)))))}var Gi=t.div`
  flex-direction: column;
  width: 100%;
`,Zi=t(H.div)`
  flex: 1;
  width: 100%;
  cursor: pointer;
`,Yi=t(H.div).attrs({initial:{opacity:1},animate:{opacity:1},exit:{opacity:0},transition:{duration:.2,ease:"easeInOut"}})``;i();n();var _=m(c());var ir=({collection:e,position:o})=>{let r=(0,_.useMemo)(()=>{let a=new ee(e.floorPrices[0].value,10).dividedBy(new ee(10).pow(e.floorPrices[0].paymentToken.decimals)).toNumber();return`${W(a)} ${e.floorPrices[0].paymentToken.symbol} `},[e.floorPrices]),s=(0,_.useMemo)(()=>{let a=new ee(e.volume||0,10).dividedBy(new ee(10).pow(e.floorPrices[0].paymentToken.decimals)).toNumber();return`${W(a,{compact:a>=1e3})} ${e.floorPrices[0].paymentToken.symbol}`},[e.volume,e.floorPrices]);return _.default.createElement(Ki,null,_.default.createElement(Ji,null,_.default.createElement(en,null,_.default.createElement(tn,null,o)),_.default.createElement(an,{src:e.imageUrl,width:48,height:48,fallback:_.default.createElement(g,{borderRadius:"14px",width:"48px",height:"48px"}),loader:_.default.createElement(g,{borderRadius:"14px",width:"48px",height:"48px"})}),_.default.createElement("div",null,_.default.createElement(on,null,X(e.name,15)),_.default.createElement(rn,null,r))),_.default.createElement(Ri,null,_.default.createElement(nn,null,s),_.default.createElement(sn,{green:e.volumePercentChange>=0},W(e.volumePercentChange,{compact:!0,includePlusPrefix:!0}),"%")))},Ki=t.div`
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  gap: 10px;
  display: flex;
`,Ji=t.div`
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  display: flex;
`,Ri=t.div`
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  text-align: right;
`,en=t.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
`,tn=t.div`
  font-size: 14px;
  line-height: 18px;
  color: #777777;
  font-weight: 600;
`,on=t.div`
  font-size: 17px;
  line-height: 22px;
  height: 22px;
  overflow-x: hidden;
`,rn=t.div`
  font-size: 15px;
  line-height: 20px;
  color: ${e=>e.theme.grayLight};
`,nn=t.div`
  font-size: 17px;
  line-height: 22px;
  white-space: nowrap;
`,sn=t.div`
  font-size: 15px;
  line-height: 20px;
  color: ${e=>e.green?e.theme.green:e.theme.alert};
  text-align: right;
`,an=t(z)`
  border-radius: 14px;
  width: 48px;
  height: 48px;
`;i();n();var nr=m(c());function Qe({children:e,onPress:o}){return nr.default.createElement(ln,{onClick:o},e)}var ln=t.div`
  width: 100%;
  padding: 12px 16px;
`;i();n();var ie=m(c());var Lt=({titles:e})=>ie.default.createElement(pn,null,ie.default.createElement(dn,null,ie.default.createElement(cn,null,ie.default.createElement(Ut,null,e[0])),ie.default.createElement(Ut,null,e[1])),ie.default.createElement(mn,null,ie.default.createElement(Ut,null,e[2]))),pn=t.div`
  flex-direction: row;
  width: 100%;
  justify-content: space-between;
  display: flex;
  padding-left: 16px;
  padding-right: 16px;
  padding-bottom: 4px;
  padding-top: 12px;
`,dn=t.div`
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  display: flex;
`,mn=t.div`
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  display: flex;
`,Ut=t.div`
  font-size: 14px;
  line-height: 18px;
  font-weight: 600;
  color: ${e=>e.theme.grayLight};
`,cn=t.div`
  width: 74px;
  padding-left: 4px;
`;function sr(){let{isExploreCollectionsLoading:e}=ve(),{error:o,data:r}=Re(),{t:s}=v(),a=(l,p)=>xe.default.createElement(un,{key:`list-collections-${p}`,href:l.marketplacePages[0].collectionUrl},xe.default.createElement(Qe,{onPress:()=>{k.onExploreListItemClickedByUser({datasourceId:r?.uuid||"",listName:"collections",itemDetails:{position:p,title:l.name,id:l.id}})}},xe.default.createElement(ir,{collection:l,position:p+1})));return o&&!r?xe.default.createElement(Ae,null):xe.default.createElement(fe,{items:r?r.data:[],renderItem:a,listName:"collections",header:xe.default.createElement(Lt,{titles:["#",s("exploreFloor"),s("exploreVolume")]}),isLoading:e})}var un=t.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  display: contents;
`;var ar=()=>{let{isExploreCollectionsLoading:e}=ve();return De.default.createElement("div",null,De.default.createElement(Yo,null),e?De.default.createElement(Be,null):De.default.createElement(ce,{tab:"collections"}),De.default.createElement(sr,null))};i();n();var Fe=m(c());i();n();var ge=m(c());i();n();var ne=m(c());var lr=({site:e})=>{let{t:o}=v();return ne.default.createElement(St,{src:e.backgroundImageUrl},ne.default.createElement(fn,null,ne.default.createElement(hn,null,ne.default.createElement(xn,null,e.name),ne.default.createElement(gn,null,o(`exploreCategory${e.category.replaceAll(" ","")}`,{defaultValue:e.category}))),ne.default.createElement(Cn,null,ne.default.createElement(yn,{src:e.imageUrl}))))},fn=t.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 6px 12px 8px 12px;
`,xn=t.div`
  font-weight: 600;
  font-size: 18px;
  line-height: 22px;
  width: 100%;
  white-space: nowrap;
  -webkit-mask-image: linear-gradient(91deg, black 85%, transparent);
`,gn=t.div`
  color: ${e=>e.theme.grayLight};
  font-size: 14px;
  font-weight: 600;
  line-height: 18px;
`,hn=t.div`
  flex: 1;
  width: 100%;
  overflow-x: hidden;
`,Cn=t.div`
  transform: translateY(-12px);
`,yn=t(z)`
  width: 48px;
  height: 48px;
  border-radius: 14px;
`;function pr(){let{isExploreSitesLoading:e}=Se(),{error:o,data:r}=tt(),s=(0,ge.useCallback)((a,l)=>ge.default.createElement(bn,{key:`carousel-card-sites-${l}`,href:Xe(a.url)},ge.default.createElement(Ie,{onPress:()=>{k.onExploreCarouselItemClickedByUser({datasourceId:r?.uuid||"",carouselName:"sites",itemDetails:{position:l,title:a.name,id:a.id}})}},ge.default.createElement(lr,{site:a}))),[r?.uuid]);return ge.default.createElement(de,{name:"sites",items:r?r.data:[],renderCard:s,isLoading:e,isEmpty:!!o&&(!r?.data||r?.data?.length===0)})}var bn=t.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  display: contents;
`;i();n();var Ne=m(c());i();n();var G=m(c());var dr=({site:e,position:o})=>{let{t:r}=v();return G.default.createElement(wn,null,G.default.createElement(kn,null,G.default.createElement(vn,null,o)),G.default.createElement(Ln,{src:e.imageUrl,width:48,height:48,fallback:G.default.createElement(g,{borderRadius:"14px",width:"48px",height:"48px"}),loader:G.default.createElement(g,{borderRadius:"14px",width:"48px",height:"48px"})}),G.default.createElement("div",null,G.default.createElement(Sn,null,X(e.name,15)),G.default.createElement(Tn,null,r(`exploreCategory${e.category.replaceAll(" ","")}`,{defaultValue:e.category}))))},wn=t.div`
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  gap: 10px;
  display: flex;
  align-items: center;
`,kn=t.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
`,vn=t.div`
  font-size: 14px;
  line-height: 18px;
  color: #777777;
  font-weight: 600;
`,Sn=t.div`
  font-size: 17px;
  line-height: 22px;
`,Tn=t.div`
  font-size: 15px;
  line-height: 20px;
  color: ${e=>e.theme.grayLight};
`,Ln=t(z)`
  border-radius: 14px;
  width: 48px;
  height: 48px;
`;function mr(){let{isExploreSitesLoading:e}=Se(),{error:o,data:r}=ot(),s=(a,l)=>Ne.default.createElement(En,{key:`list-sites-${l}`,href:Xe(a.url)},Ne.default.createElement(Qe,{onPress:()=>{k.onExploreListItemClickedByUser({datasourceId:r?.uuid||"",listName:"sites",itemDetails:{position:l,title:a.name,id:a.id}})}},Ne.default.createElement(dr,{site:a,position:l+1})));return o&&!r?Ne.default.createElement(Ae,null):Ne.default.createElement(fe,{items:r?r.data:[],renderItem:s,listName:"sites",isLoading:e,header:null})}var En=t.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  text-decoration: none;
  display: contents;
`;var cr=()=>{let{isExploreSitesLoading:e}=Se();return Fe.default.createElement("div",null,Fe.default.createElement(pr,null),e?Fe.default.createElement(Be,null):Fe.default.createElement(ce,{tab:"sites"}),Fe.default.createElement(mr,null))};i();n();var $e=m(c());i();n();var he=m(c());i();n();var Z=m(c());var ur=({token:e})=>{let o=e.tokens[0];return Z.default.createElement(Pn,null,Z.default.createElement(In,null,Z.default.createElement(Bn,null,Z.default.createElement(An,null,X(o.data.name||"",12)),Z.default.createElement(Qn,null,o.data.symbol)),Z.default.createElement(Dn,{src:o.data.logoUri||""})),Z.default.createElement(Nn,null,Z.default.createElement(Fn,null,ye(parseFloat(e.currentPrice),{minimumAmount:1e-6,decimalFormatSmallNumbers:"0.[000000]",roundDecimals:!0})),Z.default.createElement($n,{green:parseFloat(e.priceChangePercentage)>=0},W(parseFloat(e.priceChangePercentage),{includePlusPrefix:!0,suffix:"%"}))))},Pn=t.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: ${$};
  width: ${$};
  padding: 10px 12px;
  background-color: #2c2d30;
  border-radius: 16px;
`,In=t.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 8px;
`,Bn=t.div`
  height: 36px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 3px;
`,An=t.div`
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`,Qn=t.div`
  color: ${e=>e.theme.grayLight};
  font-size: 13px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
`,Dn=t(z)`
  width: 32px;
  height: 32px;
  border-radius: 100px;
`,Nn=t.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
`,Fn=t.div`
  font-size: 22px;
  font-style: normal;
  font-weight: 500;
  line-height: 24px;
  letter-spacing: -0.44px;
`,$n=t.div`
  font-size: 13px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  color: ${e=>e.green?e.theme.green:e.theme.alert};
`;function fr(){let{data:e}=ke(),{isExploreTokensLoading:o}=Te(),{error:r,data:s}=rt(),a=ut(),{data:l}=we(),p=l?.isReadOnly,{pushDetailView:x}=mt(),{data:[f,u]}=be(["enable-public-fungible-detail-page","enable-public-fungible-detail-page-from-explore"]),L=f&&u,h=(0,he.useCallback)((C,E)=>he.default.createElement(Ie,{key:`carousel-card-token-${E}`,onPress:()=>{let I=C.tokens.find(y=>y.data.chain.id===e)??C.tokens[0];if(L){let y=Ze(Ye(I));x(he.default.createElement(ft,{caip19:y,title:I.data.name??void 0,entryPoint:"explore"}))}else if(Ke(p,C))a({buyFungible:I});else return;k.onExploreCarouselItemClickedByUser({datasourceId:s?.uuid||"",carouselName:"tokens",itemDetails:{position:E,title:C.tokens[0].data.name||C.id,id:C.id||""}})}},he.default.createElement(ur,{token:C})),[L,p,s?.uuid,e,x,a]);return he.default.createElement(de,{name:"tokens",items:s?s.data:[],renderCard:h,isLoading:o,isEmpty:!!r&&(!s?.data||s?.data?.length===0)})}i();n();var Y=m(c());i();n();var S=m(c());var gr=({token:e,position:o,displayType:r})=>{let s=e.tokens[0],a=(0,S.useMemo)(()=>{switch(r){case"market_cap":return S.default.createElement(S.default.Fragment,null,S.default.createElement(jt,null,ye(parseFloat(e.marketCap)||0,{compact:!0})),S.default.createElement(xr,{green:parseFloat(e.marketCapChangePercentage)>=0},W(parseFloat(e.marketCapChangePercentage),{includePlusPrefix:!0,suffix:"%",compact:!0})));case"volume":return S.default.createElement(S.default.Fragment,null,S.default.createElement(jt,null,ye(parseFloat(e.volume)||0,{compact:!0})));default:return S.default.createElement(S.default.Fragment,null,S.default.createElement(jt,null,ye(parseFloat(e.currentPrice),{minimumAmount:1e-6,decimalFormatSmallNumbers:"0.[000000]",roundDecimals:!0})),S.default.createElement(xr,{green:parseFloat(e.priceChangePercentage)>=0},W(parseFloat(e.priceChangePercentage),{includePlusPrefix:!0,suffix:"%",compact:!0})))}},[r,e]);return S.default.createElement(_n,null,S.default.createElement(Mn,null,S.default.createElement(zn,null,S.default.createElement(Un,null,o)),S.default.createElement(qn,{src:s.data.logoUri||"",width:48,height:48,fallback:S.default.createElement(Xn,null,S.default.createElement(Vn,null,s.data.symbol)),loader:S.default.createElement(g,{borderRadius:"14px",width:"48px",height:"48px"})}),S.default.createElement(On,null,S.default.createElement(jn,null,X(s.data.name||"",15)),S.default.createElement(Wn,null,s.data.symbol))),S.default.createElement(Hn,null,a))},_n=t.div`
  flex-direction: row;
  flex-wrap: no-wrap;
  justify-content: space-between;
  gap: 10px;
  display: flex;
`,Mn=t.div`
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 8px;
  display: flex;
  overflow: hidden;
`,On=t.div`
  overflow: hidden;
`,Hn=t.div`
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  display: flex;
  flex: 1;
`,zn=t.div`
  width: 18px;
  min-width: 18px;
  height: 18px;
  min-height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
`,Un=t.div`
  font-size: 14px;
  line-height: 18px;
  color: #777777;
  font-weight: 600;
`,jn=t.div`
  font-size: 17px;
  line-height: 22px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,Wn=t.div`
  font-size: 15px;
  line-height: 20px;
  color: ${e=>e.theme.grayLight};
`,jt=t.div`
  font-size: 17px;
  line-height: 22px;
`,xr=t.div`
  font-size: 15px;
  line-height: 20px;
  color: ${e=>e.green?e.theme.green:e.theme.alert};
`,qn=t(z)`
  width: 48px;
  height: 48px;
  border-radius: 100px;
`,Vn=t.div.attrs({numberOfLines:1})`
  color: ${e=>e.theme.white};
  font-size: 12px;
`,Xn=t.div`
  width: 48px;
  min-width: 48px;
  height: 48px;
  min-height: 48px;
  border-radius: 100px;
  background-color: ${e=>e.theme.buttonGray};
  display: flex;
  align-items: center;
  justify-content: center;
`;function hr({displayType:e}){let{data:o}=ke(),{isExploreTokensLoading:r}=Te(),{error:s,data:a}=it(),{t:l}=v(),{data:p}=we(),x=p?.isReadOnly,f=ut(),{data:[u,L]}=be(["enable-public-fungible-detail-page","enable-public-fungible-detail-page-from-explore"]),h=u&&L,C=(0,Y.useMemo)(()=>{switch(e){case"market_cap":return["#",l("exploreToken"),l("exploreCap")];case"gainers":case"losers":return["#",l("exploreToken"),l("explorePrice")];default:return["#",l("exploreToken"),l("explore24hVolume")]}},[e,l]),{pushDetailView:E}=mt(),I=(y,A)=>Y.default.createElement(Qe,{key:`list-tokens-${A}`,onPress:()=>{let N=y.tokens.find(j=>j.data.chain.id===o)??y.tokens[0];if(h){let j=Ze(Ye(N));E(Y.default.createElement(ft,{caip19:j,title:N.data.name??void 0,entryPoint:"explore"}))}else if(Ke(x,y))f({buyFungible:N});else return;k.onExploreListItemClickedByUser({datasourceId:a?.uuid||"",listName:"tokens",itemDetails:{position:A,title:N.data.name||y.id,id:y.id}})}},Y.default.createElement(Gn,null,Y.default.createElement(gr,{token:y,position:A+1,displayType:e})));return s&&!a?Y.default.createElement(Ae,null):Y.default.createElement(fe,{items:a?a.data:[],renderItem:I,listName:"tokens",isLoading:r,header:Y.default.createElement(Lt,{titles:C})})}var Gn=t.div`
  cursor: pointer;
`;var Cr=()=>{let{isExploreTokensLoading:e}=Te(),{currentSortOption:o}=Je(),r=o("tokens");return $e.default.createElement("div",null,$e.default.createElement(fr,null),e?$e.default.createElement(Be,null):$e.default.createElement(ce,{tab:"tokens"}),$e.default.createElement(hr,{displayType:r}))};function yr(){let{sections:e,activeSection:o,activeSectionIdx:r}=bt(),s=(0,R.useMemo)(()=>e.map(a=>{switch(a){case"sites":return{section:a,render:R.default.createElement(cr,null)};case"tokens":return{section:a,render:R.default.createElement(Cr,null)};case"collections":return{section:a,render:R.default.createElement(ar,null)};case"quests":return{section:a,render:R.default.createElement(No,null)};case"learn":return{section:a,render:R.default.createElement(qo,null)};default:return null}}).filter(Vt),[e]);return R.default.createElement(Ft,{activeIndex:r,activeSection:o,items:s})}i();n();var Et=m(c());i();n();var O=m(c());var Wt=16,Zn={duration:.3,delay:0,ease:"easeOut"};function qt({values:e,activeTabIndex:o,setActiveTabIndex:r}){let s=(0,O.useRef)(null),[a,l]=(0,O.useState)(null),[p,x]=(0,O.useState)(0);(0,O.useEffect)(()=>{s.current&&x(s.current.scrollWidth)},[e]);let f=lt(0),u=(0,O.useMemo)(()=>{let h=self.innerWidth-p-Wt;return Math.min(0,h)},[p]),L=(0,O.useCallback)((h,C)=>{let{left:E,right:I}=h.getBoundingClientRect(),y=I>self.innerWidth-Wt,A=E<Wt;if(y||A)return pt(f,C!==void 0?C:y?u:0,Zn)},[f,u]);return O.default.createElement(Yn,{ref:s},O.default.createElement(Kn,{drag:"x",style:{x:f},dragConstraints:{left:u,right:0},onDragStart:()=>{l(f.get())},onDragEnd:()=>{l(null),k.onExploreTabTitlesDragged()},onWheel:h=>{if(h.deltaX===0)return;let C=f.get()-h.deltaX;return C>0?f.set(0):C<u?f.set(u):f.set(C)}},e.map((h,C)=>{let E=o===C;return O.default.createElement(Jn,{"data-testid":`tab-title-${h}`,key:`tab-title-${C}`,active:o===C},O.default.createElement(Rn,{onClick:I=>{if(a!==null){I.stopPropagation(),I.preventDefault();return}r(C),L(I.currentTarget)},isActive:E},h))})))}var Yn=t.div`
  border-bottom: 1px solid ${e=>e.theme.border};
`,Kn=t(H.div)`
  display: flex;
  flex-direction: row;
  padding: 0 16px;
`,Jn=t.div`
  border-bottom-style: solid;
  border-bottom-width: 2px;
  border-bottom-color: ${e=>e.active?e.theme.purple:"transparent"};
  margin-right: 8px;
  height: 56px;
  display: flex;
  align-items: center;
`,Rn=t.div`
  padding: 8px 4px;
  border-radius: 8px;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  color: ${e=>e.isActive?e.theme.white:e.theme.grayLight};
  transition:
    color 0.1s cubic-bezier(0.5, 1, 0.89, 1),
    background 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  white-space: nowrap;

  height: 32px;
  display: flex;
  align-items: center;

  &:active {
    color: ${e=>e.theme.white};
    background: #333;
  }
`;var br=()=>{let{activeSectionIdx:e,sections:o}=bt(),{setActiveSection:r}=ae(),{t:s}=v(),a=(0,Et.useMemo)(()=>o.map(l=>{switch(l){case"sites":return s("exploreSites");case"tokens":return s("exploreTokens");case"collections":return s("exploreCollections");case"quests":return s("quests");case"learn":return s("exploreLearn");default:return""}}),[o,s]);return Et.default.createElement(qt,{values:a,activeTabIndex:e,setActiveTabIndex:l=>{let p=o[l];r(p),k.onExploreTabClickedByUser({tabName:p})}})};var es=15,ts=(0,kr.default)(e=>{e&&k.onExploreSearchedByUser({searchTerm:e})},1e3);function os(){let e=eo(),{t:o}=v(),{data:r}=at(),{error:s,refetch:a}=st(),{setActiveSection:l,activeSection:p}=ae();(0,D.useEffect)(()=>{e.state?.tab==="quests"&&r&&l("quests")},[e.state?.tab,r,s,l]);let{error:x,refetch:f}=ot(),{error:u,refetch:L}=tt(),{refetch:h}=it(),{refetch:C}=Re(),{refetch:E}=rt(),{refetch:I}=et(),{refetch:y}=nt(),A=x&&u,N=(0,D.useCallback)(()=>{switch(p){case"sites":L(),f();break;case"collections":I(),C();break;case"tokens":E(),h();break;case"quests":r&&a();break;case"learn":y();break}},[p,L,f,I,C,E,h,r,y,a]),{exploreSearchQuery:j,setExploreSearchQuery:_e}=ae(),se=Xt(j,250),Me=Zt(),Ce=Jt({searchQuery:se,networkIds:Me,minSearchResults:es}),{showSpinner:Pt,showSearchResults:Oe}=Ce;return(0,D.useEffect)(()=>{ts(se)},[se]),A?D.default.createElement(is,null,D.default.createElement(bo,{title:o("exploreErrorTitle"),buttonText:o("exploreErrorButtonText"),description:o("exploreErrorDescription"),refetch:N})):D.default.createElement(rs,null,D.default.createElement(wo,{value:j,onChange:_e,isLoading:Pt}),D.default.createElement(vr,{hide:Oe},D.default.createElement(br,null)),D.default.createElement(wr,{hide:Oe},D.default.createElement(yr,null),p==="tokens"&&D.default.createElement(ns,null,D.default.createElement(ss,null,o("exploreTokensLegalDisclaimer")))),D.default.createElement(wr,{hide:!Oe},D.default.createElement(Co,{...Ce,entryPoint:"explore"})))}var rs=t.div`
  position: absolute;
  display: flex;
  flex-direction: column;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: hidden;
`,is=t.div`
  padding: 16px;
`,vr=t.div`
  display: ${({hide:e})=>e?"none":"initial"};
  overflow-x: hidden;
`,wr=t(vr)`
  display: ${({hide:e})=>e?"none":"flex"};
  flex: 1;
  flex-direction: column;
  overflow-y: auto;
`,ns=t.div`
  padding: 12px 16px;
`,ss=t(P)`
  color: #999;
  font-feature-settings: "calt" off;

  font-size: 13px;
  font-style: normal;
  font-weight: 400;
  line-height: 16px;
  text-align: left;
`,Su=os;export{os as ExplorePage,Su as default};
