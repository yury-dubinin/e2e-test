import{c as p}from"./chunk-QVVAGMA5.js";import{a as i}from"./chunk-OIUFF6CQ.js";import{a}from"./chunk-7ZDPJAUC.js";import{o as n,p as t}from"./chunk-OJG7N72N.js";import{a as d}from"./chunk-MVAHBHCD.js";import{f as c,h as r,n as e}from"./chunk-FPMOV6V2.js";r();e();var o=c(d());var f=[1,2,3],m=50,l=350,h=m+l,I=n`
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
`,H=t(a).attrs({align:"center"})`
  height: ${h}px;
`,S=t(i).attrs({width:"100%",height:`${m}px`,margin:"0 0 20px 0",borderRadius:"6px",backgroundColor:"#2D2D2D"})``,L=()=>o.default.createElement(H,null,o.default.createElement(S,null),f.map(s=>o.default.createElement(p,{key:`fungible-token-row-${s}`})));export{L as a};
