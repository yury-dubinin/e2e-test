import{P as c,Q as l,oa as d}from"./chunk-KB2UMCDM.js";import{p as a}from"./chunk-OJG7N72N.js";import{a as g}from"./chunk-MVAHBHCD.js";import{f as s,h as i,n as t}from"./chunk-FPMOV6V2.js";i();t();var p=a.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  overflow: hidden;
  background-color: ${e=>e.isPurple?"#34333f":"#2d2d2d"};
  background-image: ${e=>e.previewImage?`url(${e.previewImage})`:void 0};
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
`;i();t();var o=s(g());var v=o.default.memo(({type:e,width:r=48,fill:n="#474747"})=>{switch(e){case"video":return o.default.createElement(l,{width:r,height:r,fill:n});case"audio":return o.default.createElement(c,{width:r,height:r,fill:n});case"image":case"other":default:return o.default.createElement(d,{width:r,height:r,fill:n})}});export{p as a,v as b};
