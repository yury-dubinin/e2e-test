import{p as o}from"./chunk-OJG7N72N.js";import{h as t,n as e}from"./chunk-FPMOV6V2.js";t();e();t();e();var p=o.div`
  ${r=>!r.plain&&`
    background-color: #2b2b2b;
    border-top: 1px solid #323232;
    box-shadow: 0px -6px 10px rgba(0, 0, 0, 0.25);
  `}
`;var c=o.div`
  flex: none;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;

  > * {
    margin-top: 27px;
  }
`,f=o.div`
  flex: 1;
  overflow: auto;
  padding: 0px 16px;
`,m=o.div`
  position: fixed;
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  left: 0;
  bottom: 0;
  background: #222222;
`,g=o(p)`
  flex: none;
  padding: 14px 20px;
`,b=o.div`
  padding: 20px;
  height: 100%;
`;export{p as a,c as b,f as c,m as d,g as e,b as f};
