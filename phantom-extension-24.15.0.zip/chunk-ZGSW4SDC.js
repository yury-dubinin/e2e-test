import{h as e,i as n,n as r}from"./chunk-FPMOV6V2.js";e();r();var s=()=>n.ENVIRONMENT==="e2e";export{s as a};
